"""Print a two-page Chinese experiment note from the locked validation and test results."""
import argparse
import html
import json
from pathlib import Path
import tempfile

from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
NAMES = {"previous": "上轮 60 轮", "continued": "原结构续训", "residual": "残差与子像素"}


def name(key):
    return NAMES.get(key, "残差与子像素 + FFL")


def table(headers, rows):
    head = "".join(f"<th>{h}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{x}</td>" for x in row) + "</tr>" for row in rows)
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


STYLE = """
@page {size:A4; margin:0} *{box-sizing:border-box} body{margin:0; color:#17282b; background:white;
font: 10.5pt/1.52 'Microsoft YaHei','Noto Sans CJK SC',sans-serif}
section{width:210mm; min-height:297mm; padding:13mm 16mm 15mm; position:relative; break-after:page}
section:last-child{break-after:auto} .top{display:flex;justify-content:space-between;align-items:center;
padding-bottom:2.3mm;border-bottom:1px solid #73898e;color:#3c6064;font-size:9pt}
h1{font-size:22pt;margin:5mm 0 1.8mm;line-height:1.2;letter-spacing:-0.4pt}
h2{font-size:13.5pt;margin:4mm 0 1.3mm} p{margin:1.5mm 0} b{font-weight:650}
table{border-collapse:collapse;width:100%;margin:2mm 0 2.5mm;font-size:9.6pt;font-variant-numeric:tabular-nums}
th,td{text-align:right;border-bottom:1px solid #d6dfe0;padding:1.2mm 1.5mm;white-space:nowrap}
th{background:#e9f0ef;color:#244d50;font-weight:600} td:first-child,th:first-child{text-align:left}
td:nth-child(2),th:nth-child(2){text-align:left} .cite,.caption{font-size:8.6pt;color:#435d60}
a{color:#235e66;text-decoration:underline} img{display:block;width:100%;height:auto;margin:2mm 0 1mm}
.foot{position:absolute;bottom:7mm;left:16mm;right:16mm;border-top:1px solid #ced8d8;padding-top:1.5mm;
display:flex;justify-content:space-between;font-size:8.5pt;color:#496065}
"""


def build_note(chrome=None):
    v = json.loads((HERE / "validation.json").read_text(encoding="utf-8"))
    test = json.loads((HERE / "results/metrics.json").read_text(encoding="utf-8"))
    if not v.get("selection_final"):
        raise ValueError("Wait for final validation selection")
    scores = []
    val_description = []
    test_table = []
    deltas = []
    for side in ("8", "16"):
        candidates = v["candidates"][side]
        winner = v["selected"][side]["candidate"]
        for key, entry in candidates.items():
            label = name(key) + (" ✓" if key == winner else "")
            scores.append((side+"×"+side,label,f"{entry['parameters']:,}",f"{entry['psnr']:.3f}",
                           f"{entry['ssim']:.4f}",f"{entry['local_detail_mae']:.3f}"))
        val_description.append(f"{side}×{side} 选用“{name(winner)}”")
        old, new = (test["models"][key+side]["metrics"] for key in ("previous","current"))
        test_table.append((side+"×"+side,f"{old['psnr']:.2f} → {new['psnr']:.2f}",
                           f"{old['ssim']:.4f} → {new['ssim']:.4f}",
                           f"{old['local_detail_mae']:.3f} → {new['local_detail_mae']:.3f}"))
        deltas.append(100*(1-new["local_detail_mae"]/old["local_detail_mae"]))
    sizes = table(("潜网格","验证候选","参数","PSNR / dB ↑","SSIM ↑","细节误差 ↓"),scores)
    official = table(("潜网格","PSNR / dB ↑","SSIM ↑","细节误差 ↓"),test_table)
    bands = json.loads((HERE / "frequency-bands.json").read_text(encoding="utf-8"))["candidates"]["16"]
    low_gain = 100*(1 - bands["paper_ffl"]["low"] / bands["residual"]["low"])
    high_cost = 100*(bands["paper_ffl"]["high"] / bands["residual"]["high"] - 1)
    photo = (HERE / "results/crop-comparison.png").as_uri()
    truck = next(c["mean_rgb_abs_error"] for c in test["crops"] if c["index"] == 11)
    detail = {s:{k:m["local_detail_mae"] for k,m in rows.items()}
              for s,rows in v["candidates"].items()}
    improved = {s:rows["local_detail_mae"]["improved_images"] for s,rows in test["paired"].items()}
    example = test["counterexamples"]["16"]
    exception = (f"例外之一为索引 {example['index']} 的测试图"
                 f"（{example['previous_detail_mae']:.3f} → {example['current_detail_mae']:.3f}）。"
                 if example else "")
    url = "https://banligegit.github.io/mini-ddpm/cifar-vae/"
    def top(text): return f'<div class="top"><span>CIFAR-10 · 卷积 VAE</span><span>{text}</span></div>'
    def foot(n): return f'<div class="foot"><span>mini-ddpm-cifar-vae　·　重建细节实验</span><span>{n} / 2</span></div>'
    h = f"""<!doctype html><meta charset="utf-8"><title>CIFAR-10 VAE 重建细节 · 论文方法对照</title>
    <style>{STYLE}</style><section>{top("方法与验证")}
    <h1>怎样让窗框和细线更接近原图？</h1>
    <p>上轮模型在同一张 CIFAR-10 照片上已经能还原车身。这次固定潜变量的形状和通道数，比较继续训练、增加像素位置修正、加强频域监督三种做法。</p>
    <h2>从三篇论文中借用了什么</h2>
    <p><b>学习修正量。</b> 借鉴 He 等的残差学习，让新支路补充原编码器和解码器。末层初始为零，所以训练开始时新旧模型给出相同的后验参数和重建图。[1]</p>
    <p><b>按位置预测子像素。</b> 借鉴 Shi 等的子像素卷积，从低分辨率特征预测各位置的 RGB 修正，再重排到像素网格。编码端相应地将输入块按位置重排到通道；解码时仍只接收四通道 z。[2]</p>
    <p><b>让频率误差参与训练。</b> 参照 Jiang 等的 FFL，给当前复数频谱中预测偏差大的分量较高权重。权重逐图逐通道归一化，停止梯度。本轮在相同新结构上额外加入 0.5 倍 FFL。[3]</p>
    <h2>验证集对照</h2>
    <p>每种尺寸都从同一份 60 轮权重出发。三个续训分支各训练 20 轮（3,520 次更新），共用 45,000 张训练图、5,000 张验证图、样本顺序和后验抽样种子。β 维持 0.003，高通项权重维持 0.075。</p>
    {sizes}
    <p class="caption">✓ 为同尺寸验证选定的模型。在 PSNR 距最佳不超过 0.25 dB、SSIM 距最佳不超过 0.003 的候选中，取细节误差最小者。原结构续训用于估算增加更新次数的作用；两组新结构之差用于评估 FFL。</p>
    <h2>新增参数换来了多少细节</h2>
    <p>16×16 验证集上，原结构延训使细节误差从 {detail['16']['previous']:.3f} 降为 {detail['16']['continued']:.3f}，同预算的新支路进一步降至 {detail['16']['residual']:.3f}。8×8 上，新支路相对延训仅从 {detail['8']['continued']:.3f} 降至 {detail['8']['residual']:.3f}。实验测到的是新增参数和重排设计的共同效果，两个尺寸的收益也有明显差别。</p>
    <p class="cite">[1] <a href="https://arxiv.org/abs/1512.03385">He 等 · Deep Residual Learning，CVPR 2016</a>　[2] <a href="https://arxiv.org/abs/1609.05158">Shi 等 · Sub-pixel CNN，CVPR 2016</a><br>
    [3] <a href="https://arxiv.org/abs/2012.12821">Jiang 等 · Focal Frequency Loss，ICCV 2021</a>　·　<a href="https://github.com/EndlessSora/focal-frequency-loss">作者实现</a></p>{foot(1)}</section>
    <section>{top("锁定权重后的官方测试")}<h1>同一位置，优化前后</h1>
    <p>按验证结果，{'，'.join(val_description)}。在同一批 10,000 张官方测试图上直接解码每张图的后验均值 μ，以下箭头均由上轮 60 轮模型指向本轮选定模型。</p>
    {official}
    <p>8×8 与 16×16 的平均局部细节误差分别下降 <b>{deltas[0]:.1f}%</b> 和 <b>{deltas[1]:.1f}%</b>。该指标衡量像素减去 3×3 邻域均值后与原图相应残差的差异，按 0–255 RGB 强度计。</p>
    <h2>预先固定的三个局部</h2><img src="{html.escape(photo)}">
    <p class="caption">使用此前已选定的飞机文字、卡车窗框和船身像素框。整数最近邻放大保留原图的像素边界。</p>
    <p>卡车窗框内，8×8 的逐像素绝对误差从 {truck['previous8']:.2f} 变为 {truck['current8']:.2f}，16×16 从 {truck['previous16']:.2f} 变为 {truck['current16']:.2f}。这是同一框内 RGB 值相对原图的误差，与上表按整张图计算的高通误差分别统计。</p>
    <p>逐图复核，16×16 有 {improved['16']:,} 张的细节误差下降，8×8 有 {improved['8']:,} 张下降。{exception}两图即使肉眼近似，误差仍可能有小幅变化。</p>
    <h2>频域损失为什么没被选中</h2>
    <p>16×16 验证集上，对同一新结构加 FFL 后，总体 PSNR 略有提高。将像素平方误差按径向频率分解，低频（≤ 1/8 周期/像素）对 MSE 的贡献降低 {low_gain:.1f}%，高频（&gt; 1/4 周期/像素）的贡献反而增加 {high_cost:.1f}%。本轮优先还原局部细节，选择表中高通误差更低的版本。</p>
    <p>输入照片只有 32×32 像素，字形轮廓更接近原图，并不代表可以从图上读出原始文字。本轮比较使用一个训练种子，结论适用于这些模型和这次训练预算，随机先验生成需要另行验证。</p>
    <p><a href="{url}">在网页上同步放大查看其他区域</a></p>{foot(2)}</section>"""
    with tempfile.TemporaryDirectory() as d:
        source = Path(d)/"note.html"
        source.write_text(h, encoding="utf-8")
        with sync_playwright() as pw:
            browser = pw.chromium.launch(executable_path=chrome)
            page = browser.new_page()
            page.goto(source.as_uri(), wait_until="load")
            assert page.locator("img").evaluate("(el) => el.complete && el.naturalWidth > 0")
            page.evaluate("document.fonts.ready")
            page.pdf(path=str(HERE/"paper-detail-note.pdf"), prefer_css_page_size=True,
                     print_background=True, display_header_footer=False)
            browser.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chrome", help="Local Chrome or Chromium executable")
    build_note(parser.parse_args().chrome)
