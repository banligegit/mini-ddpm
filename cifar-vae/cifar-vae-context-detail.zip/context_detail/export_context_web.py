"""Add validation-selected CIFAR-10 models, comparison images and scores to the existing task 5 site."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

import numpy as np
import onnxruntime as ort
from PIL import Image
import torch

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK))
from cifar_data import load_split
from export_web import Decoder, MeanEncoder, checked_export, save_image
from context_model import load_context_model


@torch.inference_mode()
def export_side(side, model, examples, site):
    enc_file = site / "models" / f"context-encoder{side}.onnx"
    dec_file = site / "models" / f"context-decoder{side}.onnx"
    z = torch.randn(1, 4, side, side, generator=torch.Generator().manual_seed(2026))
    enc_error = checked_export(MeanEncoder(model), next(iter(examples.values())), enc_file, "x", "mu")
    dec_error = checked_export(Decoder(model), z, dec_file, "z", "rgb")
    enc = ort.InferenceSession(str(enc_file), providers=["CPUExecutionProvider"])
    dec = ort.InferenceSession(str(dec_file), providers=["CPUExecutionProvider"])
    rgb_error = 0.
    for idx, x in examples.items():
        expected = model.decode(model.encode(x)[0])
        mu, = enc.run(["mu"], {"x": x.numpy()})
        actual, = dec.run(["rgb"], {"z": mu})
        error = float(np.abs(actual - expected.numpy()).max())
        if not np.isfinite(error) or error > 2e-4:
            raise RuntimeError(f"ONNX reconstruction mismatch for {side}x{side} on test #{idx}: {error}")
        rgb_error = max(rgb_error, error)
        pixels = expected[0].mul(255).round().clamp(0, 255).byte().numpy()
        save_image(pixels, site / "samples" / f"{idx}-context{side}.png")
    return dict(encoder_max_abs=enc_error, decoder_max_abs=dec_error, ten_image_rgb_max_abs=rgb_error)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Existing site/cifar-vae folder")
    parser.add_argument("--data", type=Path, default=TASK / "data")
    args = parser.parse_args()
    torch.set_num_threads(2)
    validation = json.loads((HERE / "validation.json").read_text(encoding="utf-8"))
    if validation.get("selection_final") is not True:
        raise RuntimeError("Validation selection must be locked before export")
    scores = json.loads((HERE / "results/metrics.json").read_text(encoding="utf-8"))
    catalog = json.loads((args.output / "results.json").read_text(encoding="utf-8"))
    prior = scores["prior"]
    if (scores["n"] != 10000 or prior["reference_indices"] != list(range(32))
            or prior["count_per_model"] != 32 or prior["seed"] != 2026 or prior["matched_reference"]):
        raise ValueError("Official evaluation does not match the page's test or prior sample protocol")
    originals, _ = load_split(args.data, train=False)
    examples = {}
    for sample in catalog["samples"]:
        idx = sample["index"]
        with Image.open(args.output / "samples" / f"{idx}-original.png") as img:
            if not np.array_equal(np.array(img.convert("RGB")), originals[idx].transpose(1, 2, 0)):
                raise ValueError(f"Existing site original does not match official test image {idx}")
        examples[idx] = torch.from_numpy(originals[idx]).float().unsqueeze(0) / 255
    if list(examples) != scores["indices"]:
        raise ValueError("Web and official evaluation image indices differ")

    options = {"previous": "上轮权重", "continued": "原结构续训", "context": "上下文残差版"}
    records, selections = {}, []
    for side in (16, 8):
        choice = validation["selected"][str(side)]
        checkpoint = TASK / choice["checkpoint"]
        digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        result = scores["models"][f"current{side}"]
        if digest != choice["sha256"] or digest != result["sha256"]:
            raise ValueError(f"Locked validation/test checkpoint mismatch: {checkpoint}")
        model = load_context_model(checkpoint, "cpu").eval()
        errors = export_side(side, model, examples, args.output)
        row = {key: result["metrics"][key] for key in ("psnr", "ssim", "local_detail_mae")}
        records[str(side)] = dict(**row, **errors, checkpoint_sha256=digest, candidate=choice["candidate"])
        records[str(side)]["lower_detail_error_count"] = scores["paired"][str(side)]["local_detail_mae"]["improved_images"]
        selections.append(f"{side} × {side} 选用{options[choice['candidate']]}")
        print(f"{side}x{side}: ten-image ONNX RGB error {errors['ten_image_rgb_max_abs']:.3g}", flush=True)
    for group in ("real-reference", "prior16", "prior8", "counterexamples"):
        shutil.copyfile(HERE / "results" / f"{group}.png", args.output / "samples" / f"context-{group}.png")
    note = (f"首版用 50,000 张图训练 10 轮。后续固定 45,000 张训练、5,000 张验证。"
            f"论文版在 60 轮版上续训 20 轮。本轮从论文版出发，分别测试原结构续训与增加上下文残差分支，"
            f"两组各续训 {validation['extra_epochs']} 轮。按验证集选型，" + "，".join(selections) + "。")
    output = dict(test_image_count=scores["n"], models=records, training_note=note, prior=prior)
    (args.output / "context-results.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
