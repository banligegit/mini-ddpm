"""Print the three-page report from the locked selections, training logs and test outputs."""
import argparse
import csv
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "paper_detail"))
from make_note import STYLE, table

URL = "https://banligegit.github.io/mini-ddpm/cifar-vae/"
TITLES = {"context": "扩张卷积残差块", "continued": "原结构续训", "previous": "上轮权重"}
SIDES = ("16", "8")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def tag_image(path, alt):
    return f'<img src="{path.as_uri()}" alt="{alt}">'


def frame(page, topic, title, content):
    return (f'<section><div class="top"><span>CIFAR-10　/　卷积变分自编码器</span>'
            f'<span>{topic}</span></div><h1>{title}</h1>{content}<div class="foot">'
            f'<span>mini-ddpm-cifar-vae　·　题目五实验报告</span><span>{page} / 3</span></div></section>')


def final_epoch(side, validation):
    path = ROOT / validation["selected"][side]["checkpoint"]
    with (path.parent / "history.csv").open(encoding="utf8") as file:
        return list(csv.DictReader(file))[-1]


def loss_table(v):
    rows = []
    for side in SIDES:
        last = final_epoch(side, v)
        kl = float(last["kl_per_pixel"])
        rows.append((f"{side}×{side}×4", f"{v['selected'][side]['parameters']:,}",
                     f"{float(last['train_mse']):.6f}", f"{kl:.4f}",
                     f"{v['beta'] * kl:.6f}", f"{float(last['total']):.6f}"))
    return table(("潜变量形状", "参数量", "重建 MSE", "KL / 3,072", "加权 KL", "含细节项的总损失"), rows)


def page_one(v):
    rows = []
    for side in SIDES:
        for key in ("previous", "continued", "context"):
            values = v["candidates"][side][key]
            chosen = " ✓" if v["selected"][side]["candidate"] == key else ""
            rows.append((f"{side}×{side}", TITLES[key] + chosen,
                         f"{values['psnr']:.2f}", f"{values['ssim']:.4f}", f"{values['local_detail_mae']:.3f}"))
    validation_table = table(("潜网格", "验证候选", "PSNR / dB ↑", "SSIM ↑", "局部细节误差 ↓"), rows)
    return frame(1, "方法与验证", "同一张照片，压缩后还能还原多少？", f"""
    <p>一张 CIFAR-10 原图有 32×32×3＝3,072 个颜色值。这里让两个模型分别用 1,024 和 256 个潜变量记录同一张图，再看车窗、船身和小字的像素能还原到什么程度。</p>
    <h2>编码、采样与损失</h2>
    <p>RGB 像素除以 255 进入卷积编码器。编码器在每个潜位置输出四个均值 μ 和四个对数方差 ℓ。训练时取 <b>z = μ + exp(ℓ/2) ⊙ ε</b>，其中 ε 来自标准正态；测试重建直接取 z = μ。解码器只接收 z，末层 sigmoid 将 RGB 限制在 [0, 1]。</p>
    <p>16×16 版主干下采样一次，8×8 版多一次下采样和对应的上采样。两版都保留前轮的像素重排支路。本轮候选在编码端与解码端的低分辨率特征上各加三个残差块，3×3 卷积的膨胀率依次为 1、2、1。中间层能跨一个格点读取邻居；新增分支初始输出为零。</p>
    <p class="formula"><b>L = MSE + 0.003 × KL / 3,072 + 0.075 × 局部细节误差</b></p>
    <p>每张图的 MSE 对 3,072 个 RGB 值取均值。KL 把各潜坐标的 ½(μ² + exp ℓ − 1 − ℓ) 相加，再除以 3,072。细节项取重建误差减去其 3×3 邻域均值后的绝对值均值，训练单位为 [0, 1]。三项最后对 batch 取均值。下表为入选模型末轮训练记录。</p>
    {loss_table(v)}
    <h2>在验证集上比较同样多的训练</h2>
    <p>从官方训练集固定分出 45,000 张训练、5,000 张验证。每种尺寸从自己的第 80 轮权重出发，分别做原结构续训和加残差块续训。两支各训练 {v['extra_epochs']} 轮、{v['updates_per_variant']:,} 次更新，共用种子 {v['seed']}、样本顺序、优化器设置和 batch size {v['batch_size']}。</p>
    {validation_table}
    <p class="caption">✓ 为验证集入选模型。在同尺寸 PSNR 距最佳不超过 0.25 dB、SSIM 距最佳不超过 0.003 的候选中，选细节误差最低者。16×16 原结构多训 40 轮已提高约 0.96 dB，新结构再提高约 0.21 dB。两种尺寸均增加 61,824 个参数。</p>
    <img class="loss-plot" src="{(HERE / 'results/training-curves.png').as_uri()}" alt="续训 40 轮的重建与 KL 曲线">
    <p class="caption">左图是训练 MSE，右图是每图 KL / 3,072。实线为新增卷积块，虚线为原结构续训，β 均为 0.003。</p>""")


def page_two(test, observations):
    rows = []
    for side in SIDES:
        for version, name in (("previous", "上轮"), ("current", "本轮")):
            m = test["models"][version + side]["metrics"]
            rows.append((f"{side}×{side}", name, f"{m['mse']:.6f}", f"{m['psnr']:.2f}",
                         f"{m['ssim']:.4f}", f"{m['mean_rgb_mae']:.2f}", f"{m['coarse_gradient_mae']:.2f}",
                         f"{m['local_detail_mae']:.2f}"))
    scores = table(("潜网格", "权重", "MSE ↓", "PSNR ↑", "SSIM ↑", "颜色 ↓", "轮廓 ↓", "细节 ↓"), rows)
    counts = [test["paired"][s]["local_detail_mae"]["improved_images"] for s in SIDES]
    return frame(2, "官方测试集　·　配对重建", "把重建放回原图旁边看", f"""
    <p>固定两份验证入选权重，在全部 {test['n']:,} 张官方测试图上用 μ 重建。每张图独立计算各项指标，再取平均。PSNR 单位为 dB。颜色、轮廓、细节三列分别测整图 RGB 均值、4×4 分块后的相邻梯度、3×3 高通残差，单位均为 0–255 RGB 强度级。</p>{scores}
    <figure>{tag_image(HERE / 'results/full-comparison.png', '十类照片原图与同图重建')}
    <figcaption>图 1　每类取测试集顺序中的第一张。对齐看同一列，可分别判断压缩尺寸带来的差距与同尺寸模型的改进。</figcaption></figure>
    <figure>{tag_image(HERE / 'results/crop-comparison.png', '三张照片固定位置的原像素和重建像素')}
    <figcaption>图 2　固定三处原图坐标，以最近邻放大。橙框只负责定位。{observations['crop']}</figcaption></figure>
    <p>相比上轮，16×16 有 <b>{counts[0]:,}</b> 张的整图细节误差下降，8×8 有 <b>{counts[1]:,}</b> 张下降。{observations['exception']}</p>
    <p class="caption">{observations['texture']}</p>""")


def page_three(test, observations):
    groups = (
        ("real-reference", "真实 CIFAR-10", "按官方测试顺序取前 32 张，供观察真实照片中常见的主体和背景。"),
        ("prior16", "16×16×4 直接采样", observations["prior16"]),
        ("prior8", "8×8×4 直接采样", observations["prior8"]),
    )
    panels = "".join(f'<div class="panel">{tag_image(HERE / ("results/" + key + ".png"), title)}'
                     f'<div><h3>{title}</h3><p>{caption}</p></div></div>' for key, title, caption in groups)
    a, b = [test["models"]["current" + s]["metrics"] for s in SIDES]
    return frame(3, "未筛选生成　·　下一题的权重", "从标准正态出发，能画出什么？", f"""
    <p>对两个入选解码器各连续抽取 32 个 z ∼ N(0, I)，PyTorch CPU 种子 {test['prior']['seed']}。下图完整保留生成顺序。真实照片仅作整体观感参考，随机样本没有对应原图，因此这一页没有逐图 PSNR 或 SSIM。</p>
    {panels}
    <p><b>为何与第 2 页相差这么多？</b> 编码一张船的照片时，μ 在空间上已经记录船身和水面的排列。直接抽样时，各坐标独立取值。训练中的 KL 鼓励每张图的后验接近标准正态，不能保证任意独立组合都具有自然物体的结构。单凭这两组样本，无法区分先验匹配程度和解码器容量各自的影响。</p>
    <h2>题目六选哪一份</h2>
    <p>网页优先展示 16×16，便于核对最接近原图的重建。题六准备采用本轮 <b>8×8×4</b> 权重，潜位置数从 256 减至 64，通道数同为 4。代价是测试 PSNR 低 {a['psnr']-b['psnr']:.2f} dB，SSIM 低 {a['ssim']-b['ssim']:.4f}。训练集 μ 的四通道标准化常量随权重提供，已在验证集核对编码与解码的往返误差。本轮使用一个训练种子，题六的实际加速留待扩散训练测量。</p>
    <p class="caption">复现与资料　<a href="{URL}#comparison">网页同图比较</a>　·　<a href="{URL}#priors">未筛选生成</a>　·　<a href="{URL}cifar-vae-context-detail.zip">代码、权重与逐图指标</a><br>
    <a href="https://cave.cs.toronto.edu/kriz/cifar.html">CIFAR-10 数据说明</a>　·　<a href="https://arxiv.org/abs/1312.6114">Kingma 与 Welling，变分自编码器</a>　·　<a href="https://arxiv.org/abs/1511.07122">Yu 与 Koltun，扩张卷积</a></p>""")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--chrome", help="Path to a local Chrome or Chromium executable")
    args = p.parse_args()
    v = read(HERE / "validation.json")
    test = read(HERE / "results/metrics.json")
    observations = read(HERE / "report-observations.json")
    calibration = read(HERE / "calibration/roundtrip.json")
    if (not v["selection_final"] or calibration["checkpoint_sha256"] != v["selected"]["8"]["sha256"]
            or any(test["models"]["current" + s]["sha256"] != v["selected"][s]["sha256"] for s in SIDES)):
        raise ValueError("The validation, test and calibration records must refer to the same weights")
    style = STYLE + """
      body{font-size:10.1pt;line-height:1.45} section{padding:12mm 15mm 14mm}
      h1{font-size:21pt} h2{font-size:13pt;margin:3.3mm 0 1mm} h3{font-size:12pt;margin:1mm 0}
      th,td{padding:1.05mm 1.35mm} table{font-size:9.2pt} p{margin:1.4mm 0}
      figure{margin:2.5mm 0} figure img{max-height:74mm;object-fit:contain}
      figcaption{font-size:8.8pt;color:#425d63}.formula{padding:2mm 3mm;background:#eaf2f0}
      .panel{display:flex;align-items:center;gap:5mm;margin:2mm 0}
      .panel img{width:90mm;margin:0}.panel p{font-size:9.5pt}.panel div{flex:1}
      .loss-plot{height:44mm;object-fit:contain;margin:1mm auto}
    """
    body = page_one(v) + page_two(test, observations) + page_three(test, observations)
    doc = f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>CIFAR-10 VAE 实验报告</title><style>{style}</style><body>{body}</body></html>'
    with TemporaryDirectory() as tmp:
        path = Path(tmp) / "report.html"
        path.write_text(doc, encoding="utf8")
        with sync_playwright() as pw:
            browser = pw.chromium.launch(executable_path=args.chrome)
            page = browser.new_page()
            page.goto(path.as_uri(), wait_until="load")
            page.evaluate("document.fonts.ready")
            assert page.locator("img").evaluate_all("(imgs) => imgs.length === 6 && imgs.every(i => i.complete && i.naturalWidth > 0)")
            page.pdf(path=str(HERE / "cifar-vae-current-report.pdf"), prefer_css_page_size=True,
                     print_background=True, display_header_footer=False)
            browser.close()


if __name__ == "__main__":
    main()
