"""Compare extra context against matched continued training on the fixed 45k/5k split."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import torch

from context_model import ContextVAE, TASK, load_context_model, load_paper_model
sys.path.insert(0, str(TASK / "paper_detail"))
from train_paper import validate, relpath
from cifar_data import load_split
from detail.train_detail import BATCH, BETA, WEIGHT, SEED, run_epochs, write_json
from evaluate import save_grid

HERE = Path(__file__).resolve().parent
EPOCHS = 40
LR = .0008


def checksum(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def initialize(prior, side, variant, examples):
    torch.manual_seed(SEED)
    before = load_paper_model(prior)
    if variant == "continued":
        return before
    after = ContextVAE(side)
    added = after.load_state_dict(before.state_dict(), strict=False)
    if added.unexpected_keys or set(added.missing_keys) != {
        key for key in after.state_dict() if ".context." in key
    }:
        raise ValueError("Initial parameter mapping failed")
    with torch.inference_mode():
        a, b = before.encode(examples)
        c, d = after.encode(examples)
        if not (torch.equal(a, c) and torch.equal(b, d) and torch.equal(before.decode(a), after.decode(c))):
            raise ValueError("New blocks did not preserve the original encoder/decoder function")
    return after


def fit(prior, side, variant, train_x, val_x, examples, dest):
    device = train_x.device
    dest.mkdir(parents=True, exist_ok=True)
    model = initialize(prior, side, variant, examples[:4].cpu()).to(
        device=device, memory_format=torch.channels_last).train()
    torch.manual_seed(SEED)
    order = torch.Generator().manual_seed(SEED)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, T_max=EPOCHS * math.ceil(len(train_x) / BATCH), eta_min=LR / 10)
    print(f"Starting {side}-{variant}, {sum(p.numel() for p in model.parameters()):,} parameters", flush=True)
    with (dest / "history.csv").open("w", encoding="utf8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(("extra_epoch", "train_mse", "kl_per_pixel", "highpass_l1", "total",
                         "highpass_weight", "seconds"))
        for first in range(1, EPOCHS + 1, 5):
            writer.writerows(run_epochs(model, opt, sched, train_x, order, first,
                                        min(first + 4, EPOCHS), WEIGHT))
            f.flush()
    checkpoint = dest / f"vae{side}.pt"
    tmp = checkpoint.with_suffix(".tmp")
    torch.save({"side": side, "architecture": "context" if variant == "context" else "residual",
                "state_dict": {k: v.cpu() for k, v in model.state_dict().items()},
                "config": {"parent_sha256": checksum(prior), "beta": BETA, "highpass": WEIGHT,
                           "extra_epochs": EPOCHS, "batch_size": BATCH, "initial_lr": LR,
                           "final_lr": LR / 10, "seed": SEED}}, tmp)
    tmp.replace(checkpoint)
    # Evaluate the actual persisted checkpoint in float32.
    with torch.backends.cudnn.flags(enabled=True, benchmark=False, deterministic=False, allow_tf32=False):
        metrics = validate(load_context_model(checkpoint, device), val_x, examples, device,
                           dest / "validation-examples.png")
    metrics.update(parameters=sum(p.numel() for p in model.parameters()), checkpoint=relpath(checkpoint),
                   sha256=checksum(checkpoint))
    print(f"Validation {side}-{variant}: {metrics}", flush=True)
    return metrics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE)
    parser.add_argument("--data", type=Path, default=TASK / "data")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--resume", action="store_true", help="Skip verified completed variants")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    lock = out / "validation.json"
    previous = json.loads((TASK / "paper_detail/validation.json").read_text("utf8"))
    if not previous["selection_final"]:
        raise RuntimeError("Previous validation selection is incomplete")
    torch.set_num_threads(min(8, torch.get_num_threads()))
    array, labels = load_split(args.data, train=True)
    split_path = TASK / "refinement/beta/split.npz"
    with np.load(split_path) as split:
        tr, va = split["train"], split["val"]
    train_x = torch.from_numpy(array[tr]).to(args.device)
    val_x = torch.from_numpy(array[va])
    idx = [int(va[labels[va] == k][0]) for k in range(10)]
    examples = torch.from_numpy(array[idx]).to(device=args.device, dtype=torch.float32) / 255
    del array
    save_grid(examples, out / "validation-original.png")
    report = {"initial_epochs": 80, "extra_epochs": EPOCHS, "batch_size": BATCH, "seed": SEED,
              "updates_per_variant": EPOCHS * math.ceil(len(tr) / BATCH), "beta": BETA, "highpass": WEIGHT,
              "initial_lr": LR, "final_lr": LR / 10, "split_sha256": checksum(split_path),
              "example_indices": idx, "train_images": len(tr), "validation_images": len(va),
              "selection": "Within 0.25 dB and 0.003 of the respective validation PSNR and SSIM maxima, "
                           "minimize local_detail_mae; retain previous if no feasible candidate.",
              "selection_final": False, "candidates": {}, "selected": {}}
    saved = {}
    if args.resume and lock.exists():
        old = json.loads(lock.read_text("utf8"))
        if any(old[k] != v for k, v in report.items() if k not in ("selection_final", "selected", "candidates")):
            raise ValueError("Stored experiments used a different protocol")
        saved = old["candidates"]
    else:
        write_json(lock, report)
    for side in (8, 16):
        parent = dict(previous["selected"][str(side)])
        if parent.pop("candidate") != "residual":
            raise ValueError("Expected a residual VAE parent")
        prior = TASK / parent["checkpoint"]
        if checksum(prior) != parent["sha256"]:
            raise ValueError("Parent checkpoint checksum mismatch")
        candidates = report["candidates"][str(side)] = {"previous": parent}
        for variant in ("context", "continued"):
            existing = saved.get(str(side), {}).get(variant)
            if existing and (TASK / existing["checkpoint"]).is_file() and checksum(TASK / existing["checkpoint"]) == existing["sha256"]:
                candidates[variant] = existing
            else:
                candidates[variant] = fit(prior, side, variant, train_x, val_x, examples,
                                          out / "experiments" / f"{side}-{variant}")
            write_json(lock, report)
        best_psnr = max(m["psnr"] for m in candidates.values())
        best_ssim = max(m["ssim"] for m in candidates.values())
        eligible = [key for key, m in candidates.items()
                    if m["psnr"] >= best_psnr - .25 and m["ssim"] >= best_ssim - .003]
        choice = min(eligible, key=lambda k: candidates[k]["local_detail_mae"]) if eligible else "previous"
        report["selected"][str(side)] = {"candidate": choice, **candidates[choice]}
        write_json(lock, report)
    report["selection_final"] = True
    write_json(lock, report)


if __name__ == "__main__":
    main()
