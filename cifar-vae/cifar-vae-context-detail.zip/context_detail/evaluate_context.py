"""Evaluate the two validation-locked VAEs against the previous release on CIFAR-10.

Run from task5 after training:
    python context_detail/evaluate_context.py
The results directory contains metrics.json, per-image.npz, two reconstruction
figures, and direct-prior sample grids with a separate real-image reference.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "paper_detail"))
sys.path.insert(0, str(ROOT))
from cifar_data import CLASS_NAMES, load_split
from detail.evaluate_detail import CROPS, METRICS, ZH_CLASSES, font_for_figures, to_pil
from evaluate_paper import save_figures, score, score_pairs
from paper_model import load_paper_model


PRIOR_COUNT = 32
PRIOR_SEED = 2026


def read_selection(path):
    report = json.loads(path.read_text(encoding="utf-8"))
    if report.get("selection_final") is not True:
        raise ValueError(f"Both models must be locked on validation before evaluation: {path}")
    selected = {}
    for side in (8, 16):
        spec = report["selected"][str(side)]
        checkpoint = ROOT / spec["checkpoint"]
        if hashlib.sha256(checkpoint.read_bytes()).hexdigest() != spec["sha256"]:
            raise ValueError(f"Checkpoint differs from its locked digest: {checkpoint}")
        selected[side] = spec
    return selected


@torch.inference_mode()
def draw_prior(model, side, device):
    generator = torch.Generator(device="cpu").manual_seed(PRIOR_SEED)
    z = torch.randn((PRIOR_COUNT, 4, side, side), generator=generator, dtype=torch.float32)
    images = model.decode(z.to(device)).cpu()
    if images.shape != (PRIOR_COUNT, 3, 32, 32) or not torch.isfinite(images).all():
        raise ValueError("Decoder produced invalid prior samples")
    return images


def save_prior_grids(groups, out):
    cols, rows, tile, gap = 8, 4, 64, 3
    width = cols * (tile + gap) - gap
    height = rows * (tile + gap) - gap
    font, chinese = font_for_figures()
    captions = {
        "real-reference": ("真实 CIFAR-10 测试图 · 官方顺序前 32 张", "Real CIFAR-10: first 32 test images"),
        "prior8": ("8×8×4 解码器 · 独立标准正态采样", "8x8x4 decoder: standard normal prior"),
        "prior16": ("16×16×4 解码器 · 独立标准正态采样", "16x16x4 decoder: standard normal prior"),
    }
    line, margin = 36, 12
    header = 2 * line
    combined = Image.new("RGB", (width + 2 * margin, header + 3 * (line + height + margin)), "white")
    draw = ImageDraw.Draw(combined)
    notes = (("真实图作独立参照，各面板的图片没有配对关系。",
              f"先验采样种子 {PRIOR_SEED}，每个解码器连续输出 {PRIOR_COUNT} 张。")
             if chinese else ("Real images are an independent, unpaired reference.",
                              f"Prior seed {PRIOR_SEED}, first {PRIOR_COUNT} samples from each decoder."))
    for i, note in enumerate(notes):
        draw.text((margin, (i + 0.5) * line), note, fill="#182b3a", font=font, anchor="lm")
    for panel, (key, title) in enumerate(captions.items()):
        images = groups[key]
        if len(images) != rows * cols:
            raise ValueError(f"Expected exactly {rows*cols} images in {key}")
        grid = Image.new("RGB", (width, height), "white")
        for i, img in enumerate(images):
            patch = to_pil(img).resize((tile, tile), Image.Resampling.NEAREST)
            grid.paste(patch, ((i % cols) * (tile + gap), (i // cols) * (tile + gap)))
        grid.save(out / f"{key}.png", optimize=True)
        y = header + panel * (line + height + margin)
        draw.text((margin, y + line // 2), title[0 if chinese else 1],
                  font=font, anchor="lm", fill="#182b3a")
        combined.paste(grid, (margin, y + line))
    combined.save(out / "prior-comparison.png", optimize=True)


def summarize_crops(examples):
    crops = []
    for cls, index, (x0, y0, x1, y1), _, title in CROPS:
        target = examples["original"][cls, :, y0:y1, x0:x1]
        errors = {}
        for key, reconstructions in examples.items():
            if key != "original":
                region = reconstructions[cls, :, y0:y1, x0:x1]
                errors[key] = (region - target).abs().double().mean().item() * 255
        crops.append(dict(index=index, name=title, box_xyxy=[x0, y0, x1, y1],
                          mean_rgb_abs_error=errors))
    return crops


@torch.inference_mode()
def save_counterexamples(cases, images, labels, releases, batch_size, device, out):
    rows = [(int(k), v) for k, v in cases.items() if v is not None]
    font, chinese = font_for_figures()
    tile, pitch, left, top, row_height = 128, 162, 105, 82, 172
    canvas = Image.new("RGB", (left + 3 * pitch, top + row_height * len(rows) + 16), "white")
    draw = ImageDraw.Draw(canvas)
    title = ("按测试集顺序，每种尺寸首个局部细节误差升高的样本" if chinese
             else "First increased detail error in test order for each latent size")
    if not rows:
        title = "同一测试集上没有样本的局部细节误差升高" if chinese else "No test image had increased detail error"
    draw.text((12, 22), title, font=font, fill="#182b3a", anchor="lm")
    if rows:
        headers = ("原图", "上轮", "本轮") if chinese else ("Original", "Previous", "Current")
        for column, label in enumerate(headers):
            draw.text((left + (column + .5) * pitch, top - 21), label, font=font, fill="#182b3a", anchor="mm")
    for row, (side, case) in enumerate(rows):
        index = case["index"]
        y = top + row * row_height
        name = (ZH_CLASSES if chinese else CLASS_NAMES)[labels[index]]
        for offset, text in enumerate((f"{side}×{side}×4", f"#{index}", name)):
            draw.text((12, y + 34 + offset * 30), text, font=font, fill="#182b3a", anchor="lm")
        start = index // batch_size * batch_size
        batch = images[start:start + batch_size].to(device=device, dtype=torch.float32) / 255
        shown = [batch[index - start]]
        for _, specs, loader in releases:
            model = loader(ROOT / specs[side]["checkpoint"], device).eval()
            shown.append(model.decode(model.encode(batch)[0])[index - start])
        for column, frame in enumerate(shown):
            center = int(left + (column + .5) * pitch)
            patch = to_pil(frame).resize((tile, tile), Image.Resampling.NEAREST)
            canvas.paste(patch, (center - tile // 2, y))
            if column:
                metric = case["previous_detail_mae"] if column == 1 else case["current_detail_mae"]
                caption = f"细节误差 {metric:.3f}" if chinese else f"Detail MAE {metric:.3f}"
                draw.text((center, y + tile + 18), caption, font=font, fill="#182b3a", anchor="mm")
    canvas.save(out / "counterexamples.png", optimize=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data")
    parser.add_argument("--previous", type=Path, default=ROOT / "paper_detail/validation.json")
    parser.add_argument("--selection", type=Path, default=HERE / "validation.json")
    parser.add_argument("--out", type=Path, default=HERE / "results")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=256)
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("Batch size must be positive")

    previous, current = read_selection(args.previous), read_selection(args.selection)
    from context_model import load_context_model

    torch.set_num_threads(min(8, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    pixels, labels = load_split(args.data, train=False)
    if len(pixels) != 10000:
        raise ValueError("Expected all 10,000 official CIFAR-10 test images")
    indices = [int(np.flatnonzero(labels == i)[0]) for i in range(10)]
    if any(indices[cls] != idx for cls, idx, *_ in CROPS):
        raise ValueError("The predeclared image indices do not match this test split")
    x = torch.from_numpy(pixels)
    examples = {"original": x[indices].float() / 255}
    grids = {"real-reference": x[:PRIOR_COUNT].float() / 255}
    summary = dict(n=len(x), split="official CIFAR-10 test", device=args.device, torch=str(torch.__version__),
                   batch_size=args.batch_size, metrics=list(METRICS), deterministic_reconstruction="posterior mean",
                   indices=indices, classes=list(CLASS_NAMES), models={}, paired={}, counterexamples={},
                   counterexample_rule="First image in official order with increased local_detail_mae, if any.",
                   prior={"seed": PRIOR_SEED, "count_per_model": PRIOR_COUNT, "prior": "independent standard normal",
                          "generator": "torch.float32 CPU randn, generator reset for each latent size",
                          "reference_indices": list(range(PRIOR_COUNT)), "matched_reference": False,
                          "within_grid_order": "consecutive, row-major, unfiltered"},
                   )
    individual = {}
    releases = (("previous", previous, load_paper_model), ("current", current, load_context_model))
    for release, specs, loader in releases:
        for side, spec in specs.items():
            key = f"{release}{side}"
            model = loader(ROOT / spec["checkpoint"], args.device).eval()
            if model.side != side:
                raise ValueError(f"Unexpected model architecture in {spec['checkpoint']}")
            values, examples[key] = score(model, x, indices, args.device, args.batch_size)
            individual[key] = values
            avg = dict(zip(METRICS, values.mean(0, dtype=np.float64).tolist()))
            summary["models"][key] = dict(checkpoint=spec["checkpoint"], sha256=spec["sha256"], metrics=avg)
            if release == "current":
                grids[f"prior{side}"] = draw_prior(model, side, args.device)
            print(f"{key}: {json.dumps(avg)}", flush=True)

    col = METRICS.index("local_detail_mae")
    for side in (8, 16):
        a, b = individual[f"previous{side}"], individual[f"current{side}"]
        summary["paired"][str(side)] = score_pairs(a, b)
        worse = np.flatnonzero(b[:, col] > a[:, col])
        counterexample = None
        if len(worse):
            idx = int(worse[0])
            counterexample = dict(index=idx, class_name=CLASS_NAMES[labels[idx]],
                                  previous_detail_mae=float(a[idx, col]), current_detail_mae=float(b[idx, col]))
        summary["counterexamples"][str(side)] = counterexample

    summary["crops"] = summarize_crops(examples)
    args.out.mkdir(parents=True, exist_ok=True)
    save_figures(examples, CROPS, args.out)
    save_counterexamples(summary["counterexamples"], x, labels, releases, args.batch_size, args.device, args.out)
    save_prior_grids(grids, args.out)
    np.savez_compressed(args.out / "per-image.npz", **individual)
    temp = args.out / "metrics.json.tmp"
    temp.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temp.replace(args.out / "metrics.json")


if __name__ == "__main__":
    main()
