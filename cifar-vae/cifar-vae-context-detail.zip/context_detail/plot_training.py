"""Plot the forty additional training epochs for the two matched branches per size."""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent


def main():
    fig, axes = plt.subplots(1, 2, figsize=(8.5, 3.45), constrained_layout=True)
    handles = []
    for side, color in ((16, "#126f73"), (8, "#a64a1f")):
        for variant, name, linestyle in (("continued", "continued", "--"), ("context", "context", "-")):
            path = HERE / "experiments" / f"{side}-{variant}" / "history.csv"
            with path.open(encoding="utf-8") as stream:
                rows = list(csv.DictReader(stream))
            epochs = [int(row["extra_epoch"]) + 80 for row in rows]
            if epochs != list(range(81, 121)):
                raise ValueError(f"Incomplete training history in {path}")
            for ax, key, title in zip(axes, ("train_mse", "kl_per_pixel"),
                                      ("Training reconstruction MSE", "Training KL / 3,072")):
                line, = ax.plot(epochs, [float(row[key]) for row in rows], color=color, ls=linestyle,
                                lw=1.75, label=f"{side}×{side} {name}")
                ax.set_title(title, loc="left")
            handles.append(line)
    for ax in axes:
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", alpha=.18)
        ax.set_xlabel("Total training epochs")
        ax.set_xlim(81, 120)
    fig.legend(handles=handles, loc="outside lower center", ncols=4, frameon=False, fontsize=9)
    out = HERE / "results"
    out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / "training-curves.png", dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()
