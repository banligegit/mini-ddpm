# CIFAR-10 VAE 同图重建与直接采样

[网页同图比较](https://banligegit.github.io/mini-ddpm/cifar-vae/#comparison) · [网页先验样本](https://banligegit.github.io/mini-ddpm/cifar-vae/#priors) · [三页报告](cifar-vae-current-report.pdf)

## 怎么核对老师的要求

| 想看什么 | 到哪里看 |
|---|---|
| 同一张原始 CIFAR-10 照片的两种压缩效果 | 报告第 2 页每列固定同一张图。网页默认显示卡车，可更换类别、尺寸并同步查看同一处像素。[十类整图](results/full-comparison.png) · [三处细节](results/crop-comparison.png) |
| 调整模型是否有效 | 报告第 1 页列有原结构等预算续训与新增卷积块的验证对照，第 2 页列有官方测试结果。[5,000 张验证记录](validation.json) · [10,000 张测试记录](results/metrics.json) · [逐张指标](results/per-image.npz) |
| 直接抽样的真实效果 | 报告第 3 页与网页先验页使用入选的同一对解码器。种子 2026，每组连续取 32 张，按行原序展示；真实照片取官方顺序前 32 张，供观察物体结构。[完整三组网格](results/prior-comparison.png) |
| 结构、损失和训练过程 | [网络](context_model.py)使用低分辨率残差块，编码端输出 μ、log σ²，只有四通道 z 交给解码器。[训练入口](train_context.py)与 ZIP 中的 `detail/train_detail.py` 保存每轮 MSE、KL / 3,072、高通项、加权总损失及耗时。β=0.003 对两种尺寸相同。[两种尺寸的训练曲线](results/training-curves.png) |
| 下一题用哪一份 | 题六从 8×8×4 开始。和 16×16×4 相比，潜张量元素数为四分之一。使用本轮 8×8 的训练集 μ 统计做逐通道标准化。[缩放常量](calibration/channel-statistics.json) · [5,000 张验证往返](calibration/roundtrip.json) |

## 如何理解这次改动

上轮模型已经把每个像素块的不同位置分到不同通道，再重排回原图。这次在潜变量网格的特征层看到更远的邻居，希望同一根窗框、同一段船舷能还原得连贯。编码和解码支路各用三个残差块，膨胀率依次为 1、2、1，各块的末层从零开始。在续训第一步前，程序逐元素检查新旧模型的 μ、log σ² 和重建完全一致。小窗放大使用最近邻，图像保持原来的 32×32 个像素。[扩张卷积的原论文](https://arxiv.org/abs/1511.07122) · [变分自编码器原论文](https://arxiv.org/abs/1312.6114)

固定训练集 45,000 张、验证集 5,000 张，原结构续训与新增结构都从上轮第 80 轮的权重开始，增加 40 轮（7,040 次更新），相同 Adam、余弦学习率、batch size 256、样本顺序和后验噪声种子。比较的是同更新次数下的重建效果，加深模型也增加了参数和计算量。每个尺寸各按验证决策锁定权重，再评估官方测试集。历次任务使用过这份官方测试集，最新一轮未根据它挑选候选权重。四个续训分支各自的训练记录和权重存放在 `experiments/`；上一轮入选权重随包附在 `paper_detail/experiments/`。

原图的高频起伏有大有小。补充记录按原图自身的局部高通绝对值均值，将 10,000 张测试图从低到高均分四组，每组 2,500 张；每张在组内对齐比较上轮和本轮的误差。分组由原图像素决定。[按原图细节分组](results/texture-quartiles.json)

## 实测效果

| 潜变量 | 测试 PSNR，上轮 → 本轮 | SSIM，上轮 → 本轮 | 局部细节误差，上轮 → 本轮 | 误差下降张数 |
|---|---:|---:|---:|---:|
| 16×16×4 | 33.86 → 35.01 dB | 0.9750 → 0.9796 | 3.172 → 2.681（降 15.47%） | 9,426 / 10,000 |
| 8×8×4 | 26.64 → 26.90 dB | 0.8712 → 0.8778 | 7.007 → 6.816（降 2.74%） | 9,733 / 10,000 |

16×16 在原图局部起伏最大的四分之一上，平均细节误差下降 20.17%，最平滑的四分之一下降 6.49%。8×8 的四组降幅均在 2.62%–2.88% 之间。卡车窗框裁切中，16×16 的 RGB 误差从 5.59 降至 4.41，8×8 从 15.46 微升至 15.50。测试顺序里首个整图细节误差回退的实例分别是 16×16 的鹿 #22 和 8×8 的飞机 #21。[回退图](results/counterexamples.png)

16×16 原结构续训和新结构的验证 PSNR 分别是 34.796、35.003 dB，SSIM 均约 0.97958。8×8 两者分别是 26.732、26.885 dB。新结构相比同更新次数的原结构各增加 61,824 个参数。本机逐轮日志的训练时间之和约为 16×16 原结构 140 秒、新结构 235 秒，8×8 分别为 139 秒、262 秒；这不包含初始化和验证。

## 复现

在解压根目录运行以下命令。数据是 [CIFAR-10 官方 Python 包](https://cave.cs.toronto.edu/kriz/cifar.html)，首次运行会下载并校验，也可把已有的 `cifar-10-python.tar.gz` 放进 `data/`。记录环境为 Python 3.11、PyTorch 2.14、NumPy 2.4、Pillow 12.3。CPU 同样能评估；原训练使用 RTX 4060 Laptop GPU。

```powershell
python -m pip install torch numpy Pillow
python context_detail/evaluate_context.py --device cpu --out replay/test
python context_detail/detail_by_texture.py --results replay/test
```

如需重训本轮四个分支，下面的命令写入单独目录。训练所需的两份起始权重、上一轮验证记录和固定训练/验证切分已随包提供。新跑的结果可通过 `--selection replay/fit/validation.json` 传递给评估。

```powershell
python context_detail/train_context.py --device cuda --out replay/fit
python context_detail/evaluate_context.py --device cuda --selection replay/fit/validation.json --out replay/retrained-test
```

用实测交付的 8×8 权重重新计算题六的逐通道统计。用 `FrozenLatents(..., model_loader=load_context_model)` 加载编码器与其匹配的 JSON；读取时会核对权重摘要。

```powershell
$selection = Get-Content context_detail/validation.json -Raw | ConvertFrom-Json
python context_detail/calibrate_context.py --checkpoint $selection.selected.'8'.checkpoint --device cpu --out replay/calibration
```

如需重印报告，额外安装 Playwright 和 Chromium，再运行 `python context_detail/make_report.py`，也可以用 `--chrome` 指定已安装 Chrome 的路径。导出网页额外需要 onnx、onnxruntime，在 [网页源码](https://github.com/banligegit/mini-ddpm) 对应的已有 `site/cifar-vae` 目录上运行 `python context_detail/export_context_web.py --output <site/cifar-vae目录>`。导出器会核查原图、权重指纹，以及 ONNX 重建和 PyTorch 的误差。

[此前三组 β 的对照和初版模型](https://banligegit.github.io/mini-ddpm/cifar-vae/)在网页的历史实验中保留。
