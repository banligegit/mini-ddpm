"""Build and integrity-check the portable task-5 experiment archive."""
import hashlib
import json
from pathlib import Path
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def main():
    validation = json.loads((HERE / "validation.json").read_text(encoding="utf-8"))
    old = json.loads((ROOT / "paper_detail/validation.json").read_text(encoding="utf-8"))
    if not validation["selection_final"]:
        raise ValueError("Validation selection is not yet final")
    files = {ROOT / name for name in (
        "model.py", "train.py", "evaluate.py", "appearance.py", "cifar_data.py", "export_web.py",
        "detail/calibrate.py", "detail/train_detail.py", "detail/evaluate_detail.py",
        "latent_diagnostics/latent_io.py", "refinement/beta/split.npz",
        "paper_detail/validation.json", "paper_detail/train_paper.py", "paper_detail/evaluate_paper.py",
        "paper_detail/paper_model.py", "paper_detail/make_note.py")}
    for side in ("8", "16"):
        for spec in (validation["selected"][side], old["selected"][side]):
            ckpt = ROOT / spec["checkpoint"]
            if hashlib.sha256(ckpt.read_bytes()).hexdigest() != spec["sha256"]:
                raise ValueError(f"Checkpoint verification failed for {ckpt}")
            files.update((ckpt, ckpt.parent / "history.csv"))
    for pattern in ("*.py", "README.md", "report-observations.json", "cifar-vae-current-report.pdf",
                    "validation.json", "validation-original.png", "experiments/*/*.pt",
                    "experiments/*/*.csv", "experiments/*/*.png", "results/*.json",
                    "results/*.npz", "results/*.png", "calibration/*.json"):
        paths = list(HERE.glob(pattern))
        if not paths:
            raise FileNotFoundError(f"Missing results for {pattern}")
        files.update(paths)
    archive = ROOT / "cifar-vae-context-detail.zip"
    with tempfile.NamedTemporaryFile(dir=ROOT, suffix=".zip", delete=False) as temp:
        staged = Path(temp.name)
    try:
        with ZipFile(staged, "w", compression=ZIP_DEFLATED, compresslevel=6) as z:
            z.writestr("README.md", "# CIFAR-10 VAE · 题目五\n\n[实验报告](context_detail/cifar-vae-current-report.pdf)"
                       "　·　[指标、图片与复现命令](context_detail/README.md)\n")
            for file in sorted(files):
                z.write(file, file.relative_to(ROOT).as_posix())
        with ZipFile(staged) as z:
            if z.testzip() is not None:
                raise ValueError("Archive CRC verification failed")
        staged.replace(archive)
    finally:
        staged.unlink(missing_ok=True)
    print(f"{archive}\n{archive.stat().st_size:,} bytes\nSHA-256 {hashlib.sha256(archive.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
