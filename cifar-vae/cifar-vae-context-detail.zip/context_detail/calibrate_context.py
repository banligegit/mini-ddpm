"""Fit posterior-mean normalization for the selected 8x8 context experiment."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from context_model import load_context_model
from detail.calibrate import main

if __name__ == "__main__":
    main(model_loader=load_context_model, default_out=HERE / "calibration")
