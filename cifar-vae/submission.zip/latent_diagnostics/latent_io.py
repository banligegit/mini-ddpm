"""Interface for a diffusion model trained on normalized CIFAR-10 posterior means."""

import hashlib
import json
import sys
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from model import load_model


class FrozenLatents:
    """RGB [0,1] <-> standardized [B,4,8,8] posterior means."""

    def __init__(self, device="cpu", checkpoint=HERE.parent / "runs/vae8.pt",
                 statistics=HERE / "results.json", model_loader=load_model):
        checkpoint = Path(checkpoint)
        stats = json.loads(Path(statistics).read_text(encoding="utf-8"))
        if hashlib.sha256(checkpoint.read_bytes()).hexdigest() != stats["checkpoint_sha256"].lower():
            raise ValueError("The training-set statistics belong to a different checkpoint")
        self.vae = model_loader(checkpoint, device).requires_grad_(False)
        channels = stats["splits"]["train"]["distributions"]["mu"]["channels"]
        self.mean = torch.tensor([c["mean"] for c in channels], device=device).view(1, 4, 1, 1)
        self.std = torch.tensor([c["std"] for c in channels], device=device).view(1, 4, 1, 1)
        if not (self.std.isfinite() & (self.std > 0)).all():
            raise ValueError("Invalid training-set channel scales")

    @torch.no_grad()
    def encode(self, images):
        """Accept float RGB in [0,1] on the chosen device, ready for diffusion training."""
        mu, _ = self.vae.encode(images)
        return (mu - self.mean) / self.std

    @torch.no_grad()
    def decode(self, normalized):
        """Invert train-set scaling, then decode the predicted clean latents to RGB."""
        return self.vae.decode(normalized * self.std + self.mean)
