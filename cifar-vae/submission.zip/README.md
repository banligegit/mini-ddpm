# CIFAR-10 VAE · 原图与两种压缩尺寸

公开网页只提供一套结果。每个潜空间尺寸各保留一份通过验证集选出的权重。网页中三张重建对照图对应同一张 CIFAR-10 测试图，局部放大也共用一个位置。[在线查看](https://banligegit.github.io/mini-ddpm/cifar-vae/#comparison) · [三页报告](https://banligegit.github.io/mini-ddpm/cifar-vae/report.pdf)

以下文件名和命令均相对于提交包的解压根目录。报告位于 `gated_detail/report.pdf`。选中的两份 PyTorch 权重路径及 SHA-256 在 `gated_detail/final-selection.json` 的 `selected` 字段。潜变量形状在论文习惯下记为 16×16×4 或 8×8×4，在 PyTorch 中对应 [B, 4, 16, 16] 或 [B, 4, 8, 8]。

## 用随包权重复核

实验环境为 Python 3.11、PyTorch 2.14、NumPy 2.4、Pillow 12.3、RTX 4060 Laptop GPU。训练采用 CUDA；下列命令可以在 CPU 上执行。在自己的 Python 环境安装 PyTorch、NumPy 和 Pillow。首次运行会自动下载、校验 CIFAR-10，或把已有的 `cifar-10-python.tar.gz` 放进 `data/`。

```powershell
python -m pip install torch numpy Pillow
python gated_detail/evaluate_gated.py --selected-only --device cpu --out replay/test
python gated_detail/check_gates.py --device cpu --out replay/gates.json
```

第一条评估命令用随包的两份权重跑官方 10,000 张测试图，在 `replay/test` 下生成逐图指标、平均 PSNR/SSIM、原图配对的整图和裁切图，以及每种尺寸 32 张未筛选的先验样本。第二条命令在验证集重复报告第 1 页的通道注意力检查。

## 复现训练与同预算比较

训练时只读取官方训练集内部固定的 45,000 / 5,000 划分。从每种尺寸各自的第 120 轮权重出发，分别试原结构续训、加局部卷积与通道注意力续训，两支都增加 30 轮。下列第一条命令从项目固定历史提交恢复这次实验的两个训练起点，核对归档和两份权重的 SHA-256；平时只做最终评估可跳过。

```powershell
python gated_detail/fetch_parents.py
python gated_detail/evaluate_gated.py --device cpu --out replay/paired-test
python gated_detail/train_gated.py --device cuda --out replay/fit
python gated_detail/blend_gated.py --device cuda --out replay/fit
python gated_detail/evaluate_gated.py --device cuda --selection replay/fit/final-selection.json --out replay/retrained-test
```

训练与验证选型由 `gated_detail/train_gated.py` 实现。每组均为 Adam、种子 2026、batch 256、5,280 次更新；学习率从 0.0008 余弦下降到 0.00008。训练用 z = μ + exp(ℓ/2) ⊙ ε，测试重建用 μ。重建 MSE 按 RGB 平均；各潜坐标 KL 先求和，再除以 RGB 元素数 3,072；β 固定为 0.003。另加权 0.075 的 3×3 高通误差。四个分支的逐轮训练 MSE、归一化 KL、高通误差、总损失及耗时均保存为 `gated_detail/experiments/*/history.csv`。模型初始化时核对新增分支的输出与原模型一致。

受权重平均研究启发，在同一起点的两个已训练分支之间追加 t=0.25、0.50、0.75 三个固定插值。共有参数线性插值；新支路内部参数使用训练好的值，末端投影权重与偏置乘 t。脚本验证 t=0 和 1 对应两份原模型。第一轮结果记录在 `gated_detail/validation.json`。只有插值版的验证 PSNR、SSIM 都达到训练起点及第一轮入选者中的较高值，同时细节误差达到较低值，才替换第一轮权重。三个中间比例在两个尺寸均未达到此门槛。[Model Soups](https://proceedings.mlr.press/v162/wortsman22a.html)

| 潜空间 | 测试 PSNR，上次 → 本次 | SSIM，上次 → 本次 | 局部细节误差，上次 → 本次 |
|---|---:|---:|---:|
| 16×16×4 | 35.014 → 35.044 dB | 0.97960 → 0.97859 | 2.681 → 2.612 |
| 8×8×4 | 26.898 → 27.041 dB | 0.87782 → 0.88129 | 6.816 → 6.715 |

16×16 的细节误差低于此前权重，但整体结构相似度及平均颜色误差有小幅退步。文中“最优”指按公开的验证规则为每种尺寸选出的一份，符合优先保留局部细节的目标。最初的训练候选和之后的锁定权重都测过同一套官方测试集。三个插值系数的比较和晋级判断只读取验证集。

把门值从逐图自适应改用固定的训练均值，16×16 的验证 PSNR 由 35.029 降至 34.848 dB，但细节误差由 2.6158 微降到 2.6147。8×8 的 PSNR 只由 27.030 降到 27.028 dB。由此可见，在当前权重上，不能把所有纹理收益都归于推理时的门控；新增局部卷积与额外训练也参与了重建。

## 图、数据和题目六

- 实测数字和逐图记录在 `gated_detail/results/metrics.json`、`per-image.npz`。颜色统计衡量全图平均颜色的偏差，轮廓统计衡量分块后相邻梯度的差异，细节统计衡量像素与邻域均值之差的重建误差。高频细节按原图像素起伏分组的结果在 `texture-quartiles.json`。
- 网页与报告使用 `selected-full.png`、`selected-crops.png`。完整先验对照是 `prior-comparison.png`。每组归档图使用 PyTorch CPU 种子 2026 连续抽样，真实参考为官方测试顺序前 32 张。网页的交互种子由浏览器内的随机数生成器处理，两端的同一个数值种子可以给出不同的噪声张量。
- `gated_detail/gate-diagnostic.json` 保存用 2,048 张训练图估算通道均值后，在 5,000 张验证图上将逐图权重改为常数的结果。这个干预保持其他网络权重相同，可描述推理时的作用；“新分支比续训好多少”同时包含新增局部卷积与可训练参数的贡献。训练只使用一个种子。
- 题六采用 8×8×4。编码时依据 `gated_detail/calibration/channel-statistics.json` 对 μ 逐通道标准化，解码前反变换。训练集缩放常量与入选 8×8 权重按摘要绑定；验证集往返记录在同目录 `roundtrip.json`。如需重算，PowerShell 命令如下。

```powershell
$selected = (Get-Content gated_detail/final-selection.json -Raw | ConvertFrom-Json).selected.'8'
python gated_detail/calibrate_gated.py --checkpoint $selected.checkpoint --device cpu --out replay/calibration
```

网页导出需要额外安装 onnx、onnxruntime。报告排版脚本使用 Playwright 和 Chromium，打印已提供的实测记录可运行 `python gated_detail/make_report.py`（也可通过 `--chrome` 指定本地 Chrome）。[网页源代码与部署说明](https://github.com/banligegit/mini-ddpm)

VAE 主干沿用本项目此前实现；本轮按通道重新加权卷积特征的思路参考 Zhang 等的 RCAN 与 Hu 等的 SE。卷积块、权重迁移、训练与验证、逐图指标、通道干预和网页导出均在本项目实现。[RCAN](https://arxiv.org/abs/1807.02758) · [SE](https://arxiv.org/abs/1709.01507) · [VAE 原论文](https://arxiv.org/abs/1312.6114) · [CIFAR-10 数据集](https://cave.cs.toronto.edu/kriz/cifar.html)
