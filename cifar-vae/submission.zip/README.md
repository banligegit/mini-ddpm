# CIFAR-10 卷积 VAE · 重建指标优化

实验报告位于 `reconstruction_next/report.pdf`。[打开 GitHub Pages 原图对比](https://banligegit.github.io/mini-ddpm/cifar-vae/)。两份最终 PyTorch 权重列在 `reconstruction_next/final-selection.json` 的 `selected` 中；目录名与训练时一致。解压后应在包含 `cifar_data.py` 的包根目录运行下列命令。

## 复核 10,000 张测试图

安装支持本机 CPU 或 CUDA 的 PyTorch，以及 NumPy、Pillow。第一次运行将下载并核验 CIFAR-10 官方 Python 数据；也可以将已有的 `cifar-10-python.tar.gz` 放进根目录下的 `data/`。无需预先另行下载模型。

```powershell
python reconstruction_next/eval/evaluate_reconstruction.py --selected-only --device cpu --batch-size 64
```

输出在 `reconstruction_next/selected-results/`，其中 `summary.csv` 给出两种尺寸的参数量、PSNR、SSIM 和细节误差。`selected-full.png` 展示按固定索引提取的原图和后验均值重建。`prior16.png` 和 `prior8.png` 是相应解码器对 32 份标准正态样本的直接输出。

每张图片单独计算 RGB MSE 和 PSNR，最后跨图片求平均。SSIM 沿用 11×11 有效高斯窗口。细节误差把两张图各自减去反射填充的 3×3 局部均值，再对两张残差图的差取平均绝对值，换算为 0–255 色阶。指标使用浮点图像，网页和 PNG 仅用于显示。

## 对照上轮基线和重新训练

精简包保留两份最终权重。完整配对评估和重新训练会用到上轮的两份起点；恢复脚本从固定 Git 提交取回它们，并核对整个归档和每份权重的 SHA-256。也可使用 `--archive 路径` 指定上轮提交包。

```powershell
python reconstruction_next/restore_baseline.py
python reconstruction_next/eval/evaluate_reconstruction.py --device cuda
```

配对结果写入 `reconstruction_next/results/`。逐图数据覆盖测试集原顺序的全部 10,000 张，`metrics.json` 含逐项改善数和三项同时改善数。以下命令从恢复的起点重做训练；使用独立输出位置可以保留交付的选型文件。

```powershell
python reconstruction_next/train_next.py --stage screen --device cuda --out replay
python reconstruction_next/train_next.py --stage extend --device cuda --out replay
python reconstruction_next/distill_mean.py --device cuda --out replay
python reconstruction_next/eval/evaluate_reconstruction.py --device cuda --selection replay/final-selection.json --out replay/test
```

三个训练命令只用官方训练集内部同一个 45,000/5,000 划分，随机种子和划分摘要在选型文件中。各尺寸的新增分支必须在验证集上同时守住 PSNR、SSIM 和细节误差，再按局部细节误差选出权重。最终评分采用完整前馈编码器给出的 μ，每张图保留 4×16×16 或 4×8×8 个数。不同 CUDA、PyTorch 版本及设备可能产生数值差异。

## 检查后验和潜空间接口

在 5,000 张验证图上用每张图相同的 ε 对比新旧编码器，用 μ、μ+σ⊙ε 分别重建。

```powershell
python reconstruction_next/check_posterior.py --baseline --device cpu
python reconstruction_next/check_posterior.py --device cpu
$selection = Get-Content -Encoding UTF8 reconstruction_next/final-selection.json -Raw | ConvertFrom-Json
python reconstruction_next/calibrate.py --checkpoint $selection.selected.'8'.checkpoint --device cuda
python reconstruction_next/time_codec.py --device cuda
```

后验检查写入 `diagnostics/`；8×8 新编码器的四通道缩放常数和 5,000 张验证图的往返检查写入 `calibration/`。旧学习先验在生成图片时依然搭配当时训练时的解码器。任务六如从头使用本轮的 8×8 编码器，可直接使用本轮校准。计时结果给出 batch 32 的编码与解码耗时，单位为毫秒。

另在原 16×16 架构上做了 2×2 对照。固定同一训练起点、噪声与打乱种子、学习率、高通权重及 12 轮预算，仅改变 β 和用于随机后验采样的批内比例。每组用最后一轮在 5,000 张验证图上计算相同指标。运行 `python reconstruction_next/ablate_training.py --device cuda` 得到 `diagnostics/ablation.json`。这个对照用于解释训练设置，没有参与最终权重选择。

## 网页、报告和数据

网页现场编码和解码可复用 `reconstruction_next/export_web.py --output <站点输出目录>`（另需 ONNX、ONNX Runtime）。`make_report.py` 从随包附带的实测结果重建 PDF，依赖 Playwright 及本机 Chrome。`package.py` 生成本目录的精简 ZIP。

本项目基于前几版自写的 PyTorch VAE、数据读取和评估代码，保留原始 CIFAR-10 数值范围与指标口径。[VAE 与重参数化](https://arxiv.org/abs/1312.6114) · [CIFAR-10 官方说明](https://www.cs.toronto.edu/~kriz/cifar.html)。

对编码修正的理解可对照两篇工作。Kim 等讨论从编码器的估计出发继续优化单样本的变分参数，Marino 等研究如何让网络学会迭代修正。本轮用训练图的重建残差来预测固定次数的均值修正，具体网络、教师目标和比较均在本项目实现。[Semi-Amortized Variational Autoencoders](https://proceedings.mlr.press/v80/kim18e.html) · [Iterative Amortized Inference](https://proceedings.mlr.press/v80/marino18a.html)
