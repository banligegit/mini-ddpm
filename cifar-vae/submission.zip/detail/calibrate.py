"""Fit per-channel posterior-mean scales and verify the RGB round trip on validation images."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "latent_diagnostics"))
from latent_io import FrozenLatents
from cifar_data import load_split
from model import load_model


@torch.inference_mode()
def main(model_loader=load_model, default_out=HERE / "calibration", out_by_side=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--data", type=Path, default=ROOT / "data")
    parser.add_argument("--out", type=Path, help="Override the default directory for the checkpoint's latent size")
    args = parser.parse_args()
    torch.set_num_threads(min(6, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    model = model_loader(args.checkpoint, args.device)
    if out_by_side is None:
        out_by_side = {8: default_out}
    if model.side not in out_by_side:
        parser.error(f"Expected a checkpoint with latent side in {list(out_by_side)}, got {model.side}")
    output = args.out or out_by_side[model.side]
    split_path = ROOT / "refinement/beta/split.npz"
    with np.load(split_path) as split:
        train, val = split["train"], split["val"]
    pixels = torch.from_numpy(load_split(args.data, train=True)[0])
    totals = torch.zeros(2, 4, device=args.device, dtype=torch.float64)
    for ids in torch.from_numpy(train).split(256):
        x = pixels[ids].to(args.device, dtype=torch.float32) / 255
        mu = model.encode(x)[0].double()
        totals[0] += mu.sum((0, 2, 3))
        totals[1] += mu.square().sum((0, 2, 3))
    mean, second_moment = totals / (len(train) * model.side ** 2)
    std = (second_moment - mean.square()).sqrt()
    channels = [dict(mean=m, std=s) for m, s in zip(mean.tolist(), std.tolist())]
    digest = hashlib.sha256(args.checkpoint.read_bytes()).hexdigest()
    provenance = dict(checkpoint_sha256=digest, side=model.side,
                      split_sha256=hashlib.sha256(split_path.read_bytes()).hexdigest())
    data = {**provenance, "splits": {"train": {
        "images": len(train), "distributions": {"mu": {"channels": channels}}}}}
    output.mkdir(parents=True, exist_ok=True)
    path = output / "channel-statistics.json"
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    codec = FrozenLatents(args.device, args.checkpoint, path, model_loader=model_loader)
    errors = torch.zeros(2, device=args.device)
    for ids in torch.from_numpy(val).split(256):
        x = pixels[ids].to(args.device, dtype=torch.float32) / 255
        mu = model.encode(x)[0]
        normalized = codec.encode(x)
        roundtrip = normalized * codec.std + codec.mean
        rgb_error = (codec.decode(normalized) - model.decode(mu)).abs().max()
        errors = torch.maximum(errors, torch.stack(((roundtrip - mu).abs().max(), rgb_error)))
    if not (errors < 1e-5).all():
        raise ValueError(f"Round trip failed: {errors.tolist()}")
    result = dict(**provenance, validation_images=len(val),
                  max_abs_mu_error=errors[0].item(), max_abs_rgb_error=errors[1].item())
    text = json.dumps(result, indent=2)
    (output / "roundtrip.json").write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
