"""CIFAR-10 VAE with residual context on the latent-resolution feature maps."""
from collections import OrderedDict
from pathlib import Path
import sys

import torch
from torch import nn

TASK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TASK))
from paper_detail.paper_model import ResidualVAE, load_paper_model


class SpatialBlock(nn.Module):
    def __init__(self, dilation):
        super().__init__()
        self.spatial = nn.Conv2d(32, 32, 3, padding=dilation, dilation=dilation)
        self.activation = nn.SiLU()
        self.project = nn.Conv2d(32, 32, 1)
        nn.init.zeros_(self.project.weight)
        nn.init.zeros_(self.project.bias)

    def forward(self, x):
        return x + self.project(self.activation(self.spatial(x)))


def insert_context(layers, after):
    ordered = OrderedDict()
    for key, module in layers.named_children():
        ordered[key] = module
        if key == after:
            ordered["context"] = nn.Sequential(*(SpatialBlock(d) for d in (1, 2, 1)))
    return nn.Sequential(ordered)


class ContextVAE(ResidualVAE):
    def __init__(self, side):
        super().__init__(side)
        self.analysis = insert_context(self.analysis, after="2")
        self.synthesis = insert_context(self.synthesis, after="1")


def load_context_model(checkpoint, device="cpu"):
    record = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if record.get("architecture", "base") != "context":
        return load_paper_model(checkpoint, device)
    model = ContextVAE(record["side"])
    model.load_state_dict(record["state_dict"])
    return model.to(device).eval()
