"""Group the paired test errors by the fine-scale contrast of each ORIGINAL photo."""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
import torch
from torch.nn import functional as F

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from cifar_data import load_split


def summarize_texture(results, data):
    summary = json.loads((results / "metrics.json").read_text(encoding="utf-8"))
    if summary["split"] != "official CIFAR-10 test" or summary["n"] != 10000:
        raise ValueError("Expected the complete paired official test evaluation")
    pixels, _ = load_split(data, train=False)
    torch.set_num_threads(min(6, torch.get_num_threads()))
    strength = []
    for batch in torch.from_numpy(pixels).split(128):
        image = batch.float()
        local_mean = F.avg_pool2d(F.pad(image, (1, 1, 1, 1), mode="reflect"), 3, stride=1)
        strength.append((image - local_mean).abs().mean((1, 2, 3)).numpy())
    strength = np.concatenate(strength)
    # Group membership uses only the source pixels, with ties resolved in test order.
    groups = np.array_split(np.argsort(strength, kind="stable"), 4)
    out = {"definition": "Original RGB minus its 3x3 reflect-padded local mean, mean absolute value (0-255); "
                         "four equal groups sorted by original fine-scale contrast.",
           "split": summary["split"], "quartiles": []}
    col = summary["metrics"].index("local_detail_mae")
    with np.load(results / "per-image.npz") as values:
        for index, ids in enumerate(groups, 1):
            row = {"quartile": index, "images": len(ids), "source_range": [
                float(strength[ids[0]]), float(strength[ids[-1]])], "models": {}}
            for side in ("16", "8"):
                before, after = (values[k + side][ids, col].astype(np.float64) for k in ("previous", "current"))
                row["models"][side] = {
                    "previous": float(before.mean()), "current": float(after.mean()),
                    "relative_reduction_percent": float(100 * (1 - after.mean() / before.mean())),
                    "improved_images": int((after < before).sum())}
            out["quartiles"].append(row)
    path = results / "texture-quartiles.json"
    path.write_text(json.dumps(out, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=HERE / "results")
    parser.add_argument("--data", type=Path, default=HERE.parent / "data")
    args = parser.parse_args()
    summarize_texture(args.results, args.data)


if __name__ == "__main__":
    main()
