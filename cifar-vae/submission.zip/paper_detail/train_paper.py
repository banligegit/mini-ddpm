"""Paired, equal-update fine-tuning of the previous 60-epoch CIFAR VAE checkpoints."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np
import torch

from paper_model import ConvVAE, ResidualVAE, load_paper_model
from appearance import appearance_errors
from cifar_data import load_split
from detail.train_detail import BATCH, BETA, WEIGHT, SEED, highpass_l1, write_json
from evaluate import save_grid, ssim_per_image

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
EPOCHS = 20
LR = 0.0008
FFL_WEIGHT = 0.5


def focal_frequency_loss(error):
    """Jiang et al., alpha=1, patch factor 1, dynamic weights per image/channel."""
    spectrum = torch.fft.fft2(error.float(), norm="ortho")
    squared = spectrum.real.square() + spectrum.imag.square()
    with torch.no_grad():
        amplitude = squared.sqrt()
        weight = amplitude / amplitude.amax(dim=(-2, -1), keepdim=True).clamp_min(1e-12)
    return (weight * squared).mean()


def finetune(model, opt, scheduler, train_x, shuffle, use_frequency):
    device = train_x.device
    mixed = device.type == "cuda" and torch.cuda.is_bf16_supported()
    history = []
    for epoch in range(1, EPOCHS + 1):
        start = time.perf_counter()
        sums = torch.zeros(5, dtype=torch.float64, device=device)
        order = torch.randperm(len(train_x), generator=shuffle).to(device)
        for idx in order.split(BATCH):
            x = train_x[idx].to(dtype=torch.float32, memory_format=torch.channels_last).div_(255)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device.type, dtype=torch.bfloat16, enabled=mixed):
                recon, mu, lv = model(x)
            err = recon.float() - x
            mse = err.square().mean()
            kl = .5 * (mu.square() + lv.exp() - 1 - lv).flatten(1).sum(1).mean() / 3072
            hp = highpass_l1(err)
            ffl = focal_frequency_loss(err) if use_frequency else err.new_zeros(())
            loss = mse + BETA * kl + WEIGHT * hp + FFL_WEIGHT * ffl
            loss.backward()
            opt.step()
            scheduler.step()
            sums += torch.stack([mse, kl, hp, ffl, loss]).detach() * len(idx)
        values = (sums / len(train_x)).tolist()
        if not all(math.isfinite(v) for v in values):
            raise ValueError("Nonfinite training objective")
        history.append((epoch, *values, time.perf_counter() - start))
        if epoch in (1, 10, EPOCHS):
            print(f"{model.side}x{model.side} frequency={use_frequency} epoch={epoch} "
                  f"MSE={values[0]:.6f} time={history[-1][-1]:.2f}s", flush=True)
    return history


@torch.inference_mode()
def validate(model, pixels, examples, device, figure):
    model.eval()
    totals = torch.zeros(6, dtype=torch.float64, device=device)
    for raw in pixels.split(BATCH):
        x = raw.to(device=device, dtype=torch.float32) / 255
        y = model.decode(model.encode(x)[0])
        mse = (x - y).square().mean(dim=(1, 2, 3))
        scores = torch.cat([mse[:, None], -10 * mse.log10()[:, None],
                            ssim_per_image(x, y)[:, None], appearance_errors(x, y)], dim=1)
        totals += scores.sum(0, dtype=torch.float64)
    save_grid(model.decode(model.encode(examples)[0]), figure)
    names = ("mse", "psnr", "ssim", "color_mae", "coarse_edge_mae", "local_detail_mae")
    return dict(zip(names, (totals / len(pixels)).tolist()))


def relpath(path):
    return (path.relative_to(TASK) if path.is_relative_to(TASK) else path).as_posix()


def train(side, variant, prior, train_pixels, val_pixels, examples, args):
    device = train_pixels.device
    torch.manual_seed(SEED)
    base = load_paper_model(prior)
    if variant == "continued":
        model = base
    else:
        model = ResidualVAE(side)
        model.encoder.load_state_dict(base.encoder.state_dict())
        model.decoder.load_state_dict(base.decoder.state_dict())
        example = examples[:4].cpu()
        with torch.no_grad():
            m0, v0 = base.encode(example)
            m1, v1 = model.encode(example)
            if not (torch.equal(m0, m1) and torch.equal(v0, v1)
                    and torch.equal(base.decode(m0), model.decode(m1))):
                raise RuntimeError("Residual initialization changed the reference function")
    model = model.to(device=device, memory_format=torch.channels_last).train()
    # Reset both order and posterior draws after model construction, which
    # consumes a different number of random draws in the residual branch.
    torch.manual_seed(SEED)
    shuffle = torch.Generator().manual_seed(SEED)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, T_max=EPOCHS * math.ceil(len(train_pixels)/BATCH), eta_min=LR / 10)
    history = finetune(model, opt, scheduler, train_pixels, shuffle, variant == "paper_ffl")
    dest = args.out / "experiments" / f"{side}-{variant}"
    dest.mkdir(parents=True, exist_ok=True)
    with (dest / "history.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(("extra_epoch", "train_mse", "kl_per_pixel", "highpass_l1", "focal_frequency_loss", "total", "seconds"))
        w.writerows(history)
    ckpt = dest / f"vae{side}.pt"
    tmp = ckpt.with_suffix(".tmp")
    torch.save({"side": side, "architecture": "base" if variant == "continued" else "residual",
                "state_dict": {k: v.cpu() for k,v in model.state_dict().items()},
                "config": {"parent_sha256": hashlib.sha256(prior.read_bytes()).hexdigest(),
                           "extra_epochs": EPOCHS, "beta": BETA, "highpass": WEIGHT,
                           "frequency_weight": FFL_WEIGHT if variant == "paper_ffl" else 0.,
                           "seed": SEED, "train_images": len(train_pixels), "lr": LR}}, tmp)
    tmp.replace(ckpt)
    with torch.backends.cudnn.flags(enabled=torch.backends.cudnn.enabled,
                                    benchmark=torch.backends.cudnn.benchmark,
                                    deterministic=torch.backends.cudnn.deterministic, allow_tf32=False):
        metrics = validate(load_paper_model(ckpt, device), val_pixels, examples,
                           device, dest / "validation-examples.png")
    metrics.update(checkpoint=relpath(ckpt), sha256=hashlib.sha256(ckpt.read_bytes()).hexdigest(),
                   parameters=sum(p.numel() for p in model.parameters()))
    print(f"{side} {variant} validation {metrics}", flush=True)
    return metrics


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", type=Path, default=TASK / "data")
    p.add_argument("--out", type=Path, default=HERE)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--resume", action="store_true", help="Reuse checksum-verified completed variants")
    args = p.parse_args()
    args.out = args.out.resolve()
    args.out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(min(8, torch.get_num_threads()))
    prev = json.loads((TASK / "detail/validation.json").read_text(encoding="utf-8"))
    arr, labels = load_split(args.data, train=True)
    with np.load(TASK / "refinement/beta/split.npz") as split:
        tr, va = split["train"], split["val"]
    train_x = torch.from_numpy(arr[tr]).to(args.device)
    val_x = torch.from_numpy(arr[va])
    idx = [int(va[labels[va] == k][0]) for k in range(10)]
    examples = torch.from_numpy(arr[idx]).float().to(args.device) / 255
    del arr
    save_grid(examples, args.out / "validation-original.png")
    report = {"initial_epochs": 60, "extra_epochs": EPOCHS, "updates_per_variant": EPOCHS * math.ceil(len(tr)/BATCH),
              "beta": BETA, "highpass": WEIGHT, "initial_lr": LR, "final_lr": LR / 10,
              "seed": SEED, "train_images": len(tr), "validation_images": len(va),
              "example_indices": idx, "batch_size": BATCH,
              "selection": "Lowest local_detail_mae amongst models within 0.25 dB PSNR and 0.003 SSIM of the best on each axis, per size. If empty, retain previous.",
              "selection_final": False, "frequency_weight": FFL_WEIGHT,
              "candidates": {}, "selected": {}}
    resumed = {}
    if args.resume:
        resumed = json.loads((args.out / "validation.json").read_text(encoding="utf-8"))["candidates"]
        report["candidates"] = dict(resumed)
    for side in (8, 16):
        initial = dict(prev["selected"][str(side)])
        initial.pop("candidate", None)
        prior = TASK / initial["checkpoint"]
        if hashlib.sha256(prior.read_bytes()).hexdigest() != initial["sha256"]:
            raise ValueError("Starting checkpoint differs from the 60-epoch selected model")
        initial["parameters"] = sum(p.numel() for p in ConvVAE(side).parameters())
        candidates = dict(resumed.get(str(side), {}))
        candidates["previous"] = initial
        report["candidates"][str(side)] = candidates
        for variant in ("continued", "residual", "paper_ffl"):
            existing = resumed.get(str(side), {}).get(variant)
            if existing and hashlib.sha256((TASK / existing["checkpoint"]).read_bytes()).hexdigest() == existing["sha256"]:
                candidates[variant] = existing
            else:
                candidates[variant] = train(side, variant, prior, train_x, val_x, examples, args)
            write_json(args.out / "validation.json", report)
        quality = max(m["psnr"] for m in candidates.values())
        structure = max(m["ssim"] for m in candidates.values())
        eligible = [k for k,m in candidates.items() if m["psnr"] >= quality - .25
                    and m["ssim"] >= structure - .003]
        selection = min(eligible, key=lambda k: candidates[k]["local_detail_mae"]) if eligible else "previous"
        report["selected"][str(side)] = {"candidate": selection, **candidates[selection]}
        write_json(args.out / "validation.json", report)
        print(f"selected {side}: {selection}", flush=True)
    report["selection_final"] = True
    write_json(args.out / "validation.json", report)


if __name__ == "__main__":
    main()
