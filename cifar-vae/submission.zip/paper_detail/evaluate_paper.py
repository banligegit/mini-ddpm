"""Compare validation-locked weights against the previous 60-epoch release."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from appearance import appearance_errors
from cifar_data import CLASS_NAMES, load_split
from detail.evaluate_detail import CROPS, METRICS, HIGHER_BETTER, ZH_CLASSES, font_for_figures, to_pil
from evaluate import ssim_per_image
from paper_model import load_paper_model


@torch.inference_mode()
def score(model, images, indices, device, batch_size):
    all_scores = []
    examples = torch.empty(len(indices), 3, 32, 32)
    for start in range(0, len(images), batch_size):
        x = images[start:start + batch_size].to(device=device, dtype=torch.float32) / 255
        y = model.decode(model.encode(x)[0])
        mse = (y - x).square().mean((1, 2, 3))
        scores = torch.stack([mse, -10 * mse.log10(), ssim_per_image(x, y)], dim=1)
        all_scores.append(torch.cat([scores, appearance_errors(x, y)], dim=1).cpu().numpy())
        for j, index in enumerate(indices):
            if start <= index < start + len(x):
                examples[j] = y[index-start].cpu()
    values = np.concatenate(all_scores, axis=0)
    if not np.isfinite(values).all():
        raise ValueError("Reconstruction metrics contain non-finite values.")
    return values, examples


def score_pairs(previous, current):
    pairs = {}
    for col, name in enumerate(METRICS):
        diff = current[:, col].astype(np.float64) - previous[:, col].astype(np.float64)
        improvement = diff if name in HIGHER_BETTER else -diff
        n_better = int((improvement > 0).sum())
        pairs[name] = dict(mean_new_minus_old=float(diff.mean()), median_new_minus_old=float(np.median(diff)),
                           improved_images=n_better, improved_fraction=n_better / len(diff),
                           unchanged_images=int((diff == 0).sum()))
    return pairs


def save_figures(images, designs, directory):
    font, chinese = font_for_figures()
    labels = ["原图", "8×8 上一轮", "8×8 本轮", "16×16 上一轮", "16×16 本轮"] if chinese else [
        "Original", "8x8 previous", "8x8 current", "16x16 previous", "16x16 current"]
    classes = ZH_CLASSES if chinese else CLASS_NAMES
    cols = ["original", "previous8", "current8", "previous16", "current16"]
    tile, skip, top, left = 96, 5, 34, 148
    wide = Image.new("RGB", (left + 10*(tile+skip), top + len(cols)*(tile+skip)), "white")
    draw = ImageDraw.Draw(wide)
    for i, name in enumerate(classes):
        draw.text((left+i*(tile+skip)+tile//2, 16), name, font=font, fill="#182b3a", anchor="mm")
    for row, key in enumerate(cols):
        y = top + row*(tile+skip)
        draw.text((8, y+tile//2), labels[row], font=font, fill="#182b3a", anchor="lm")
        for j, arr in enumerate(images[key]):
            patch = to_pil(arr).resize((tile, tile), Image.Resampling.NEAREST)
            wide.paste(patch, (left+j*(tile+skip), y))
    wide.save(directory/"full-comparison.png", optimize=True)

    pitch, row_height, top = 162, 137, 36
    zoom = Image.new("RGB", (pitch*6, top+len(designs)*row_height), "white")
    draw = ImageDraw.Draw(zoom)
    headings = (["原图定位", "原图局部"] if chinese else ["Location", "Original crop"]) + labels[1:]
    for i, label in enumerate(headings):
        draw.text((i*pitch+pitch//2, 18), label, font=font, fill="#182b3a", anchor="mm")
    for row, (cls, index, box, zh, en) in enumerate(designs):
        y = top + row*row_height
        original = to_pil(images["original"][cls]).resize((96, 96), Image.Resampling.NEAREST)
        x0, y0, x1, y1 = box
        ImageDraw.Draw(original).rectangle((x0*3,y0*3,x1*3-1,y1*3-1), outline="#f08423", width=2)
        zoom.paste(original, ((pitch-96)//2, y))
        draw.text((pitch//2,y+112), f"{zh if chinese else en} #{index}",
                  font=font, fill="#182b3a", anchor="mm")
        for col, key in enumerate(cols, start=1):
            crop = to_pil(images[key][cls]).crop(box)
            w, h = crop.size
            expanded = crop.resize((w*7, h*7), Image.Resampling.NEAREST)
            zoom.paste(expanded, (col*pitch+(pitch-expanded.width)//2, y+6))
    zoom.save(directory/"crop-comparison.png", optimize=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT/"data")
    parser.add_argument("--previous", type=Path, default=ROOT/"detail/validation.json")
    parser.add_argument("--selection", type=Path, default=HERE/"validation.json")
    parser.add_argument("--out", type=Path, default=HERE/"results")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=256)
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("Batch size must be positive")
    torch.set_num_threads(min(8, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    weights = {}
    for name, record in (("previous", args.previous), ("current", args.selection)):
        report = json.loads(record.read_text(encoding="utf-8"))
        if name == "current" and (report.get("selection_final") is not True or
                                  any(len(report["candidates"][str(s)]) < 4 for s in (8, 16))):
            raise ValueError("Official evaluation requires the complete, locked validation comparison.")
        selected = report["selected"]
        for side in (8, 16):
            spec = selected[str(side)]
            path = ROOT/spec["checkpoint"]
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if actual != spec["sha256"]:
                raise ValueError(f"{path.name} does not match its validation selection")
            weights[f"{name}{side}"] = (side, spec["checkpoint"], actual)

    pixels, labels = load_split(args.data, train=False)
    if len(pixels) != 10000:
        raise ValueError("Expected the complete official test split.")
    indices = [int(np.flatnonzero(labels==i)[0]) for i in range(10)]
    for cls, index, *_ in CROPS:
        assert index == indices[cls]
    x = torch.from_numpy(pixels)
    examples = {"original": x[indices].float()/255}
    summary = dict(n=len(x), split="official CIFAR-10 test", device=args.device, torch=torch.__version__,
                   metrics=list(METRICS), deterministic_reconstruction="posterior mean",
                   indices=indices, classes=list(CLASS_NAMES), models={}, paired={}, crops=[],
                   counterexample_rule="First image in official order with increased local_detail_mae, if any.",
                   counterexamples={})
    individual = {}
    for key,(side, rel, digest) in weights.items():
        model = load_paper_model(ROOT/rel, args.device).eval()
        if model.side != side:
            raise ValueError(f"Unexpected architecture in {rel}")
        values, examples[key] = score(model, x, indices, args.device, args.batch_size)
        individual[key] = values
        aggregate = dict(zip(METRICS, values.mean(0,dtype=np.float64).tolist()))
        summary["models"][key] = dict(checkpoint=rel, sha256=digest, metrics=aggregate)
    for side in (8, 16):
        previous = individual["previous"+str(side)]
        current = individual["current"+str(side)]
        summary["paired"][str(side)] = score_pairs(previous,current)
        col = METRICS.index("local_detail_mae")
        hits = np.flatnonzero(current[:,col] > previous[:,col])
        if len(hits):
            idx = int(hits[0])
            summary["counterexamples"][str(side)] = dict(index=idx, class_name=CLASS_NAMES[labels[idx]],
                previous_detail_mae=float(previous[idx,col]), current_detail_mae=float(current[idx,col]))
        else:
            summary["counterexamples"][str(side)] = None
    for cls,idx,(x0,y0,x1,y1),_,title in CROPS:
        rgb = {k:(y[cls,:,y0:y1,x0:x1]-examples["original"][cls,:,y0:y1,x0:x1]).abs().double().mean().item()*255
               for k,y in examples.items() if k != "original"}
        summary["crops"].append(dict(index=idx, name=title, box_xyxy=[x0,y0,x1,y1],
                                     mean_rgb_abs_error=rgb))
    args.out.mkdir(exist_ok=True, parents=True)
    save_figures(examples, CROPS, args.out)
    np.savez_compressed(args.out/"per-image.npz", **individual)
    temp = args.out/"metrics.json.tmp"
    temp.write_text(json.dumps(summary, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    temp.replace(args.out/"metrics.json")
    print(json.dumps(summary["models"], indent=2))


if __name__ == "__main__":
    main()
