"""Additive VAE analysis/synthesis refinements on a low-resolution spatial grid."""
from pathlib import Path
import sys

import torch
from torch import nn

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from model import ConvVAE


class ResidualVAE(ConvVAE):
    def __init__(self, side):
        super().__init__(side)
        ratio = 32 // side
        phases = 3 * ratio ** 2
        self.analysis = nn.Sequential(
            nn.PixelUnshuffle(ratio),
            nn.Conv2d(phases, 32, 3, padding=1),
            nn.SiLU(),
            nn.Conv2d(32, 8, 3, padding=1),
        )
        self.synthesis = nn.Sequential(
            nn.Conv2d(4, 32, 3, padding=1),
            nn.SiLU(),
            nn.Conv2d(32, phases, 3, padding=1),
            nn.PixelShuffle(ratio),
        )
        # The first forward pass exactly recovers the pre-existing functions.
        for layer in (self.analysis[-1], self.synthesis[-2]):
            nn.init.zeros_(layer.weight)
            nn.init.zeros_(layer.bias)

    def encode(self, x):
        parameters = self.encoder(x) + self.analysis(x)
        mu, lv = parameters.float().chunk(2, dim=1)
        return mu, lv.clamp(-12., 8.)

    def decode(self, z):
        # Preserve the old pre-sigmoid range and add an RGB-logit correction.
        logits = z
        for block in list(self.decoder.children())[:-1]:
            logits = block(logits)
        return torch.sigmoid(logits + self.synthesis(z))


def load_paper_model(checkpoint, device="cpu"):
    data = torch.load(checkpoint, map_location="cpu", weights_only=True)
    architecture = data.get("architecture", "base")
    if architecture not in ("base", "residual"):
        raise ValueError(f"Unknown architecture {architecture!r}")
    cls = ResidualVAE if architecture == "residual" else ConvVAE
    model = cls(data["side"])
    model.load_state_dict(data["state_dict"])
    return model.to(device).eval()
