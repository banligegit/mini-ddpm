"""Evaluate the validation-selected CIFAR VAEs on all 10,000 official test images.

From task5, run python gated_detail/evaluate_gated.py for the paired study, or
python gated_detail/evaluate_gated.py --selected-only with just the final weights.
The outputs are in gated_detail/results or gated_detail/selected-results.
"""
from pathlib import Path
import sys

from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from cifar_data import CLASS_NAMES
from context_detail.context_model import load_context_model
from context_detail.detail_by_texture import summarize_texture
from context_detail.evaluate_context import evaluate, evaluation_args
from detail.evaluate_detail import CROPS, ZH_CLASSES, font_for_figures, to_pil


def selected_figures(images, out):
    states = ("original", "current16", "current8")
    font, chinese = font_for_figures()
    row_names = ("CIFAR-10 原图", "16×16×4 重建", "8×8×4 重建") if chinese else (
        "CIFAR-10 input", "16x16x4", "8x8x4")
    classes = ZH_CLASSES if chinese else CLASS_NAMES
    ink = "#1e2935"
    tile, gap, left, top = 96, 6, 136, 44
    full = Image.new("RGB", (left + 10 * (tile + gap), top + 3 * (tile + gap)), "white")
    draw = ImageDraw.Draw(full)
    for i, name in enumerate(classes):
        draw.text((left + i * (tile + gap) + tile // 2, top // 2), name, font=font, fill=ink, anchor="mm")
    for row, (state, title) in enumerate(zip(states, row_names)):
        y = top + row * (tile + gap)
        draw.text((8, y + tile // 2), title, font=font, fill=ink, anchor="lm")
        for i, tensor in enumerate(images[state]):
            patch = to_pil(tensor).resize((tile, tile), Image.Resampling.NEAREST)
            full.paste(patch, (left + i * (tile + gap), y))
    full.save(out / "selected-full.png", optimize=True)

    col_width, row_height, head = 180, 133, 42
    zoom = Image.new("RGB", (4 * col_width, head + len(CROPS) * row_height), "white")
    draw = ImageDraw.Draw(zoom)
    titles = (("原图定位", "原图局部") if chinese else ("Location", "Original crop")) + row_names[1:]
    for i, title in enumerate(titles):
        draw.text(((i + .5) * col_width, head // 2), title, font=font, fill=ink, anchor="mm")
    for row, (cls, index, box, zh, en) in enumerate(CROPS):
        y = head + row * row_height
        locator = to_pil(images["original"][cls]).resize((96, 96), Image.Resampling.NEAREST)
        x0, y0, x1, y1 = box
        ImageDraw.Draw(locator).rectangle((3*x0, 3*y0, 3*x1-1, 3*y1-1), outline="#ed781d", width=2)
        zoom.paste(locator, ((col_width - 96) // 2, y))
        draw.text((col_width // 2, y + 110), f"{zh if chinese else en} #{index}", font=font, fill=ink, anchor="mm")
        for col, state in enumerate(states, start=1):
            crop = to_pil(images[state][cls]).crop(box)
            patch = crop.resize((crop.width * 8, crop.height * 8), Image.Resampling.NEAREST)
            zoom.paste(patch, (col * col_width + (col_width - patch.width) // 2, y))
    zoom.save(out / "selected-crops.png", optimize=True)


def main():
    args = evaluation_args(__doc__, ROOT / "context_detail/validation.json", HERE / "final-selection.json",
                           HERE / "results", selected_only_out=HERE / "selected-results")
    from gated_model import load_gated_model
    examples = evaluate(args, None if args.selected_only else load_context_model, load_gated_model)
    selected_figures(examples, args.out)
    if not args.selected_only:
        summarize_texture(args.out, args.data)


if __name__ == "__main__":
    main()
