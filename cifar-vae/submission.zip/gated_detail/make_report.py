"""Build the current three-page CIFAR-10 report from the measured outputs."""
import argparse
import csv
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
SIDES = ("16", "8")
URL = "https://banligegit.github.io/mini-ddpm/cifar-vae/"
NAMES = {"previous": "起点", "continued": "原结构续训", "gated": "局部卷积＋通道注意力"}


def read(relative):
    return json.loads((HERE / relative).read_text(encoding="utf8"))


def table(headers, rows):
    head = "".join(f"<th>{h}</th>" for h in headers)
    content = "".join("<tr>" + "".join(f"<td>{v}</td>" for v in row) + "</tr>" for row in rows)
    return f"<table><thead><tr>{head}</tr></thead><tbody>{content}</tbody></table>"


def photo(name, alt):
    return f'<img src="{(HERE / "results" / name).as_uri()}" alt="{alt}">'


def page(n, label, title, body):
    return f"""<section><header><span>CIFAR-10　 /　 卷积变分自编码器</span><span>{label}</span></header>
    <h1>{title}</h1>{body}<footer><span>mini-ddpm-cifar-vae　·　题目五实验报告</span><span>{n} / 3</span></footer></section>"""


def methods(v, diagnosis):
    control_rows, loss_rows = [], []
    for side in SIDES:
        spec = v["selected"][side]
        for key in ("previous", "continued", "gated"):
            m = v["candidates"][side][key]
            label = NAMES[key] + (" ✓" if spec["candidate"] == key else "")
            control_rows.append((f"{side}×{side}", label, f"{m['parameters']:,}", f"{m['psnr']:.3f}",
                                 f"{m['ssim']:.5f}", f"{m['local_detail_mae']:.3f}"))
        trained = v["candidates"][side]["gated"]
        with (TASK / trained["checkpoint"]).with_name("history.csv").open(encoding="utf8") as f:
            end = list(csv.DictReader(f))[-1]
        loss_rows.append((f"{side}×{side}×4", f"{float(end['train_mse']):.6f}",
                          f"{float(end['kl_per_pixel']):.4f}", f"{float(end['highpass_l1']):.5f}",
                          f"{float(end['total']):.6f}"))
    loss = table(("潜变量形状", "重建 MSE", "KL / 3,072", "高通 MAE", "总损失"), loss_rows)
    control = table(("潜网格", "验证候选", "参数量", "PSNR / dB ↑", "SSIM ↑", "细节误差 ↓"), control_rows)
    diag_rows = []
    for side in SIDES:
        m = diagnosis["models"][side]
        if m["applicable"]:
            diag_rows.append((f"{side}×{side}", f"{m['adaptive']['local_detail_mae']:.4f}",
                              f"{m['constant']['local_detail_mae']:.4f}", f"{m['adaptive']['psnr']:.3f}",
                              f"{m['constant']['psnr']:.3f}"))
    diagnostic = table(("入选权重", "逐图权重 / 细节 ↓", "固定权重 / 细节 ↓", "逐图 / dB ↑", "固定 / dB ↑"), diag_rows) if diag_rows else ""
    return page(1, "方法、训练与验证", "压缩一张照片，还能保留多少细节？", f"""
    <p>CIFAR-10 每张照片包含 32×32×3 个颜色值，除以 255 后传入网络。16×16×4 的编码有 1,024 个数，8×8×4 有 256 个。后者在主干上多一层下采样，解码时多一层上采样。两版均保留像素重排与低分辨率卷积分支。</p>
    <h2>同一个 VAE 如何训练和重建</h2>
    <p>编码器输出均值 μ 和对数方差 ℓ。训练时取 z = μ + exp(ℓ/2) ⊙ ε，ε 服从标准正态。测试时直接解码 μ。解码器只接收四通道潜张量，末层 sigmoid 输出 [0, 1] 的 RGB 图。</p>
    <p class="formula"><b>L = 重建 MSE + 0.003 × KL / 3,072 + 0.075 × 高通 MAE</b></p>
    <p>MSE 对一图的 3,072 个 RGB 值取平均。KL 把每个潜坐标的 ½(μ² + exp ℓ − 1 − ℓ) 相加。高通项取像素误差减去其 3×3 邻域均值后的绝对值均值。各项再对 batch 平均。下表为两支注意力模型的末轮训练记录；第 2 页的权重插值无需再次训练。</p>{loss}
    <h2>在固定训练预算下检验通道注意力</h2>
    <p>参考 RCAN 和 SE，先用两层 3×3 卷积提取局部信息，再对各通道做空间平均，由小网络根据这张照片为 32 组特征分别给出权重。加权后的特征投影回原分支。编码端和解码端各增设一块，末层从零开始，以保证训练起点与原结构相同。[1, 2]</p>
    <p>官方训练集划分为 45,000 张训练和 5,000 张验证。每种尺寸均从第 {v['initial_epochs']} 轮权重出发，两支各续训 {v['extra_epochs']} 轮、{v['updates_per_variant']:,} 次 Adam 更新，batch size {v['batch_size']}，学习率和噪声种子相同。两支的更新次数相同，增加卷积会增加计算量。</p>
    {control}<p class="cap">✓ 为第一轮筛选结果。保留同尺寸 PSNR 距最佳不超过 0.25 dB、SSIM 距最佳不超过 0.003 的候选，取细节误差最低者。16×16 两支细节误差接近，普通续训的 PSNR 和 SSIM 更高。</p>
    <h2>输入自适应的权重贡献了多少</h2>
    <p>用划分中前 2,048 张训练图估计各通道平均权重，固定这些均值，再对同一 5,000 张验证图重建。这个对照保留全部卷积和训练参数，可检验推理时随图改变权重的作用。</p>{diagnostic}
    <p class="cap">16×16 逐图调整带来约 0.18 dB 的 PSNR 收益，对局部细节误差几乎没有帮助。8×8 固定与逐图两种做法的 PSNR 仅差约 0.003 dB。</p>""")


def reconstruction(t, notes):
    rows = []
    for side in SIDES:
        m = t["models"]["current" + side]["metrics"]
        rows.append((f"{side}×{side}×4", f"{m['mse']:.6f}", f"{m['psnr']:.2f}", f"{m['ssim']:.4f}",
                     f"{m['mean_rgb_mae']:.2f}", f"{m['coarse_gradient_mae']:.2f}", f"{m['local_detail_mae']:.3f}"))
    scores = table(("入选权重", "MSE ↓", "PSNR / dB ↑", "SSIM ↑", "颜色 ↓", "轮廓 ↓", "细节 ↓"), rows)
    return page(2, "官方测试集　·　同图重建", "用原图逐处核对重建", f"""
    <p>参考权重平均，在普通续训（t=0）与新增注意力（t=1）的参数之间取 t=0.25、0.50、0.75。[3] 只有验证 PSNR 和 SSIM 都达到起点与第一轮入选者中的较高值，细节误差也达到较低值，插值模型才可晋级。{notes['selection']}</p>
    <p>对全部 {t['n']:,} 张官方测试图逐张解码 μ，再取指标均值。后三列分别测整图 RGB 均值、4×4 分块后的相邻梯度、3×3 高通残差的误差，单位为 0–255 RGB 强度级。</p>{scores}
    <figure>{photo('selected-full.png','同一批十类 CIFAR-10 图的原图和入选重建')}
    <figcaption>图 1　每类按官方顺序取第一张。同一列是同一张原始照片与两种潜空间的重建。</figcaption></figure>
    <figure>{photo('selected-crops.png','飞机红字、车窗和船身三个固定区域')}
    <figcaption>图 2　沿用实验前已指定的三个坐标框，以最近邻按整数倍放大原始像素。{notes['crop']}</figcaption></figure>
    <h2>哪些变化能在原图上找到</h2><p>{notes['effect']}</p><p>{notes['exception']}</p>
    <p class="cap">两轮都评估过同一官方测试集；插值系数仅按验证集比较。本实验使用一个训练种子。图中放大展示原有的 32×32 像素。</p>""")


def prior(t, calibration, notes):
    blocks = []
    for name, label, body in (("real-reference", "真实 CIFAR-10", "官方测试集按顺序取前 32 张，供观察自然照片中物体和背景的结构。"),
                              ("prior16", "16×16×4 直接解码", notes["prior16"]),
                              ("prior8", "8×8×4 直接解码", notes["prior8"])):
        blocks.append(f'<div class="panel">{photo(name+".png",label)}<div><h3>{label}</h3><p>{body}</p></div></div>')
    a, b = (t["models"]["current" + s]["metrics"] for s in SIDES)
    return page(3, "直接采样　·　题目六权重", "没有原图时，同一个解码器画出了什么？", f"""
    <p>把标准正态张量 z 直接送给入选解码器。每种尺寸固定种子 {t['prior']['seed']}，连续生成 32 张，全部按原顺序展示。随机样本和真实图没有配对关系。</p>{''.join(blocks)}
    <p>编码照片时，μ 已经保留这张照片各部位的位置和配色；从标准正态抽样时，各位置独立取值。KL 会约束每张图的后验，重建训练仍允许解码器依赖真实编码中的空间关系。第 2 页的 PSNR 和 SSIM 衡量同图保真度，这一页用未筛选样本观察自然物体能否成形。</p>
    <h2>给题目六留哪一份</h2>
    <p>网页同时展示两份入选权重。以重建质量为先时选 16×16；下一题从 <b>8×8×4</b> 开始，用四分之一的潜变量元素数换取更小的扩散输入，代价是 PSNR 低 {a['psnr']-b['psnr']:.2f} dB、SSIM 低 {a['ssim']-b['ssim']:.4f}。用 45,000 张训练图重算了该权重的四通道 μ 均值和标准差，5,000 张验证图上标准化往返后的最大 RGB 差为 {calibration['max_abs_rgb_error']:.2g}。</p>
    <p class="cap">[1] Zhang 等，<a href="https://arxiv.org/abs/1807.02758">RCAN</a>　[2] Hu 等，<a href="https://arxiv.org/abs/1709.01507">Squeeze-and-Excitation Networks</a>　[3] Wortsman 等，<a href="https://proceedings.mlr.press/v162/wortsman22a.html">Model Soups</a><br>
    <a href="https://arxiv.org/abs/1312.6114">VAE 原论文</a>　·　<a href="https://cave.cs.toronto.edu/kriz/cifar.html">CIFAR-10 数据说明</a>　·　<a href="{URL}#comparison">网页对照</a>　·　<a href="{URL}submission.zip">代码、两份权重、图表和逐图数据</a></p>""")


CSS = """
@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;color:#172a30;font:10.2pt/1.47 'Microsoft YaHei','Noto Sans CJK SC',sans-serif}
section{width:210mm;min-height:297mm;padding:12mm 15mm 15mm;position:relative;break-after:page}section:last-child{break-after:auto}
header,footer{display:flex;justify-content:space-between;color:#456369;font-size:8.5pt}header{padding-bottom:2.4mm;border-bottom:1px solid #85989c}
footer{position:absolute;bottom:6mm;left:15mm;right:15mm;border-top:1px solid #c7d5d7;padding-top:1.5mm}
h1{font-size:21pt;line-height:1.25;margin:4.5mm 0 1.8mm}h2{font-size:12.6pt;margin:3.2mm 0 .8mm}h3{font-size:12pt;margin:1mm 0}
p{margin:1.35mm 0}.formula{padding:1.8mm 3mm;background:#e8f1ee}.cap,figcaption{font-size:8.7pt;color:#38565d}
table{width:100%;border-collapse:collapse;margin:1.4mm 0 2mm;font-size:9.35pt;font-variant-numeric:tabular-nums}
td,th{text-align:right;padding:1.1mm 1.4mm;border-bottom:1px solid #d2dddf}td:first-child,th:first-child{text-align:left}th{background:#eaf1ef;color:#24484c}
figure{margin:2.6mm 0}figure img{display:block;width:100%;max-height:76mm;object-fit:contain}.panel{display:flex;align-items:center;gap:4mm;margin:2mm 0}
.panel img{width:91mm}.panel div{flex:1}.panel p{font-size:9.5pt}a{color:#12626a}
"""


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--chrome", help="Path to local Chrome or Chromium")
    args = p.parse_args()
    v, t = read("validation.json"), read("results/metrics.json")
    final, diagnosis, calibration = read("final-selection.json"), read("gate-diagnostic.json"), read("calibration/roundtrip.json")
    if (not final["selection_final"] or calibration["checkpoint_sha256"] != final["selected"]["8"]["sha256"]
            or any(final["selected"][s]["sha256"] != t["models"]["current"+s]["sha256"]
                   or diagnosis["models"][s]["sha256"] != final["selected"][s]["sha256"] for s in SIDES)):
        raise ValueError("Selection, calibration, validation probe and official test must use the same weights")
    notes = read("observations.json")
    body = methods(v, diagnosis) + reconstruction(t, notes) + prior(t, calibration, notes)
    with TemporaryDirectory() as d:
        source = Path(d) / "report.html"
        source.write_text(f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>CIFAR-10 VAE 实验报告</title><style>{CSS}</style><body>{body}</body></html>', encoding="utf8")
        with sync_playwright() as pw:
            browser = pw.chromium.launch(executable_path=args.chrome)
            page_tab = browser.new_page()
            page_tab.goto(source.as_uri(), wait_until="load")
            page_tab.evaluate("document.fonts.ready")
            assert page_tab.locator("img").evaluate_all("(els) => els.length === 5 && els.every(e => e.complete && e.naturalWidth)")
            page_tab.pdf(path=str(HERE/"report.pdf"), prefer_css_page_size=True, print_background=True)
            browser.close()


if __name__ == "__main__":
    main()
