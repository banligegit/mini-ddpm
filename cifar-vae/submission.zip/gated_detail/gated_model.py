"""CIFAR-10 VAE with local residual corrections and image-dependent channel attention.

The gates use global average pooling as in Zhang et al., RCAN, ECCV 2018.
"""
from pathlib import Path
import sys

import torch
from torch import nn

TASK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TASK))
from context_detail.context_model import ContextVAE, load_context_model


class ChannelResidual(nn.Module):
    def __init__(self):
        super().__init__()
        self.local = nn.Sequential(
            nn.Conv2d(32, 48, 3, padding=1), nn.SiLU(),
            nn.Conv2d(48, 32, 3, padding=1),
        )
        self.gate = nn.Sequential(
            nn.Conv2d(32, 8, 1), nn.SiLU(),
            nn.Conv2d(8, 32, 1), nn.Sigmoid(),
        )
        self.project = nn.Conv2d(32, 32, 1)
        nn.init.zeros_(self.project.weight)
        nn.init.zeros_(self.project.bias)

    def forward(self, x):
        correction = self.local(x)
        weights = self.gate(correction.mean(dim=(2, 3), keepdim=True))
        return x + self.project(correction * weights)


class GatedVAE(ContextVAE):
    def __init__(self, side):
        super().__init__(side)
        self.analysis.context.add_module("gated", ChannelResidual())
        self.synthesis.context.add_module("gated", ChannelResidual())


def load_gated_model(checkpoint, device="cpu"):
    record = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if record.get("architecture") != "gated":
        return load_context_model(checkpoint, device)
    model = GatedVAE(record["side"])
    model.load_state_dict(record["state_dict"])
    return model.to(device).eval()
