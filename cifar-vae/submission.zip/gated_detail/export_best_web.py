"""Export the two validation-selected CIFAR-10 VAEs and the official test examples to GitHub Pages."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

import numpy as np
import onnxruntime as ort
import torch

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK))
from cifar_data import load_split
from export_web import Decoder, MeanEncoder, checked_export, save_image
from gated_model import load_gated_model

CLASSES = ["飞机", "汽车", "鸟", "猫", "鹿", "狗", "蛙", "马", "船", "卡车"]


@torch.inference_mode()
def export_pair(side, model, examples, site):
    encoder = site / "models" / f"best-encoder{side}.onnx"
    decoder = site / "models" / f"best-decoder{side}.onnx"
    z = torch.randn(1, 4, side, side, generator=torch.Generator().manual_seed(2026))
    enc_error = checked_export(MeanEncoder(model), next(iter(examples.values())), encoder, "x", "mu")
    dec_error = checked_export(Decoder(model), z, decoder, "z", "rgb")
    enc = ort.InferenceSession(str(encoder), providers=["CPUExecutionProvider"])
    dec = ort.InferenceSession(str(decoder), providers=["CPUExecutionProvider"])
    rgb_error = 0.
    for idx, x in examples.items():
        expected = model.decode(model.encode(x)[0])
        mu, = enc.run(["mu"], {"x": x.numpy()})
        actual, = dec.run(["rgb"], {"z": mu})
        error = float(np.abs(actual - expected.numpy()).max())
        if not np.isfinite(error) or error > 2e-4:
            raise RuntimeError(f"ONNX reconstruction mismatch for {side}x{side} on test #{idx}: {error}")
        rgb_error = max(rgb_error, error)
        rgb8 = expected[0].mul(255).round().clamp(0, 255).byte().numpy()
        save_image(rgb8, site / "samples" / f"{idx}-best{side}.png")
    return dict(encoder_max_abs=enc_error, decoder_max_abs=dec_error, ten_image_rgb_max_abs=rgb_error)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Destination site/cifar-vae directory")
    parser.add_argument("--data", type=Path, default=TASK / "data")
    args = parser.parse_args()
    torch.set_num_threads(2)
    validation = json.loads((HERE / "final-selection.json").read_text(encoding="utf-8"))
    if validation.get("selection_final") is not True:
        raise RuntimeError("Both validation choices must be final before export")
    scores = json.loads((HERE / "results/metrics.json").read_text(encoding="utf-8"))
    prior = scores["prior"]
    if (scores["n"] != 10000 or prior["reference_indices"] != list(range(32))
            or prior["count_per_model"] != 32 or prior["seed"] != 2026 or prior["matched_reference"]):
        raise ValueError("Test or prior protocol mismatch")
    originals, labels = load_split(args.data, train=False)
    samples = [dict(name=name, index=int(np.flatnonzero(labels == label)[0]))
               for label, name in enumerate(CLASSES)]
    if [sample["index"] for sample in samples] != scores["indices"]:
        raise ValueError("Official test example indices differ from the export")
    for folder in ("models", "samples"):
        (args.output / folder).mkdir(parents=True, exist_ok=True)
    examples = {}
    for sample in samples:
        idx = sample["index"]
        examples[idx] = torch.from_numpy(originals[idx]).float().unsqueeze(0) / 255
        save_image(originals[idx], args.output / "samples" / f"{idx}-original.png")
    records = {}
    for side in (16, 8):
        choice = validation["selected"][str(side)]
        checkpoint = TASK / choice["checkpoint"]
        digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        result = scores["models"][f"current{side}"]
        if digest != choice["sha256"] or digest != result["sha256"]:
            raise ValueError(f"Validation and official test hashes do not agree with {checkpoint}")
        model = load_gated_model(checkpoint, "cpu").eval()
        errors = export_pair(side, model, examples, args.output)
        parameters = sum(p.numel() for p in model.parameters())
        if parameters != choice["parameters"]:
            raise ValueError(f"Incorrect parameter count for {side}x{side}: {parameters}")
        metrics = {key: result["metrics"][key] for key in ("psnr", "ssim", "local_detail_mae")}
        records[str(side)] = dict(**metrics, parameters=parameters, checkpoint_sha256=digest, **errors)
        print(f"{side}x{side}: ten-image ONNX RGB error {errors['ten_image_rgb_max_abs']:.3g}", flush=True)
    for group in ("real-reference", "prior16", "prior8"):
        shutil.copyfile(HERE / "results" / f"{group}.png", args.output / "samples" / f"{group}.png")
    catalog = dict(samples=samples, test_image_count=scores["n"], models=records, prior=prior)
    (args.output / "best-results.json").write_text(
        json.dumps(catalog, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
