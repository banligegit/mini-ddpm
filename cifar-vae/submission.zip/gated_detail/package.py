"""Build the public submission with exactly the two selected PyTorch checkpoints."""
import hashlib
import json
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def main():
    validation = json.loads((HERE / "final-selection.json").read_text(encoding="utf8"))
    if not validation["selection_final"]:
        raise ValueError("The selections are not yet final")
    files = {ROOT / relative for relative in (
        "model.py", "train.py", "evaluate.py", "appearance.py", "cifar_data.py", "export_web.py",
        "refinement/beta/split.npz", "latent_diagnostics/latent_io.py", "detail/calibrate.py",
        "detail/evaluate_detail.py", "detail/train_detail.py", "paper_detail/paper_model.py",
        "paper_detail/train_paper.py", "paper_detail/evaluate_paper.py", "context_detail/validation.json",
        "context_detail/context_model.py", "context_detail/evaluate_context.py", "context_detail/detail_by_texture.py",
    )}
    winners = set()
    for side in ("16", "8"):
        spec = validation["selected"][side]
        path = ROOT / spec["checkpoint"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != spec["sha256"]:
            raise ValueError(f"Selected checkpoint verification failed: {path}")
        winners.add(spec["checkpoint"])
        files.add(path)
    for name in ("validation.json", "final-selection.json", "gate-diagnostic.json", "report.pdf", "observations.json",
                 "calibration/channel-statistics.json", "calibration/roundtrip.json",
                 "results/metrics.json", "results/per-image.npz", "results/texture-quartiles.json",
                 "results/selected-full.png", "results/selected-crops.png", "results/real-reference.png",
                 "results/prior8.png", "results/prior16.png", "results/prior-comparison.png"):
        files.add(HERE / name)
    files.update(HERE.glob("*.py"))
    files.update(HERE.glob("experiments/*/history.csv"))
    if (HERE / "results/counterexamples.png").exists():
        files.add(HERE / "results/counterexamples.png")
    with NamedTemporaryFile(dir=HERE, delete=False) as f:
        tmp = Path(f.name)
    try:
        with ZipFile(tmp, "w", ZIP_DEFLATED, compresslevel=6) as archive:
            archive.write(HERE / "README.md", "README.md")
            for path in sorted(files):
                archive.write(path, path.relative_to(ROOT).as_posix())
        with ZipFile(tmp) as archive:
            if archive.testzip() or {n for n in archive.namelist() if n.endswith(".pt")} != winners:
                raise ValueError("Public bundle failed verification")
        tmp.replace(HERE / "submission.zip")
    finally:
        tmp.unlink(missing_ok=True)
    path = HERE / "submission.zip"
    print(f"{path}  {path.stat().st_size} bytes  SHA-256 {hashlib.sha256(path.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
