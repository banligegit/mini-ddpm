"""Compare image-dependent gates with their training-set means on validation images."""
import argparse
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from gated_model import ChannelResidual, load_gated_model, TASK
from appearance import appearance_errors
from cifar_data import load_split
from evaluate import ssim_per_image

HERE = Path(__file__).resolve().parent


@torch.inference_mode()
def compare(model, train_pixels, valid_pixels, device):
    gates = {name: block.gate for name, block in model.named_modules() if isinstance(block, ChannelResidual)}
    if not gates:
        return {"applicable": False}
    means = {}
    def record(name):
        def hook(module, args, output):
            current = output.double().sum(dim=0, keepdim=True)
            means[name] = means.get(name, 0) + current
        return hook

    def batches(pixels):
        for part in pixels.split(128):
            yield part.to(device=device, dtype=torch.float32) / 255

    with ExitStack() as stack:
        for name, gate in gates.items():
            stack.callback(gate.register_forward_hook(record(name)).remove)
        for x in batches(train_pixels):
            model.decode(model.encode(x)[0])
    means = {name: (total / len(train_pixels)).float() for name, total in means.items()}

    def score():
        totals = torch.zeros(3, dtype=torch.float64, device=device)
        for x in batches(valid_pixels):
            decoded = model.decode(model.encode(x)[0])
            mse = (decoded - x).square().mean((1, 2, 3))
            errors = appearance_errors(x, decoded)
            scores = torch.stack((-10 * mse.log10(), ssim_per_image(x, decoded), errors[:, 2]))
            totals += scores.sum(dim=1, dtype=torch.float64)
        return dict(zip(("psnr", "ssim", "local_detail_mae"), (totals / len(valid_pixels)).tolist()))

    adaptive = score()
    with ExitStack() as stack:
        for name, gate in gates.items():
            def fixed(module, args, output, mean=means[name]):
                return mean.expand_as(output)
            stack.callback(gate.register_forward_hook(fixed).remove)
        constant = score()
    return {"applicable": True, "adaptive": adaptive, "constant": constant,
            "channel_means": {key: vals.flatten().tolist() for key, vals in means.items()}}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", type=Path, default=TASK / "data")
    p.add_argument("--selection", type=Path, default=HERE / "final-selection.json")
    p.add_argument("--out", type=Path, default=HERE / "gate-diagnostic.json")
    p.add_argument("--device", default="cpu")
    args = p.parse_args()
    record = json.loads(args.selection.read_text(encoding="utf8"))
    if not record["selection_final"]:
        raise ValueError("Wait for the locked selections")
    torch.set_num_threads(min(6, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    pixels, _ = load_split(args.data, train=True)
    with np.load(TASK / "refinement/beta/split.npz") as split:
        train = torch.from_numpy(pixels[split["train"][:2048]])
        valid = torch.from_numpy(pixels[split["val"]])
    result = {"mean_gate_reference": "first 2048 training IDs in the fixed split, forwarding posterior means",
              "validation_images": len(valid), "device": args.device, "models": {}}
    for side in ("16", "8"):
        spec = record["selected"][side]
        path = TASK / spec["checkpoint"]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != spec["sha256"]:
            raise ValueError("Unexpected checkpoint")
        metrics = compare(load_gated_model(path, args.device), train, valid, args.device)
        result["models"][side] = {"sha256": digest, **metrics}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf8")
    print(args.out)


if __name__ == "__main__":
    main()
