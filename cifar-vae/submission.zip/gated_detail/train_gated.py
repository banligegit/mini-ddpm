"""Fine-tune two CIFAR VAEs, with and without a channel-attention residual branch."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import torch

from gated_model import GatedVAE, TASK, load_gated_model, load_context_model
sys.path.insert(0, str(TASK / "paper_detail"))
from train_paper import relpath, validate
from cifar_data import load_split
from detail.train_detail import BATCH, BETA, SEED, WEIGHT, run_epochs, write_json
from evaluate import save_grid

HERE = Path(__file__).resolve().parent
EPOCHS = 30
LR = .0008


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def initialize(checkpoint, side, variant, examples):
    torch.manual_seed(SEED)
    parent = load_context_model(checkpoint)
    if variant == "continued":
        return parent
    model = GatedVAE(side)
    added = model.load_state_dict(parent.state_dict(), strict=False)
    desired = {key for key in model.state_dict() if ".gated." in key}
    if added.unexpected_keys or set(added.missing_keys) != desired:
        raise RuntimeError("Could not transfer all of the original parameters")
    with torch.inference_mode():
        x = examples[:4].cpu()
        a, b = parent.encode(x)
        c, d = model.encode(x)
        if not (torch.equal(a, c) and torch.equal(b, d) and torch.equal(parent.decode(a), model.decode(c))):
            raise RuntimeError("Attention branch changed the starting function")
    return model


def train(prior, side, variant, train_x, val_x, examples, out):
    out.mkdir(parents=True, exist_ok=True)
    device = train_x.device
    model = initialize(prior, side, variant, examples).to(
        device=device, memory_format=torch.channels_last).train()
    torch.manual_seed(SEED)
    order = torch.Generator().manual_seed(SEED)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, EPOCHS * math.ceil(len(train_x) / BATCH), eta_min=LR / 10)
    parameters = sum(p.numel() for p in model.parameters())
    print(f"Starting {side}-{variant}, {parameters:,} parameters", flush=True)
    with (out / "history.csv").open("w", newline="", encoding="utf8") as f:
        writer = csv.writer(f)
        writer.writerow(("extra_epoch", "train_mse", "kl_per_pixel", "highpass_l1",
                         "total", "highpass_weight", "seconds"))
        for first in range(1, EPOCHS + 1, 5):
            history = run_epochs(model, optimizer, scheduler, train_x, order,
                                 first, min(first + 4, EPOCHS), WEIGHT)
            writer.writerows(history)
            f.flush()
    checkpoint = out / f"vae{side}.pt"
    tmp = checkpoint.with_suffix(".tmp")
    torch.save({"side": side, "architecture": "gated" if variant == "gated" else "context",
                "state_dict": {k: v.cpu() for k, v in model.state_dict().items()},
                "config": {"parent_sha256": sha(prior), "beta": BETA, "highpass": WEIGHT,
                           "extra_epochs": EPOCHS, "batch_size": BATCH, "initial_lr": LR,
                           "final_lr": LR / 10, "seed": SEED}}, tmp)
    tmp.replace(checkpoint)
    with torch.backends.cudnn.flags(enabled=True, benchmark=False, deterministic=False, allow_tf32=False):
        metrics = validate(load_gated_model(checkpoint, device), val_x, examples, device,
                           out / "validation-examples.png")
    metrics.update(checkpoint=relpath(checkpoint), sha256=sha(checkpoint), parameters=parameters)
    print(f"Validation {side}-{variant}: {metrics}", flush=True)
    return metrics


def select(candidates):
    psnr = max(m["psnr"] for m in candidates.values())
    ssim = max(m["ssim"] for m in candidates.values())
    feasible = [k for k, m in candidates.items() if m["psnr"] >= psnr - .25 and m["ssim"] >= ssim - .003]
    return min(feasible, key=lambda k: candidates[k]["local_detail_mae"]) if feasible else "previous"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE)
    parser.add_argument("--data", type=Path, default=TASK / "data")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--resume", action="store_true", help="Reuse completed checksum-verified variants")
    args = parser.parse_args()
    torch.set_num_threads(min(8, torch.get_num_threads()))
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    manifest = out / "validation.json"
    parent_record = json.loads((TASK / "context_detail/validation.json").read_text("utf8"))
    parents = parent_record["selected"]
    if not parent_record["selection_final"] or any(
        parents[key]["candidate"] != "context" or sha(TASK / parents[key]["checkpoint"]) != parents[key]["sha256"]
        for key in ("8", "16")
    ):
        raise RuntimeError("Missing locked context VAE starting weights")
    original, labels = load_split(args.data, train=True)
    split_path = TASK / "refinement/beta/split.npz"
    with np.load(split_path) as split:
        tr, va = split["train"], split["val"]
    idx = [int(va[labels[va] == k][0]) for k in range(10)]
    examples = torch.from_numpy(original[idx]).to(device=args.device, dtype=torch.float32) / 255
    save_grid(examples, out / "validation-original.png")
    train_x = torch.from_numpy(original[tr]).to(args.device)
    val_x = torch.from_numpy(original[va])
    del original
    protocol = {"initial_epochs": 120, "extra_epochs": EPOCHS, "batch_size": BATCH, "seed": SEED,
                "updates_per_variant": EPOCHS * math.ceil(len(tr) / BATCH), "beta": BETA, "highpass": WEIGHT,
                "initial_lr": LR, "final_lr": LR / 10, "split_sha256": sha(split_path),
                "parent_sha256": {k: parents[k]["sha256"] for k in ("8", "16")},
                "example_indices": idx, "train_images": len(tr), "validation_images": len(va),
                "selection": parent_record["selection"]}
    report = dict(protocol, selection_final=False, candidates={}, selected={})
    if args.resume and manifest.exists():
        report = json.loads(manifest.read_text("utf8"))
        if any(report.get(k) != v for k, v in protocol.items()):
            raise ValueError("The saved run used a different protocol or parent")
    write_json(manifest, report)
    for side in (8, 16):
        key = str(side)
        prior = TASK / parents[key]["checkpoint"]
        candidates = report["candidates"].setdefault(key, {})
        candidates["previous"] = {k: v for k, v in parents[key].items() if k != "candidate"}
        for variant in ("gated", "continued"):
            stored = candidates.get(variant)
            if stored:
                path = TASK / stored["checkpoint"]
                if args.resume and path.is_file() and sha(path) == stored["sha256"]:
                    continue
            report["selection_final"] = False
            report["selected"].pop(key, None)
            candidates.pop(variant, None)
            write_json(manifest, report)
            candidates[variant] = train(prior, side, variant, train_x, val_x, examples,
                                        out / "experiments" / f"{side}-{variant}")
            write_json(manifest, report)
        choice = select(candidates)
        report["selected"][key] = dict(candidate=choice, **candidates[choice])
        write_json(manifest, report)
    report["selection_final"] = True
    write_json(manifest, report)


if __name__ == "__main__":
    main()
