"""Compute train-only channel statistics for topic 6 and check their inversion.

From task5, run python gated_detail/calibrate_gated.py --checkpoint PATH.
See gated_detail/calibration/channel-statistics.json and roundtrip.json.
"""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from detail.calibrate import main
from gated_model import load_gated_model


if __name__ == "__main__":
    main(model_loader=load_gated_model, default_out=HERE / "calibration")
