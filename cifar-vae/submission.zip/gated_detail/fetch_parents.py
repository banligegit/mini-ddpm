"""Restore the two verified starting weights for reproducing the training comparison."""
import hashlib
import io
import json
from pathlib import Path
import tempfile
from urllib.request import urlopen
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
URL = ("https://raw.githubusercontent.com/banligegit/mini-ddpm/"
       "13aa8ff31f0a933e752b7c48637a8052f06c6603/site/cifar-vae/cifar-vae-context-detail.zip")
ARCHIVE_HASH = "bf82f035856670d71b689a82fdeebd581d8b6a50b7d83a5a57f8972ffee83b79"


def main():
    specs = json.loads((ROOT / "context_detail/validation.json").read_text(encoding="utf-8"))["selected"]
    needed = []
    for spec in specs.values():
        path = ROOT / spec["checkpoint"]
        if path.exists():
            if hashlib.sha256(path.read_bytes()).hexdigest() != spec["sha256"]:
                raise ValueError(f"Existing file differs from recorded starting weight: {path}")
        else:
            needed.append(spec)
    if not needed:
        print("Both starting checkpoints already match their recorded SHA-256.")
        return
    with urlopen(URL, timeout=60) as response:
        data = response.read()
    if hashlib.sha256(data).hexdigest() != ARCHIVE_HASH:
        raise ValueError("Archived experiment does not match its recorded SHA-256")
    with ZipFile(io.BytesIO(data)) as archive:
        for spec in needed:
            path = ROOT / spec["checkpoint"]
            payload = archive.read(spec["checkpoint"])
            if hashlib.sha256(payload).hexdigest() != spec["sha256"]:
                raise ValueError("Starting checkpoint verification failed")
            path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as out:
                temp = Path(out.name)
                out.write(payload)
            try:
                temp.replace(path)
            finally:
                temp.unlink(missing_ok=True)
            print(path)


if __name__ == "__main__":
    main()
