"""Evaluate three weight interpolations on the fixed 5k CIFAR validation split."""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
import torch

from gated_model import GatedVAE, TASK, load_gated_model
from train_gated import HERE, sha
sys.path.insert(0, str(TASK / "paper_detail"))
from train_paper import relpath, validate
from cifar_data import load_split
from detail.train_detail import write_json

FRACTIONS = (.25, .5, .75)
RULE = ("A blend can replace the original validation winner only if it reaches the better PSNR, "
        "better SSIM and lower local_detail_mae of both the 120-epoch parent and the original winner. "
        "Among eligible blends choose the lowest local_detail_mae; otherwise keep that winner.")


def interpolate(side, left, right, t):
    """Embed the smaller architecture by assigning the new projection zero at the left endpoint."""
    values = {}
    for key, tensor in right.items():
        if key in left:
            if t == 0.:
                values[key] = left[key]
            elif t == 1.:
                values[key] = tensor
            else:
                values[key] = torch.lerp(left[key], tensor, t)
        elif ".gated." not in key:
            raise ValueError(f"Unexpected new parameter {key}")
        elif ".gated.project." in key:
            values[key] = t * tensor
        else:
            values[key] = tensor
    if left.keys() - right.keys():
        raise ValueError("A source parameter is missing from the common architecture")
    model = GatedVAE(side)
    model.load_state_dict(values)
    return model.eval()


@torch.inference_mode()
def verify_endpoints(left_model, right_model, x):
    side = left_model.side
    z = torch.randn((len(x), 4, side, side), generator=torch.Generator().manual_seed(2026))
    checks = {}
    for t, reference in ((0., left_model), (1., right_model)):
        candidate = interpolate(side, left_model.state_dict(), right_model.state_dict(), t)
        mu, lv = candidate.encode(x)
        ref_mu, ref_lv = reference.encode(x)
        pairs = {"mu": (mu, ref_mu), "logvar": (lv, ref_lv),
                 "decode_random_z": (candidate.decode(z), reference.decode(z)),
                 "decode_mu": (candidate.decode(mu), reference.decode(ref_mu))}
        errors = {k: (a - b).abs().max().item() for k, (a, b) in pairs.items()}
        if any(errors.values()):
            raise ValueError(f"Endpoint t={t} differs from parent: {errors}")
        checks[str(t)] = errors
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=TASK / "data")
    parser.add_argument("--out", type=Path, default=HERE)
    parser.add_argument("--training-selection", type=Path, help="Defaults to validation.json in the output directory")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(min(8, torch.get_num_threads()))
    source_path = args.training_selection or out / "validation.json"
    first = json.loads(source_path.read_text("utf8"))
    split_path = TASK / "refinement/beta/split.npz"
    if not first["selection_final"] or sha(split_path) != first["split_sha256"]:
        raise ValueError("Original selection or existing validation split is invalid")
    with np.load(split_path) as split:
        va = split["val"]
    images, _ = load_split(args.data, train=True)
    val_x = torch.from_numpy(images[va])
    examples = torch.from_numpy(images[first["example_indices"]]).float().div_(255)
    del images
    manifest = out / "final-selection.json"
    report = dict(first, selection=RULE, selection_final=False, selected={}, first_selection=first["selected"],
                  first_selection_sha256=sha(source_path), blend_fractions=FRACTIONS, endpoint_max_abs={},
                  eligible_blends={}, promotion_thresholds={})
    write_json(manifest, report)
    for side in (8, 16):
        key = str(side)
        candidates = report["candidates"][key]
        for row in candidates.values():
            if sha(TASK / row["checkpoint"]) != row["sha256"]:
                raise ValueError(f"Invalid parent checksum: {row['checkpoint']}")
        left = load_gated_model(TASK / candidates["continued"]["checkpoint"])
        right = load_gated_model(TASK / candidates["gated"]["checkpoint"])
        report["endpoint_max_abs"][key] = verify_endpoints(left, right, examples)
        original = first["selected"][key]
        previous = candidates["previous"]
        thresholds = {m: max(original[m], previous[m]) for m in ("psnr", "ssim")}
        thresholds["local_detail_mae"] = min(original["local_detail_mae"], previous["local_detail_mae"])
        report["promotion_thresholds"][key] = thresholds
        eligible = []
        for t in FRACTIONS:
            name = f"blend{int(t * 100)}"
            dest = out / "experiments" / f"{side}-{name}"
            dest.mkdir(parents=True, exist_ok=True)
            model = interpolate(side, left.state_dict(), right.state_dict(), t)
            ckpt = dest / f"vae{side}.pt"
            tmp = ckpt.with_suffix(".tmp")
            torch.save({"side": side, "architecture": "gated", "state_dict": model.state_dict(),
                        "config": {"blend_fraction": t, "left_sha256": candidates["continued"]["sha256"],
                                   "right_sha256": candidates["gated"]["sha256"]}}, tmp)
            tmp.replace(ckpt)
            with torch.backends.cudnn.flags(enabled=True, benchmark=False, deterministic=False, allow_tf32=False):
                metrics = validate(load_gated_model(ckpt, args.device), val_x, examples.to(args.device),
                                   args.device, dest / "validation-examples.png")
            metrics.update(checkpoint=relpath(ckpt), sha256=sha(ckpt), blend_fraction=t,
                           parameters=sum(p.numel() for p in model.parameters()))
            candidates[name] = metrics
            if (metrics["psnr"] >= thresholds["psnr"] and metrics["ssim"] >= thresholds["ssim"]
                    and metrics["local_detail_mae"] <= thresholds["local_detail_mae"]):
                eligible.append(name)
            print(side, name, metrics, flush=True)
            write_json(manifest, report)
        report["eligible_blends"][key] = eligible
        winner = min(eligible, key=lambda n: candidates[n]["local_detail_mae"]) if eligible else original["candidate"]
        report["selected"][key] = dict(candidate=winner, **candidates[winner])
        write_json(manifest, report)
    report["selection_final"] = True
    write_json(manifest, report)


if __name__ == "__main__":
    main()
