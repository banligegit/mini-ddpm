# 两种压缩尺寸的训练和验证

从任务五原有的两份 150 轮模型热启动。8×8 和 16×16 的潜变量都是四个通道。原 CIFAR-10 训练集按原有索引分成 45,000 张训练图和 5,000 张验证图，训练和选择检查点的脚本仅读取官方训练集。验证重建始终执行 `model.decode(model.encode(x)[0])`。

## 三阶段复现

在 `task5` 下运行，依赖 PyTorch、NumPy、Pillow、前一轮固定的 gated 权重和原训练划分。建议 CUDA 设备。

```powershell
python reconstruction_next/train_next.py --stage screen --device cuda
python reconstruction_next/train_next.py --stage extend --device cuda
python reconstruction_next/distill_mean.py --device cuda
```

第一阶段生成 `reconstruction_next/screen-selection.json`，记录四个分支的验证结果。第二阶段生成 `extended-selection.json`。只有最后一个命令生成正式的 `final-selection.json`。各候选训练曲线、检查点及其 5,000 张验证统计在本目录的子文件夹中。最终模型使用 `reconstruction_next/model_next.py` 的 `load_next_model(path, device)` 载入。

1. 两种尺寸均从各自的原 VAE 出发，比较原结构和加宽的卷积支路。新支路先把固定空间位置映到通道维度，在潜变量分辨率处理相邻特征，再投影到后验参数或解码输出；末层零初始化，因此初始函数与原模型逐元素一致。两支均训练 12 轮，第 6、12 轮验证。
2. 从第一阶段按验证指标选出的检查点继续训练，比较直接续训和增加一次编码反馈。反馈编码器先从粗均值还原一张图，把原图和这张图的误差按像素位置重排，与粗均值一起交给卷积网络，输出 4 通道修正。两个分支在同一尺寸下共用起点，各训练 28 轮。外部解码器仍只接收一个四通道潜变量。
3. 从第二阶段选出的网络出发，冻结其权重，给每张训练图的粗均值做 12 步 Adam 更新。损失含重建 MSE、高通误差和高斯 KL 中随均值变化的一项。再训练一个共享参数的卷积网络以三次固定前馈更新逼近这些均值，附加均值蒸馏 MSE 权重 0.12。该分支训练 24 轮，每 8 轮验证。部署推理只加载 VAE 权重，编码器通过普通卷积执行三次校正，计算过程中无需迭代优化器或读取训练图片。

默认 batch 为 256。训练时每轮重新打乱训练图，每批一半用重参数化后的随机 z 重建，另一半用 μ 重建，最后将重建 MSE 按 RGB 坐标及 batch 平均，并对高通重建误差加权 0.06。两种尺寸均采用 β=0.0003，KL 对潜变量坐标求和，除以 3,072，再对 batch 平均。验证与正式测试统一使用 μ，采用逐图 PSNR 和 SSIM 的均值，并将高通绝对误差乘以 255。

前两阶段只在 PSNR、SSIM、细节 MAE 三项都不劣于原基线的候选中选择，以验证集细节 MAE 最低者优先。蒸馏候选还需三项均不劣于生成教师目标所用的上一阶段模型。输入图片、自行估计的粗重建仅在编码时可用，解码输入形状一直是 [B, 4, 8, 8] 或 [B, 4, 16, 16]。
