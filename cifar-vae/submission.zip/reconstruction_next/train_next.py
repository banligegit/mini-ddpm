"""Compare VAE reconstructions using only the locked 45k/5k CIFAR training split."""
import argparse
import csv
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
import torch

from model_next import TASK, FeedbackVAE, WideVAE, load_gated_model, load_next_model
from appearance import appearance_errors
from cifar_data import load_split
from detail.train_detail import highpass_l1, write_json
from evaluate import ssim_per_image

HERE = Path(__file__).resolve().parent
SEED, BATCH, BETA, HIGHPASS = 2057, 256, 0.0003, 0.06
SPLIT_HASH = "fce1ef0581d4ed53b13b31b680b8d640723c3e7094dcd33ca409d1c5d1e09f3a"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checkpoint_ref(path):
    return (path.relative_to(TASK) if path.is_relative_to(TASK) else path).as_posix()


@torch.inference_mode()
def validate(model, val_x, device):
    model.eval()
    sums = torch.zeros(9, dtype=torch.float64, device=device)
    with torch.backends.cudnn.flags(benchmark=False, deterministic=False, allow_tf32=False):
        for raw in val_x.split(BATCH):
            x = raw.to(device=device, dtype=torch.float32) / 255
            mu, lv = model.encode(x)
            y = model.decode(mu)
            mse = (y - x).square().mean((1, 2, 3))
            kl = 0.5 * (mu.square() + lv.exp() - 1 - lv).flatten(1).sum(1)
            sigma = (0.5 * lv).exp().flatten(1).mean(1)
            metrics = torch.cat([mse[:, None], (-10 * mse.log10())[:, None],
                                 ssim_per_image(x, y)[:, None], appearance_errors(x, y),
                                 kl[:, None], (kl / mu[0].numel())[:, None], sigma[:, None]], dim=1)
            sums += metrics.sum(0, dtype=torch.float64)
    names = ("mse", "psnr", "ssim", "color_mae", "coarse_edge_mae", "local_detail_mae",
             "kl_per_image", "kl_per_coordinate", "average_sigma")
    return dict(zip(names, (sums / len(val_x)).tolist()))


def train(side, variant, parent_path, train_x, val_x, epochs, lr, out, device, *,
          beta=BETA, posterior_fraction=0.5):
    if beta <= 0 or not 0 < posterior_fraction <= 1:
        raise ValueError("Expected positive beta and a posterior fraction in (0, 1].")
    torch.manual_seed(SEED)
    model = load_next_model(parent_path)
    if variant == "wide" and not isinstance(model, WideVAE):
        wider = WideVAE(side)
        added = wider.load_state_dict(model.state_dict(), strict=False)
        assert not added.unexpected_keys and all("correction" in k for k in added.missing_keys)
        with torch.inference_mode():
            x = val_x[:4].float() / 255
            a, b = model.encode(x)
            c, d = wider.encode(x)
            assert torch.equal(a, c) and torch.equal(b, d) and torch.equal(model.decode(a), wider.decode(c))
        model = wider
    if variant == "feedback" and not isinstance(model, FeedbackVAE):
        model = FeedbackVAE(model)
    model.to(device=device, memory_format=torch.channels_last)
    out.mkdir(parents=True, exist_ok=True)
    params = sum(p.numel() for p in model.parameters())
    print(f"training {side} {variant} parameters={params:,} epochs={epochs}", flush=True)
    mixed = device.type == "cuda"
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, fused=mixed)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, epochs * math.ceil(len(train_x)/BATCH),
                                                            eta_min=lr/12)
    scaler = torch.amp.GradScaler(device.type, enabled=mixed, init_scale=1024)
    rng = torch.Generator(device=device).manual_seed(SEED)
    order = torch.Generator().manual_seed(SEED)
    checks = {max(1, epochs // 2), epochs}
    records = {}
    with (out / "history.csv").open("w", newline="", encoding="utf8") as f:
        log = csv.writer(f)
        log.writerow(("epoch", "mse", "kl_per_rgb", "highpass_l1", "total", "seconds"))
        for epoch in range(1, epochs + 1):
            begin = time.perf_counter()
            model.train()
            sums = torch.zeros(4,device=device,dtype=torch.float64)
            idx = torch.randperm(len(train_x), generator=order).to(device)
            for batch in idx.split(BATCH):
                x = train_x[batch].to(dtype=torch.float32, memory_format=torch.channels_last) / 255
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast(device.type, dtype=torch.float16, enabled=mixed):
                    mu, lv = model.encode(x)
                    noise = torch.randn(mu.shape, generator=rng, device=device)
                    # The first group samples q(z|x); any remaining images train at mu.
                    count = int(len(batch) * posterior_fraction)
                    sampled = mu[:count] + (0.5 * lv[:count]).exp() * noise[:count]
                    z = torch.cat([sampled, mu[count:]], dim=0)
                    y = model.decode(z)
                err = y.float() - x
                mse, hp = err.square().mean(), highpass_l1(err)
                kl = 0.5 * (mu.square() + lv.exp() - 1 - lv).flatten(1).sum(1).mean() / 3072
                total = mse + beta * kl + HIGHPASS * hp
                scaler.scale(total).backward()
                scaler.step(optimizer)
                scaler.update()
                scheduler.step()
                sums += torch.stack([mse, kl, hp, total]).detach() * len(x)
            values = (sums / len(train_x)).tolist()
            if not all(math.isfinite(v) for v in values):
                raise RuntimeError(f"Nonfinite training quantities for epoch {epoch}")
            seconds = time.perf_counter() - begin
            log.writerow((epoch, *values, seconds))
            f.flush()
            if epoch == 1 or epoch in checks:
                print(f"{side} {variant} epoch={epoch} mse={values[0]:.7f} sec={seconds:.1f}",flush=True)
            if epoch in checks:
                path = out / f"epoch-{epoch}.pt"
                tmp = path.with_suffix(".tmp")
                config = dict(parent_sha256=digest(parent_path), beta=beta, highpass=HIGHPASS, seed=SEED,
                              posterior_fraction=posterior_fraction, batch_size=BATCH, epoch=epoch, planned_epochs=epochs, lr=lr)
                architecture = ("feedback" if isinstance(model,FeedbackVAE) else
                                "wide" if isinstance(model,WideVAE) else "gated")
                backbone = "wide" if isinstance(getattr(model, "base", model),WideVAE) else "gated"
                torch.save(dict(side=side, architecture=architecture, backbone=backbone,
                                config=config, state_dict={k:v.cpu() for k,v in model.state_dict().items()}),tmp)
                tmp.replace(path)
                metrics = validate(model, val_x, device)
                metrics.update(sha256=digest(path), checkpoint=checkpoint_ref(path), parameters=params,
                               candidate=f"{out.name}-e{epoch}", epoch=epoch)
                records[str(epoch)] = metrics
                write_json(out / "validation.json",records)
                print(f"Validation {side} {out.name} {epoch}: {metrics['psnr']:.4f} / "
                      f"{metrics['ssim']:.6f} / {metrics['local_detail_mae']:.4f}",flush=True)


def select(base, candidates):
    eligible = [v for v in candidates if (v["psnr"] >= base["psnr"] and v["ssim"] >= base["ssim"] and
                                          v["local_detail_mae"] <= base["local_detail_mae"])]
    if not eligible:
        return dict(base, candidate="previous")
    # Prioritize a Pareto improvement over the baseline, then finer local details.
    return min(eligible, key=lambda v: (v["local_detail_mae"], -v["psnr"], -v["ssim"]))


def completed(folder, epochs, parent):
    summary = folder / "validation.json"
    if not summary.is_file():
        return False
    metrics = json.loads(summary.read_text("utf8"))
    if str(epochs) not in metrics:
        return False
    for record in metrics.values():
        saved = TASK / record["checkpoint"]
        if not saved.is_file() or digest(saved) != record["sha256"]:
            raise ValueError(f"Completed run refers to missing or changed checkpoint {saved}")
        config = torch.load(saved, map_location="cpu", weights_only=True)["config"]
        if config["parent_sha256"] != parent:
            raise ValueError(f"Completed run {folder} was initialized from a different checkpoint")
    return True


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--stage", choices=["screen","extend"], required=True)
    p.add_argument("--device", default="cuda")
    p.add_argument("--out",type=Path, default=HERE)
    args = p.parse_args()
    device = torch.device(args.device)
    torch.set_num_threads(4)
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    parents = json.loads((TASK / "gated_detail/final-selection.json").read_text("utf8"))["selected"]
    split_path = TASK / "refinement/beta/split.npz"
    if digest(split_path) != SPLIT_HASH:
        raise RuntimeError("Training split checksum mismatch")
    all_x, _ = load_split(TASK / "data", train=True)
    with np.load(split_path) as split:
        train_x = torch.from_numpy(all_x[split["train"]]).to(device)
        val_x = torch.from_numpy(all_x[split["val"]])
    del all_x
    summaries = {}
    for key, base in parents.items():
        path = TASK / base["checkpoint"]
        if digest(path) != base["sha256"]:
            raise ValueError(f"Incorrect baseline for side {key}")
        baseline = out / "train" / f"baseline-{key}.json"
        baseline.parent.mkdir(parents=True,exist_ok=True)
        if not baseline.exists():
            measurements = validate(load_gated_model(path, device), val_x, device)
            write_json(baseline, dict(base, **measurements))
        summaries[key] = json.loads(baseline.read_text("utf8"))

    if args.stage == "screen":
        for variant in ("continued", "wide"):
            for side in (8, 16):
                folder = out / "train" / f"{side}-{variant}"
                if not completed(folder,12,parents[str(side)]["sha256"]):
                    train(side,variant,TASK / parents[str(side)]["checkpoint"],train_x,val_x,12,.00035,folder,device)
    candidates = {}
    for side in (8,16):
        key = str(side)
        candidates[key] = []
        for variant in ("continued", "wide"):
            measurements = out / "train" / f"{side}-{variant}" / "validation.json"
            records = json.loads(measurements.read_text("utf8"))
            if "12" not in records:
                raise RuntimeError("Screening incomplete")
            candidates[key].extend(records.values())
        candidate = select(summaries[key],candidates[key])
        if args.stage == "extend":
            variant = "wide" if "-wide-" in candidate["candidate"] else "continued"
            for extension in (variant,"feedback"):
                dest = out / "train" / f"{side}-{extension}-extend"
                if not completed(dest,28,candidate["sha256"]):
                    train(side,extension,TASK / candidate["checkpoint"],train_x,val_x,28,.00028,dest,device)
        if args.stage != "screen":
            for folder in sorted((out / "train").glob(f"{side}-*-extend")):
                extra = json.loads((folder / "validation.json").read_text("utf8"))
                if "28" not in extra:
                    raise RuntimeError("Extension incomplete")
                candidates[key].extend(extra.values())
    summaries_path = out / ("screen-selection.json" if args.stage == "screen" else "extended-selection.json")
    report = dict(selection_final=False,split_sha256=SPLIT_HASH,
                  train_images=len(train_x),validation_images=len(val_x),seed=SEED,
                  screen_epochs=12,extended_epochs=28,batch_size=BATCH,beta=BETA,highpass=HIGHPASS,
                  selection="Require all three validation metrics to match or beat the baseline, then minimize detail MAE; ties favor PSNR, then SSIM.",
                  baseline=summaries,candidates=candidates,selected={k:select(summaries[k],v) for k,v in candidates.items()})
    write_json(summaries_path,report)


if __name__ == "__main__":
    main()
