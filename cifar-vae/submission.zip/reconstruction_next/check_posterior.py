"""Measure the cost of prioritizing posterior-mean reconstruction on the held-out split."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from appearance import appearance_errors
from cifar_data import load_split
from evaluate import ssim_per_image
from gated_detail.gated_model import load_gated_model


def quality(raw, decoded):
    mse = (raw - decoded).square().mean((1, 2, 3))
    psnr = -10 * torch.log10(mse.clamp_min(1e-12))
    return mse, psnr, ssim_per_image(raw, decoded), appearance_errors(raw, decoded)[:, 2]


@torch.inference_mode()
def measure(path, expected_hash, loader, images, device):
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected_hash:
        raise ValueError(f"Checkpoint does not match the validation lock: {path}")
    model = loader(path, device).eval()
    noise = torch.Generator().manual_seed(39107)
    totals = {}
    for batch in images.split(96):
        x = batch.to(device, dtype=torch.float32) / 255
        mu, logvar = model.encode(x)
        std = torch.exp(0.5 * logvar)
        eps = torch.randn(mu.shape, generator=noise).to(device)
        kl = 0.5 * (mu.square() + logvar.exp() - 1 - logvar)
        fields = {"mean_sigma": std.mean((1, 2, 3)), "kl_per_image": kl.sum((1, 2, 3)),
                  "kl_per_coordinate": kl.mean((1, 2, 3))}
        for tag, z in (("mu", mu), ("z", mu + std * eps)):
            scores = quality(x, model.decode(z))
            for metric, values in zip(("mse", "psnr", "ssim", "detail"), scores):
                fields[f"{tag}_{metric}"] = values
        for key, values in fields.items():
            totals[key] = totals.get(key, 0.) + values.double().sum().item()
    return {"sha256": expected_hash, **{k: v / len(images) for k, v in totals.items()}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", action="store_true", help="Measure the previous published VAEs")
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--data", type=Path, default=ROOT / "data")
    parser.add_argument("--out", type=Path, default=HERE / "diagnostics")
    args = parser.parse_args()
    torch.set_num_threads(4)
    torch.backends.cudnn.allow_tf32 = False
    if args.baseline:
        selection = ROOT / "gated_detail/final-selection.json"
        loader = load_gated_model
    else:
        from model_next import load_next_model
        selection = HERE / "final-selection.json"
        loader = load_next_model
    with np.load(ROOT / "refinement/beta/split.npz") as data:
        indices = data["val"]
    assert len(indices) == 5000 and len(np.unique(indices)) == len(indices)
    pixels = torch.from_numpy(load_split(args.data, train=True)[0][indices])
    lock = json.loads(selection.read_text(encoding="utf-8"))
    if not lock["selection_final"]:
        raise ValueError("The selection must be final before measuring the posterior.")
    report = dict(images=len(indices), split="45k/5k held-out training partition", epsilon_seed=39107,
                  posterior_draws_per_image=1, models={})
    for side in ("16", "8"):
        info = lock["selected"][side]
        report["models"][side] = measure(ROOT / info["checkpoint"], info["sha256"], loader, pixels, args.device)
    args.out.mkdir(parents=True, exist_ok=True)
    output = args.out / ("previous.json" if args.baseline else "selected.json")
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
