"""Render the three-page experiment report using the validation lock and paired measurements."""
import argparse
from html import escape
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SIDES = ("16", "8")
URL = "https://banligegit.github.io/mini-ddpm/cifar-vae/"


def read(path):
    return json.loads((HERE / path).read_text(encoding="utf-8"))


def table(headings, rows):
    head = "".join(f"<th>{x}</th>" for x in headings)
    body = "".join("<tr>" + "".join(f"<td>{v}</td>" for v in row) + "</tr>" for row in rows)
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def image(name, alt):
    url = (HERE / "results" / name).as_uri()
    return f'<img alt="{escape(alt)}" src="{url}">'


def page(number, title, body):
    return f'<section><header><b>mini-ddpm-cifar-vae</b><span>CIFAR-10　·　32 × 32 RGB</span></header><h1>{title}</h1>{body}<footer><span>卷积 VAE 重建实验</span><span>{number} / 3</span></footer></section>'


def report(lock, test, before, after, notes):
    first = read("results/first-submission/summary.json")
    if first["indices"] != test["indices"] or first["n"] != test["n"]:
        raise ValueError("Submission comparisons require the same test set and display indices")
    metrics_rows, loss_rows, posterior_rows, paired_rows = [], [], [], []
    for side in SIDES:
        spec = lock["selected"][side]
        if not (spec["sha256"] == test["models"][f"current{side}"]["sha256"] == after["models"][side]["sha256"]
                == first["models"][f"current{side}"]["sha256"]):
            raise ValueError("The posterior diagnostics and the test metrics must use the selected weights")
        for label, info in (("首次提交", first["models"]["first" + side]),
                            ("续训起点", test["models"]["previous" + side]),
                            ("本轮", first["models"]["current" + side])):
            metrics = info["metrics"]
            metrics_rows.append((f"{side}×{side}×4", label, f'{info["parameters"]:,}', f'{metrics["psnr"]:.3f}',
                                 f'{metrics["ssim"]:.5f}', f'{metrics["local_detail_mae"]:.3f}'))
        lookup = before["models"][side], after["models"][side]
        for version, diag in zip(("续训起点", "本轮"), lookup):
            posterior_rows.append((f"{side}×{side}", version, f'{diag["mean_sigma"]:.4f}',
                                   f'{diag["kl_per_coordinate"]:.3f}', f'{diag["mu_psnr"]:.2f}', f'{diag["z_psnr"]:.2f}'))
        paired = first["paired"][side]
        paired_rows.append((f"{side}×{side}", *(f'{paired[k]["improved_images"]:,}' for k in
                                                ("psnr", "ssim", "local_detail_mae")),
                            f'{paired["all_three_improved_images"]:,}'))
        loss_rows.append(tuple(notes["training_summary"][side]))

    page_one = page(1, "同样大小的编码能否保留更多细节？", f"""
    <p>CIFAR-10 每张照片含 3,072 个 RGB 数值。16×16×4 编码保留 1,024 个数，8×8×4 保留 256 个。我在两种尺寸上分别优化重建，再用同一批原图检查，从第一次提交到现在能多保留多少细节。</p>
    <h2>模型与训练</h2>
    <p>输入按 255 缩放到 [0,1]。编码器输出 μ 和 ℓ = log σ²，随机支路由 z = μ + exp(ℓ/2) ⊙ ε 采样。解码器只读取四通道潜变量，末层 sigmoid 将 RGB 映射回 [0,1]。8×8 版比 16×16 版多一级降采样和相应的上采样。</p>
    <p>{notes['architecture']}</p>
    <p class="math">{notes['objective']}</p>
    <p>{notes['training']}</p>
    {table(("尺寸","选中训练阶段","追加训练轮数¹","重建 MSE","KL / 3,072"),loss_rows)}
    <p class="small">¹ {notes['budget']}</p>
    <h2>把 5,000 张验证图留给选型</h2>
    <p>首次提交用 50,000 张训练图训练 10 轮。本轮固定用 45,000 张训练、5,000 张验证。各尺寸分别要求验证 PSNR、SSIM 不降、细节误差不升，再选细节误差最小的权重。测试集沿用历次报告的同一批照片。</p>
    <h2>官方测试结果　10,000 张</h2>
    {table(("潜变量","版本","参数量","PSNR / dB ↑","SSIM ↑","细节误差 ↓"),metrics_rows)}
    <p>{notes['main_result']}</p>
    <p><b>本实验选定 16×16×4 VAE 供题目六使用。</b>两种尺寸在相同照片上的细节差异与选型依据见第 2–3 页。</p>""")
    truck = {row["model"]: row["local_detail_mae"] for row in first["crops"] if row["test_index"] == 11}
    page_two = page(2, "首次提交和本轮重建，放回同一张原图看", f"""
    <figure class="full">{image('first-submission/full-comparison.png','十类原图，同一张照片在首次提交和本轮的重建')}<figcaption>图 1　每类取测试集的第一张。原图和首次重建取自第一次提交包，本轮用对应照片的后验均值 μ 重建。</figcaption></figure>
    <figure class="crop">{image('first-submission/crop-comparison.png','飞机、卡车、船在首次提交和本轮的相同区域及误差')}<figcaption>图 2　同一行取同一块 20×12 像素区域。看卡车窗框，16×16 的框内细节误差从 {truck['first16']:.2f} 降到 {truck['current16']:.2f}，8×8 从 {truck['first8']:.2f} 降到 {truck['current8']:.2f}。</figcaption></figure>
    <h2>从首次提交到本轮，逐张比较 10,000 张测试图</h2>
    {table(("潜网格","PSNR 提高","SSIM 提高","细节误差降低","三项都改善"),paired_rows)}
    <p class="small">PSNR 用 [0,1] RGB 的逐图 MSE 计算，再对 10,000 张求均值。SSIM 用 11×11 高斯窗（σ=1.5），在有效窗口及 RGB 通道上取均值。细节误差将原图和重建各减去自身的 3×3 局部均值，再取两者的平均绝对差并乘 255。边缘采用反射填充。</p>""")
    grids = "".join(f'<div><b>{name}</b>{image(file, name)}</div>' for name,file in
                    (("真实 CIFAR-10","real-reference.png"),("16×16×4 直接解码","prior16.png"),("8×8×4 直接解码","prior8.png")))
    cal = read("calibration16/roundtrip.json")
    if cal["checkpoint_sha256"] != lock["selected"]["16"]["sha256"]:
        raise ValueError("Latent calibration must correspond to the selected 16x16 encoder")
    detail_col = test["metrics"].index("local_detail_mae")
    with np.load(HERE / "results/per-image.npz") as pairs:
        count = np.count_nonzero(pairs["current16"][:, detail_col] < pairs["current8"][:, detail_col])
    detail16 = test["models"]["current16"]["metrics"]["local_detail_mae"]
    detail8 = test["models"]["current8"]["metrics"]["local_detail_mae"]
    page_three = page(3, "重建更清楚以后，潜变量发生了什么？", f"""
    <p>复用 5,000 张验证图，检查同一编码器分别用 μ 和抽得的 z 重建。每张图固定一份 ε，两版同尺寸权重使用相同 ε。KL 按潜坐标报告，便于比较 1,024 与 256 个坐标的模型。</p>
    {table(("潜网格","版本","平均 σ","KL / 坐标","用 μ / dB","用 z / dB"),posterior_rows)}
    <p>{notes['posterior']}</p>
    <h2>两个解码器各自从标准正态连续抽 32 张</h2>
    <div class="grids">{grids}</div>
    <p class="small">图 3　上方取官方测试集前 32 张作参照。下方两个解码器各自使用种子 2026，无筛选。先验采样没有配对原图。</p>
    <p>{notes['prior']}</p>
    <h2>选型结论　选定 16×16×4 VAE 供题目六使用</h2>
    <p>我把能否保住原图中的细线作为选型依据。看第 2 页的卡车，16×16 能分开相邻的窗框，8×8 容易将它们合在一起。逐张比较两份最终模型，{count:,} 张测试图用 16×16 重建时细节误差更低，平均为 {detail16:.2f}，8×8 为 {detail8:.2f}。为保留这些细节，我接受每张图保存 1,024 个潜变量的代价，是 8×8 的 4 倍，仍只有原图 3,072 个 RGB 数值的三分之一。</p>
    <p>选用的权重来自 16×16 蒸馏模型第 {lock["selected"]["16"]["epoch"]} 轮。配套的四通道标准化常数用 45,000 张训练图估计；在 5,000 张验证图上，标准化再还原导致的最大 RGB 差为 {cal["max_abs_rgb_error"]:.2g}。</p>
    <p class="small">方法来源　<a href="https://arxiv.org/abs/1312.6114">VAE 与重参数化</a>　·　<a href="https://proceedings.mlr.press/v80/marino18a.html">Marino 等，迭代推断</a>　·　<a href="https://www.cs.toronto.edu/~kriz/cifar.html">CIFAR-10 数据</a>　·　<a href="{URL}">网页原图对照</a>　·　<a href="{URL}submission.zip">代码与权重</a></p>""")
    return page_one + page_two + page_three


CSS = """
@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;color:#203039;font:10.6pt/1.58 'Microsoft YaHei','Noto Sans CJK SC',sans-serif}
section{width:210mm;height:297mm;padding:12mm 14mm 14mm;position:relative;break-after:page}section:last-child{break-after:auto}
header,footer{display:flex;justify-content:space-between;color:#426560;font-size:9pt}header{padding-bottom:2mm;border-bottom:1px solid #77928b}
footer{position:absolute;bottom:6mm;left:14mm;right:14mm;border-top:1px solid #c5d1ca;padding-top:1.2mm}h1{font-size:20.5pt;line-height:1.25;margin:4mm 0 3mm}
h2{font-size:13.2pt;margin:3.3mm 0 1.1mm}p{margin:1.7mm 0}.math{background:#e9f2ee;padding:2mm 3mm}.small,figcaption{font-size:8.9pt;color:#405b5c}
table{width:100%;border-collapse:collapse;font-size:9.6pt;line-height:1.4;margin:2mm 0}th,td{padding:1.1mm 1.4mm;border-bottom:1px solid #cfdbd7;text-align:right}th{background:#e6efeb}td:first-child,th:first-child{text-align:left}
figure{margin:2mm 0}figure img{width:100%;object-fit:contain;display:block}.full img{max-height:88mm}.crop img{max-height:78mm}figcaption{margin-top:1mm}
.grids{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1mm 4mm;text-align:center;font-size:9pt}.grids>div:first-child{grid-column:1 / -1}.grids img{display:block;width:74mm;margin:0.6mm auto 0;image-rendering:pixelated}a{color:#17655c}
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chrome", help="Use a specific Chrome or Chromium executable")
    args = parser.parse_args()
    lock = read("final-selection.json")
    if not lock["selection_final"]:
        raise ValueError("A final validation selection is required.")
    body = report(lock, read("results/metrics.json"), read("diagnostics/previous.json"),
                  read("diagnostics/selected.json"), read("report-notes.json"))
    html = f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>CIFAR-10 VAE 重建实验</title><style>{CSS}</style><body>{body}</body></html>'
    with TemporaryDirectory() as folder, sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=args.chrome, channel=None if args.chrome else "chrome")
        page_tab = browser.new_page()
        src = Path(folder) / "report.html"
        src.write_text(html, encoding="utf-8")
        page_tab.goto(src.as_uri(), wait_until="load")
        page_tab.evaluate("document.fonts.ready")
        if not page_tab.locator("img").evaluate_all("(imgs)=>imgs.length===5 && imgs.every(i=>i.complete && i.naturalWidth>0)"):
            raise ValueError("Report image missing")
        fits = page_tab.locator("section").evaluate_all("(ss)=>ss.map(s=>s.lastElementChild.previousElementSibling.getBoundingClientRect().bottom < s.querySelector('footer').getBoundingClientRect().top)")
        if not all(fits):
            raise ValueError(f"Content reaches the page footer: {fits}")
        page_tab.pdf(path=str(HERE / "report.pdf"), print_background=True, prefer_css_page_size=True)
        browser.close()


if __name__ == "__main__":
    main()
