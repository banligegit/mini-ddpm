"""Calibrate the supplied 8x8 or 16x16 VAE and verify its RGB round trip."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from detail.calibrate import main
from reconstruction_next.model_next import load_next_model

if __name__ == "__main__":
    main(model_loader=load_next_model, out_by_side={8: HERE / "calibration", 16: HERE / "calibration16"})
