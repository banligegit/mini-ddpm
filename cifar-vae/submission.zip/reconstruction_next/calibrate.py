"""Recompute training-channel scales for the selected 8x8 encoder and verify the RGB round trip."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from detail.calibrate import main
from reconstruction_next.model_next import load_next_model

if __name__ == "__main__":
    main(model_loader=load_next_model, default_out=HERE / "calibration")
