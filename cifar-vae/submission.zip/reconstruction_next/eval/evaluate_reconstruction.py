"""Evaluate locked CIFAR-10 VAE checkpoints with the original paired reconstruction protocol.

From task5 run:
    python reconstruction_next/eval/evaluate_reconstruction.py --device cuda
    python reconstruction_next/eval/evaluate_reconstruction.py --device cpu --selected-only
Results, original/reconstruction panels and fixed crops are saved in
reconstruction_next/results/. Read summary.csv for model-level metrics.
With --selected-only only the two newly selected checkpoints are loaded and
metrics are written separately to reconstruction_next/selected-results/.
"""
import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from torch.nn import functional as F

HERE = Path(__file__).resolve().parent
TASK = HERE.parents[1]
sys.path.insert(0, str(TASK))
from cifar_data import load_split
from context_detail.detail_by_texture import summarize_texture
from context_detail.evaluate_context import evaluate, read_selection
from detail.evaluate_detail import CROPS, METRICS, font_for_figures, to_pil
from gated_detail.evaluate_gated import selected_figures
from gated_detail.gated_model import load_gated_model
from paper_detail.evaluate_paper import score

DISPLAY = ("psnr", "ssim", "local_detail_mae")
BASE = TASK / "gated_detail/final-selection.json"
CHECKPOINTS = TASK / "reconstruction_next/final-selection.json"


def validation_check(args):
    specs = read_selection(BASE)
    split_file = TASK / "refinement/beta/split.npz"
    source = json.loads(BASE.read_text(encoding="utf-8"))
    digest = hashlib.sha256(split_file.read_bytes()).hexdigest()
    if digest != source["split_sha256"]:
        raise ValueError("Unexpected validation split")
    with np.load(split_file) as split:
        train, val = split["train"], split["val"]
        if len(train) != 45000 or len(val) != 5000 or len(np.unique(np.r_[train, val])) != 50000:
            raise ValueError("CIFAR-10 validation indices failed validation")
    px, _ = load_split(args.data, train=True)
    data = torch.from_numpy(px[val])
    report = dict(split_sha256=digest, count=len(data), device=args.device, models={})
    for side, spec in specs.items():
        net = load_gated_model(TASK / spec["checkpoint"], args.device)
        scores, _ = score(net, data, [], args.device, args.batch_size)
        metrics = dict(zip(METRICS, scores.mean(axis=0, dtype=np.float64).tolist()))
        measured = {key: metrics[key] for key in DISPLAY}
        saved = {key: spec[key] for key in DISPLAY}
        if not np.allclose(list(measured.values()), list(saved.values()), rtol=2e-5, atol=1e-6):
            raise ValueError(f"Baseline validation mismatch for side {side}: {measured} vs {saved}")
        report["models"][side] = dict(recalculated=measured, published=saved, sha256=spec["sha256"])
        print(side, measured, flush=True)
    (HERE / "baseline-validation.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")


def save_summary(args):
    results = json.loads((args.out / "metrics.json").read_text(encoding="utf-8"))
    checkpoints = {"current": read_selection(args.selection)}
    if not args.selected_only:
        reference = json.loads((TASK / "gated_detail/results/metrics.json").read_text(encoding="utf-8"))
        checkpoints = {"previous": read_selection(args.previous), **checkpoints}
    columns = [METRICS.index(name) for name in DISPLAY]
    rows = []
    with np.load(args.out / "per-image.npz") as arrays:
        for side in (16, 8):
            for release in checkpoints:
                key = f"{release}{side}"
                spec = checkpoints[release][side]
                saved = results["models"][key]
                n = spec["parameters"]
                saved.update(parameters=n, latent_chw=[4, side, side])
                mean = saved["metrics"]
                rows.append(dict(side=side, release=release, parameters=n, n=results["n"],
                                 **{k: mean[k] for k in DISPLAY}, checkpoint_sha256=spec["sha256"]))
            if args.selected_only:
                continue
            new = arrays[f"current{side}"][:, columns].astype(np.float64)
            old = arrays[f"previous{side}"][:, columns].astype(np.float64)
            locked = reference["models"][f"current{side}"]
            if checkpoints["previous"][side]["sha256"] != locked["sha256"]:
                raise ValueError("The comparison baseline differs from the published task-5 weights")
            measured = old.mean(axis=0)
            original = [locked["metrics"][key] for key in DISPLAY]
            if not np.allclose(measured, original, rtol=2e-5, atol=1e-6):
                raise ValueError(f"Baseline test reproduction mismatch: {measured} vs {original}")
            gain = (new-old)*np.array([1, 1, -1])
            spec = results["paired"][str(side)]
            spec["all_three_improved_images"] = int(np.all(gain > 0, axis=1).sum())
            for j, key in enumerate(DISPLAY):
                spec[key]["paired_gain_quantiles_10_50_90"] = np.quantile(gain[:,j], [.1,.5,.9]).tolist()
            print(f"side={side} improved all three on {spec['all_three_improved_images']}/{len(old)}", flush=True)
    results["metric_conventions"] = {
        "psnr": "Peak 1. Compute MSE on each image over all RGB components, then average per-image PSNR.",
        "ssim": "RGB-channel mean; Gaussian 11x11 valid window, sigma 1.5, range 1.",
        "local_detail_mae": "255 * MAE between the high-pass components obtained by subtracting each image's 3x3 reflect-padded local mean.",
        "paired_gain_quantiles": "Positive means improvement; for detail this is previous minus current."}
    temp = args.out / "metrics.json.tmp"
    temp.write_text(json.dumps(results, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    temp.replace(args.out / "metrics.json")
    with (args.out / "summary.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def show_detail_residuals(examples, out):
    """Plot the absolute high-pass residual in the three predeclared crop boxes."""
    previous = ["previous16", "current16", "previous8", "current8"]
    residuals = {}
    for key in previous:
        err = 255 * (examples[key] - examples["original"])
        local = F.avg_pool2d(F.pad(err, (1, 1, 1, 1), mode="reflect"), 3, stride=1)
        residuals[key] = (err - local).abs().mean(1)
    font, zh = font_for_figures()
    scale, pitch, top, row_h, limit = 7, 161, 80, 130, 24.0
    sheet = Image.new("RGB", (5*pitch + 10, top+len(CROPS)*row_h+42), "white")
    pen = ImageDraw.Draw(sheet)
    names = (["原图局部", "16×16 旧版", "16×16 新版", "8×8 旧版", "8×8 新版"] if zh else
             ["Original crop", "16x16 previous", "16x16 current", "8x8 previous", "8x8 current"])
    title = "局部细节误差图　同一点越亮，原图与重建图的细节差异越大" if zh else "Local detail errors. Brighter pixels indicate larger high-pass errors."
    pen.text((12, 17), title, font=font, fill="#152a30")
    for i, label in enumerate(names):
        pen.text(((i+0.5)*pitch, 57), label, font=font, fill="#152a30", anchor="mm")
    rows = []
    for row, (cls, idx, (x0, y0, x1, y1), zh_name, en_name) in enumerate(CROPS):
        y = top + row*row_h
        size = ((x1-x0)*scale, (y1-y0)*scale)
        true = to_pil(examples["original"][cls]).crop((x0, y0, x1, y1)).resize(size, Image.Resampling.NEAREST)
        sheet.paste(true, ((pitch-size[0])//2, y))
        pen.text((pitch/2, y+101), f"{zh_name if zh else en_name} #{idx}", font=font, fill="#152a30", anchor="mm")
        record = dict(test_index=idx, crop=en_name, x0=x0, y0=y0, x1=x1, y1=y1)
        for i, key in enumerate(previous, 1):
            crop = residuals[key][cls, y0:y1, x0:x1]
            record[key] = float(crop.mean())
            gray = crop.div(limit).clamp(0, 1).mul(255).round().byte().numpy()
            patch = Image.fromarray(gray).resize(size, Image.Resampling.NEAREST)
            sheet.paste(patch, (i*pitch+(pitch-size[0])//2, y))
            pen.text(((i+0.5)*pitch, y+101), f"{record[key]:.2f}", font=font, fill="#152a30", anchor="mm")
        rows.append(record)
    foot = ("统一色阶　黑 = 0　白 ≥ 24　｜　每格下方为该局部的平均绝对细节误差（0–255 单位）" if zh else
            "Shared scale: black = 0, white >= 24. Labels give crop-mean absolute detail error (0–255).")
    pen.text((12, sheet.height-36), foot, font=font, fill="#344c50")
    sheet.save(out / "paired-detail-errors.png", optimize=True)
    with (out / "crop-detail.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--previous", type=Path, default=BASE)
    p.add_argument("--selection", type=Path, default=CHECKPOINTS)
    p.add_argument("--out", type=Path)
    p.add_argument("--selected-only", action="store_true",
                   help="Load only the selected weights and skip all paired baseline comparisons")
    p.add_argument("--data", type=Path, default=TASK / "data")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--threads", type=int, default=6)
    p.add_argument("--baseline-validation", action="store_true",
                   help="Only recompute the previous release on the held-out 5,000 validation images")
    args = p.parse_args()
    if args.out is None:
        args.out = HERE.parent / ("selected-results" if args.selected_only else "results")
    if min(args.batch_size, args.threads) < 1:
        p.error("Batch size and thread count must be positive.")
    torch.set_num_threads(args.threads)
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    if args.baseline_validation:
        validation_check(args)
        return
    from reconstruction_next.model_next import load_next_model
    examples = evaluate(args, None if args.selected_only else load_gated_model, load_next_model)
    selected_figures(examples, args.out)
    save_summary(args)
    if not args.selected_only:
        show_detail_residuals(examples, args.out)
        summarize_texture(args.out, args.data)


if __name__ == "__main__":
    main()
