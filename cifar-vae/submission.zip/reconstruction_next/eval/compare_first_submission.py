"""Rebuild the first teacher submission versus final CIFAR-10 figures.

From the submission root:
    python reconstruction_next/eval/compare_first_submission.py --first-archive mini-ddpm-cifar-vae.zip
The historical ZIP is read without extracting its contents. The final two
checkpoints come from reconstruction_next/final-selection.json. Find the PNGs,
crop-detail.csv and summary.json under reconstruction_next/results/first-submission/.
"""
import argparse
import csv
import hashlib
import io
import json
import sys
from pathlib import Path
from zipfile import ZipFile

import numpy as np
import torch
from PIL import Image, ImageDraw
from torch.nn import functional as F

TASK = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(TASK), str(TASK / "paper_detail")]
from cifar_data import ARCHIVE_MD5, CLASS_NAMES, load_split
from detail.evaluate_detail import CROPS, METRICS, ZH_CLASSES, font_for_figures, to_pil
from model import load_model
from paper_detail.evaluate_paper import score, score_pairs
from reconstruction_next.model_next import load_next_model

FIRST_HASH = {
    16: "24bb5f3923853c6aada7085a7a1fe071d108acc54c2ba9c17f544e6bb4147db4",
    8: "9f5057df80e2d2ed5d9d04db8eb3e65bcbd1392929d699b3fcebed6613ed0fd4",
}
FIRST_ARCHIVE_SHA = "a63e99e9c6b208d2cc166536e4503e999d210f7974d218826151acf9342337b0"
ORDER = ("first16", "current16", "first8", "current8")
INK, MUTED = "#152c36", "#455963"


def verify(data, expected, label):
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError(f"Unexpected SHA-256 for {label}")


def local_errors(examples, indices):
    rows = []
    for key in ORDER:
        error = (examples[key] - examples["original"]) * 255
        low = F.avg_pool2d(F.pad(error, (1, 1, 1, 1), mode="reflect"), 3, stride=1)
        detail = (error - low).abs()
        for cls, index, (x0, y0, x1, y1), _, name in CROPS:
            if index != indices[cls]:
                raise ValueError("A predeclared crop no longer matches its test image")
            region = (cls, slice(None), slice(y0, y1), slice(x0, x1))
            rows.append(dict(test_index=index, class_name=CLASS_NAMES[cls], crop=name,
                             x0=x0, y0=y0, x1=x1, y1=y1, model=key,
                             rgb_mae=float(error[region].abs().mean()),
                             local_detail_mae=float(detail[region].mean())))
    return rows


def archived_panels(archive, predictions):
    """Preserve the pixels originally handed in; measure using float predictions separately."""
    panels = dict(predictions)
    sources = {}
    for key, name in (("original", "original"), ("first16", "recon16"), ("first8", "recon8")):
        member = f"runs/{name}.png"
        data = archive.read(member)
        with Image.open(io.BytesIO(data)) as strip:
            if strip.size != (320, 32):
                raise ValueError(f"Unexpected CIFAR-10 grid dimensions in {member}")
            array = np.stack([np.asarray(strip.convert("RGB").crop((32*i, 0, 32*(i+1), 32))) for i in range(10)])
        rounded = predictions[key].clamp(0, 1).mul(255).round().permute(0, 2, 3, 1).numpy()
        discrepancy = np.abs(array.astype(np.int16) - rounded.astype(np.int16))
        if (key == "original" and np.any(discrepancy)) or discrepancy.max() > 1:
            raise ValueError(f"Archive panels do not match the images and checkpoint for {key}")
        sources[key] = dict(path=member, sha256=hashlib.sha256(data).hexdigest(),
                            max_code_difference_from_rerun=int(discrepancy.max()),
                            different_uint8_channels=int(np.count_nonzero(discrepancy)))
        panels[key] = torch.from_numpy(array).permute(0, 3, 1, 2).float()/255
    return panels, sources


def crop_figure(examples, rows, directory):
    font, zh = font_for_figures()
    small = font.font_variant(size=16) if hasattr(font, "font_variant") else font
    pitch, top, row_height = 157, 40, 117
    sheet = Image.new("RGB", (6 * pitch, top + 3 * row_height + 31), "white")
    pen = ImageDraw.Draw(sheet)
    names = (["原图定位", "原图局部", "16×16 首次提交", "16×16 本轮", "8×8 首次提交", "8×8 本轮"]
             if zh else ["Location", "Original crop", "16x16 first", "16x16 final", "8x8 first", "8x8 final"])
    for col, name in enumerate(names):
        pen.text(((col + 0.5) * pitch, 18), name, font=font, fill=INK, anchor="mm")
    errors = {(r["test_index"], r["model"]): r["local_detail_mae"] for r in rows}
    nearest = Image.Resampling.NEAREST
    for row, (cls, index, box, zh_name, en_name) in enumerate(CROPS):
        y = top + row * row_height
        original = to_pil(examples["original"][cls])
        locator = original.resize((96, 96), nearest)
        a, b, c, d = box
        ImageDraw.Draw(locator).rectangle((3*a, 3*b, 3*c-1, 3*d-1), outline="#ff5b22", width=2)
        sheet.paste(locator, ((pitch - 96) // 2, y))
        pen.text((pitch/2, y+105), f"#{index}", font=small, anchor="mm", fill=MUTED)
        for col, key in enumerate(("original", *ORDER), 1):
            patch = to_pil(examples[key][cls]).crop(box).resize(((c-a)*7, (d-b)*7), nearest)
            sheet.paste(patch, (col * pitch + (pitch - patch.width)//2, y + 6))
            label = (zh_name if zh else en_name) if key == "original" else f"{errors[index,key]:.2f}"
            pen.text(((col+0.5)*pitch, y+105), label, font=small, fill=MUTED, anchor="mm")
    foot = ("橙框均为 20×12 像素，右侧按原像素放大 7 倍。重建图下方为框内细节误差（0–255，越低越好）。"
            if zh else "Orange: 20x12 source pixels, enlarged 7x. Values: mean crop detail error (0–255, lower is better).")
    pen.text((10, sheet.height-25), foot, font=small, fill=MUTED)
    sheet.save(directory / "crop-comparison.png", optimize=True)


def full_figure(examples, indices, directory):
    font, zh = font_for_figures()
    small = font.font_variant(size=15) if hasattr(font, "font_variant") else font
    left, pitch, row_height, top = 133, 101, 102, 49
    sheet = Image.new("RGB", (left + 10*pitch + 5, top + 5*row_height), "white")
    pen = ImageDraw.Draw(sheet)
    for col, (index, name) in enumerate(zip(indices, ZH_CLASSES if zh else CLASS_NAMES)):
        pen.text((left + (col+.5)*pitch, 13), name, font=font, anchor="mm", fill=INK)
        pen.text((left + (col+.5)*pitch, 35), f"#{index}", font=small, anchor="mm", fill=MUTED)
    captions = (["原图", "16×16 首次提交", "16×16 本轮", "8×8 首次提交", "8×8 本轮"] if zh else
                ["Original", "16x16 first", "16x16 final", "8x8 first", "8x8 final"])
    for row, (key, title) in enumerate(zip(("original", *ORDER), captions)):
        y = top + row*row_height
        pen.text((left/2, y+48), title, font=small, fill=INK, anchor="mm")
        for col, sample in enumerate(examples[key]):
            tile = to_pil(sample).resize((96, 96), Image.Resampling.NEAREST)
            sheet.paste(tile, (left + col*pitch + 2, y))
    sheet.save(directory / "full-comparison.png", optimize=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--first-archive", type=Path, default=TASK / "mini-ddpm-cifar-vae.zip")
    parser.add_argument("--data", type=Path, default=TASK / "data")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--threads", type=int, default=6)
    parser.add_argument("--out", type=Path, default=TASK / "reconstruction_next/results/first-submission")
    args = parser.parse_args()
    if min(args.batch_size, args.threads) < 1:
        parser.error("Batch size and thread count must be positive")
    if not args.first_archive.is_file():
        parser.error(f"Supply the historical mini-ddpm-cifar-vae.zip with --first-archive (missing {args.first_archive})")
    verify(args.first_archive.read_bytes(), FIRST_ARCHIVE_SHA, args.first_archive)
    torch.set_num_threads(args.threads)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    args.out.mkdir(parents=True, exist_ok=True)
    selected = json.loads((TASK / "reconstruction_next/final-selection.json").read_text(encoding="utf-8"))["selected"]
    pixels, labels = load_split(args.data, train=False)
    if len(pixels) != 10000:
        raise ValueError("Expected the complete official 10,000-image CIFAR-10 test set")
    indices = [int(np.flatnonzero(labels == i)[0]) for i in range(10)]
    x = torch.from_numpy(pixels)
    examples = {"original": x[indices].float()/255}
    individual = {}
    summary = dict(n=len(x), split="official CIFAR-10 test_batch", archive_md5=ARCHIVE_MD5,
                   torch=torch.__version__, device=args.device, batch_size=args.batch_size,
                   methods="decode(encode(x)[0]); float32, TF32 disabled; each image weighted equally",
                   example_rule="first test image of each class in official order, zero-based indices",
                   indices=indices, classes=list(CLASS_NAMES), models={}, paired={},
                   first_archive_sha256=FIRST_ARCHIVE_SHA,
                   first_public_release_git="f78d4b6210c41be475dc0fccb40f615d25a84850",
                   crop_error="0–255 units; compute 3×3 reflection-padded high-pass on each full-frame RGB "
                              "difference, then crop and average its absolute values; right/bottom excluded.")
    with ZipFile(args.first_archive) as archive:
        for key in ORDER:
            side = 16 if key.endswith("16") else 8
            if key.startswith("first"):
                source = f"runs/vae{side}.pt"
                weights = archive.read(source)
                digest = FIRST_HASH[side]
                verify(weights, digest, source)
                model = load_model(io.BytesIO(weights), args.device)
                provenance = f"{args.first_archive.name}!{source}"
            else:
                entry = selected[str(side)]
                provenance, digest = entry["checkpoint"], entry["sha256"]
                path = TASK / provenance
                verify(path.read_bytes(), digest, provenance)
                model = load_next_model(path, args.device)
            if model.side != side:
                raise ValueError(f"Wrong latent size in {provenance}")
            values, examples[key] = score(model, x, indices, args.device, args.batch_size)
            individual[key] = values
            metrics = dict(zip(METRICS, values.mean(axis=0, dtype=np.float64).tolist()))
            summary["models"][key] = dict(checkpoint=provenance, sha256=digest, side=side,
                                          parameters=sum(p.numel() for p in model.parameters()), metrics=metrics)
            print(f'{key}: PSNR={metrics["psnr"]:.4f}, SSIM={metrics["ssim"]:.5f}, detail={metrics["local_detail_mae"]:.4f}', flush=True)
            del model
        displays, summary["archived_panels"] = archived_panels(archive, examples)
    for side in (16, 8):
        first, current = individual[f"first{side}"], individual[f"current{side}"]
        pairs = score_pairs(first, current)
        delta = current - first
        improved = ((delta[:, METRICS.index("psnr")] > 0) &
                    (delta[:, METRICS.index("ssim")] > 0) &
                    (delta[:, METRICS.index("local_detail_mae")] < 0))
        pairs["all_three_improved_images"] = int(improved.sum())
        summary["paired"][str(side)] = pairs
    rows = local_errors(examples, indices)
    with (args.out / "crop-detail.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    summary["crops"] = rows
    crop_figure(displays, rows, args.out)
    full_figure(displays, indices, args.out)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")


if __name__ == "__main__":
    main()
