"""Restore the two previous VAE checkpoints for warm starts or paired comparisons."""
import argparse
import hashlib
import io
import json
from pathlib import Path
from tempfile import NamedTemporaryFile
from urllib.request import urlopen
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
REVISION = "346d7c5dc2b69d6f9405a4e0d3e3f8beffe65759"
URL = f"https://raw.githubusercontent.com/banligegit/mini-ddpm/{REVISION}/site/cifar-vae/submission.zip"
ARCHIVE_SHA256 = "f4ddeb454a4c1c92481491d97cb9a16a5abf8c147285e840b71b391144cd9d65"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, help="Use a local copy of the pinned previous release")
    args = parser.parse_args()
    selection = json.loads((ROOT / "gated_detail/final-selection.json").read_text(encoding="utf8"))
    missing = []
    for model in selection["selected"].values():
        path = ROOT / model["checkpoint"]
        if path.exists():
            if hashlib.sha256(path.read_bytes()).hexdigest() != model["sha256"]:
                raise ValueError(f"Unexpected contents at {path}; existing weights have been preserved")
        else:
            missing.append(model)
    if not missing:
        print("Both previous checkpoints match their published hashes.")
        return
    if args.archive:
        data = args.archive.read_bytes()
    else:
        with urlopen(URL, timeout=90) as response:
            data = response.read()
    if hashlib.sha256(data).hexdigest() != ARCHIVE_SHA256:
        raise ValueError("Previous submission archive failed SHA-256 verification")
    with ZipFile(io.BytesIO(data)) as archive:
        for model in missing:
            content = archive.read(model["checkpoint"])
            if hashlib.sha256(content).hexdigest() != model["sha256"]:
                raise ValueError(f"Invalid weight in archive: {model['checkpoint']}")
            path = ROOT / model["checkpoint"]
            path.parent.mkdir(parents=True, exist_ok=True)
            with NamedTemporaryFile(dir=path.parent, delete=False) as f:
                temp = Path(f.name)
                f.write(content)
            try:
                temp.replace(path)
            finally:
                temp.unlink(missing_ok=True)
            print(path)


if __name__ == "__main__":
    main()
