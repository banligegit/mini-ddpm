"""Create the portable task-five submission with exactly two deployable weights."""
from hashlib import sha256
import json
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def main():
    lock = json.loads((HERE / "final-selection.json").read_text(encoding="utf-8"))
    if not lock["selection_final"]:
        raise ValueError("Select weights on the validation partition before building the submission.")
    documents = [
        "model.py", "train.py", "evaluate.py", "cifar_data.py", "appearance.py", "export_web.py",
        "refinement/beta/split.npz", "latent_diagnostics/latent_io.py",
        "detail/train_detail.py", "detail/calibrate.py", "detail/evaluate_detail.py",
        "paper_detail/paper_model.py", "paper_detail/evaluate_paper.py",
        "context_detail/context_model.py", "context_detail/evaluate_context.py", "context_detail/detail_by_texture.py",
        "gated_detail/gated_model.py", "gated_detail/evaluate_gated.py", "gated_detail/export_best_web.py",
        "gated_detail/final-selection.json", "gated_detail/results/metrics.json",
        "reconstruction_next/report.pdf", "reconstruction_next/report-notes.json", "reconstruction_next/README.md",
        "reconstruction_next/train/README.md", "reconstruction_next/final-selection.json",
        "reconstruction_next/diagnostics/previous.json", "reconstruction_next/diagnostics/selected.json",
        "reconstruction_next/diagnostics/ablation.json", "reconstruction_next/diagnostics/latency.json",
        "reconstruction_next/calibration/channel-statistics.json", "reconstruction_next/calibration/roundtrip.json",
        "reconstruction_next/calibration16/channel-statistics.json", "reconstruction_next/calibration16/roundtrip.json",
        "reconstruction_next/results/metrics.json", "reconstruction_next/results/summary.csv",
        "reconstruction_next/results/crop-detail.csv",
        "reconstruction_next/results/texture-quartiles.json", "reconstruction_next/results/per-image.npz",
    ]
    paths = {ROOT / s for s in documents}
    for pattern in ("*.py", "eval/*.py", "eval/*.json", "train/*/history.csv", "train/*/validation.json",
                    "train/baseline*.json", "results/*.png", "screen-selection.json", "extended-selection.json", "training-notes.md"):
        paths.update(HERE.glob(pattern))
    checkpoints = {}
    for side in ("16", "8"):
        entry = lock["selected"][side]
        name = entry["checkpoint"]
        if sha256((ROOT / name).read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError(f"Wrong weights for latent size {side}")
        checkpoints[name] = entry["sha256"]
        paths.add(ROOT / name)
    with NamedTemporaryFile(dir=HERE, delete=False) as handle:
        tmp = Path(handle.name)
    try:
        with ZipFile(tmp, "w", compression=ZIP_DEFLATED, compresslevel=6) as z:
            z.write(HERE / "README.md", "README.md")
            for file in sorted(paths):
                z.write(file, file.relative_to(ROOT).as_posix())
        with ZipFile(tmp) as z:
            if z.testzip() or {n for n in z.namelist() if n.endswith(".pt")} != set(checkpoints):
                raise ValueError("Submission contents failed verification")
        final = HERE / "submission.zip"
        tmp.replace(final)
        print(f"{final} ({final.stat().st_size:,} bytes) {sha256(final.read_bytes()).hexdigest()}")
    finally:
        tmp.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
