"""Distill better training-set codes into a fixed, convolutional posterior encoder."""
import argparse
import csv
import json
import math
from pathlib import Path
import time

import numpy as np
import torch

from model_next import DistilledMeanVAE, FeedbackVAE, WideVAE, load_next_model
from train_next import BATCH, BETA, HERE, HIGHPASS, SEED, SPLIT_HASH, TASK, checkpoint_ref, completed, digest, select, validate
from cifar_data import load_split
from detail.train_detail import highpass_l1, write_json

TEACHER_STEPS, STUDENT_EPOCHS, CODE_WEIGHT = 12, 24, 0.12


def make_teacher(base, pixels, device):
    """Compute targets only for the 45,000 training pictures; never needed by inference."""
    size = (len(pixels), 4, base.side, base.side)
    cache = [torch.empty(size,device=device) for _ in range(3)]
    metrics = torch.zeros(4, dtype=torch.float64, device=device)
    for offset in range(0, len(pixels), BATCH):
        end = min(offset + BATCH, len(pixels))
        x = pixels[offset:end].to(dtype=torch.float32, memory_format=torch.channels_last) / 255
        with torch.no_grad():
            mu, lv = base.encode(x)
            cache[0][offset:end] = mu
            cache[1][offset:end] = lv
        code = mu.detach().clone().requires_grad_(True)
        optimizer = torch.optim.Adam([code], lr=0.04)
        for step in range(TEACHER_STEPS):
            optimizer.param_groups[0]["lr"] = 0.04 * (1 - 0.75 * step / (TEACHER_STEPS - 1))
            y = base.decode(code)
            residual = y - x
            mse, detail = residual.square().mean(), highpass_l1(residual)
            mean_penalty = 0.5 * code.square().flatten(1).sum(1).mean() / 3072
            objective = mse + HIGHPASS * detail + BETA * mean_penalty
            if step == 0:
                metrics[:2] += torch.stack([mse,detail]).detach() * len(x)
            optimizer.zero_grad(set_to_none=True)
            objective.backward()
            optimizer.step()
        with torch.no_grad():
            cache[2][offset:end] = code
            err = base.decode(code) - x
            metrics[2:] += torch.stack([err.square().mean(), highpass_l1(err)]) * len(x)
    return cache, (metrics / len(pixels)).tolist()


def fit(parent, train_x, val_x, out, device):
    torch.manual_seed(SEED)
    path = TASK / parent["checkpoint"]
    if digest(path) != parent["sha256"]:
        raise ValueError("Parent checkpoint mismatch")
    base = load_next_model(path, device).to(memory_format=torch.channels_last).eval().requires_grad_(False)
    model = DistilledMeanVAE(base).to(device=device,memory_format=torch.channels_last)
    out.mkdir(parents=True,exist_ok=True)
    print(f"Creating {base.side}x{base.side} teacher means on {len(train_x):,} training images",flush=True)
    start = time.perf_counter()
    (start_mu, lv, targets), train_stats = make_teacher(base, train_x, device)
    write_json(out / "teacher.json",
               dict(n=len(train_x), split_sha256=SPLIT_HASH, steps=TEACHER_STEPS,
                    lr_start=.04,lr_end=.01,optimizer="Adam",parent_sha256=parent["sha256"],
                    train_mse_before=train_stats[0],train_detail_before=train_stats[1]*255,
                    train_mse_after=train_stats[2],train_detail_after=train_stats[3]*255,
                    seconds=time.perf_counter()-start))
    print(f"Train teacher {base.side}: {train_stats}",flush=True)
    rng = torch.Generator(device=device).manual_seed(SEED)
    shuffle = torch.Generator().manual_seed(SEED)
    mixed = device.type == "cuda"
    opt = torch.optim.Adam(model.correct.parameters(),lr=.0009,fused=mixed)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, STUDENT_EPOCHS * math.ceil(len(train_x)/BATCH),eta_min=.00006)
    scaler = torch.amp.GradScaler(device.type, enabled=mixed, init_scale=1024)
    records = {}
    with (out / "history.csv").open("w",newline="",encoding="utf8") as f:
        writer = csv.writer(f)
        writer.writerow(("epoch","mse","kl_per_rgb","highpass_l1","latent_distillation_mse","total","seconds"))
        for epoch in range(1,STUDENT_EPOCHS+1):
            start = time.perf_counter()
            totals = torch.zeros(5,dtype=torch.float64,device=device)
            for ids in torch.randperm(len(train_x),generator=shuffle).to(device).split(BATCH):
                x = train_x[ids].to(dtype=torch.float32,memory_format=torch.channels_last)/255
                logvar, target = lv[ids], targets[ids]
                opt.zero_grad(set_to_none=True)
                with torch.autocast(device.type,dtype=torch.float16,enabled=mixed):
                    mu = model.refine(x,start_mu[ids])
                    k = len(ids)//2
                    noise = torch.randn(mu[:k].shape,generator=rng,device=device)
                    z = torch.cat([mu[:k] + (0.5*logvar[:k]).exp()*noise,mu[k:]],dim=0)
                    estimated = model.decode(z)
                err = estimated.float() - x
                mse,hp = err.square().mean(), highpass_l1(err)
                kl = 0.5*(mu.square()+logvar.exp()-1-logvar).flatten(1).sum(1).mean()/3072
                code_error = (mu-target).square().mean()
                loss = mse + HIGHPASS*hp + BETA*kl + CODE_WEIGHT*code_error
                scaler.scale(loss).backward()
                scaler.step(opt)
                scaler.update()
                sched.step()
                totals += torch.stack([mse,kl,hp,code_error,loss]).detach() * len(x)
            averages = (totals / len(train_x)).tolist()
            if not all(math.isfinite(x) for x in averages):
                raise ValueError("Nonfinite training objective")
            writer.writerow((epoch,*averages,time.perf_counter()-start))
            f.flush()
            if epoch == 1 or epoch % 8 == 0:
                print(f"Distilled {base.side} epoch {epoch} mse={averages[0]:.7f} teacher_mse={averages[3]:.6f}", flush=True)
            if epoch % 8 == 0:
                checkpoint = out / f"epoch-{epoch}.pt"
                tmp = checkpoint.with_suffix(".tmp")
                inner = base.base if isinstance(base,FeedbackVAE) else base
                config = dict(parent_sha256=parent["sha256"],epoch=epoch,teacher_steps=TEACHER_STEPS,
                              beta=BETA,highpass=HIGHPASS,code_weight=CODE_WEIGHT,posterior_fraction=0.5,
                              shared_updates=3,trainable_parameters=sum(p.numel() for p in model.correct.parameters()))
                torch.save(dict(side=base.side,architecture="distilled_mean",backbone="wide" if isinstance(inner,WideVAE) else "gated",
                                base_feedback=isinstance(base,FeedbackVAE),config=config,state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()}),tmp)
                tmp.replace(checkpoint)
                m = validate(model,val_x,device)
                m.update(candidate=f"{base.side}-distilled-e{epoch}",epoch=epoch,parameters=sum(p.numel() for p in model.parameters()),
                         checkpoint=checkpoint_ref(checkpoint),sha256=digest(checkpoint))
                records[str(epoch)] = m
                write_json(out / "validation.json",records)
                print(f"Validation distilled {base.side} epoch {epoch}: {m['psnr']:.4f} {m['ssim']:.6f} {m['local_detail_mae']:.4f}",flush=True)
    return records


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device",default="cuda")
    p.add_argument("--out",type=Path,default=HERE)
    args = p.parse_args()
    torch.set_num_threads(4)
    device, out = torch.device(args.device), args.out.resolve()
    # Keep the direct-training selection separate from the sole official lock.
    source = out / "extended-selection.json"
    report = json.loads(source.read_text("utf8"))
    split_path = TASK / "refinement/beta/split.npz"
    if digest(split_path) != SPLIT_HASH or report["split_sha256"] != SPLIT_HASH:
        raise ValueError("Unexpected training split")
    all_x,_ = load_split(TASK/"data",train=True)
    with np.load(split_path) as s:
        train_x = torch.from_numpy(all_x[s["train"]]).to(device)
        val_x = torch.from_numpy(all_x[s["val"]])
    del all_x
    report["distillation"] = dict(teacher_split="train only",steps=TEACHER_STEPS,
                                  student_epochs=STUDENT_EPOCHS, checkpoints=[8,16,24],code_weight=CODE_WEIGHT,
                                  selection="Student must also match or beat its own parent in all three metrics")
    for key in ("8","16"):
        parent = report["selected"][key]
        folder = out / "train" / f"{key}-distilled"
        summary = folder / "validation.json"
        if completed(folder,STUDENT_EPOCHS,parent["sha256"]):
            records = json.loads(summary.read_text("utf8"))
        else:
            records = fit(parent, train_x, val_x, folder, device)
        report["candidates"][key].extend(records.values())
        allowed = [m for m in records.values() if m["ssim"] >= parent["ssim"] and m["psnr"] >= parent["psnr"] and m["local_detail_mae"] <= parent["local_detail_mae"]]
        if allowed:
            report["selected"][key] = select(parent,allowed)
    report["selection_final"] = True
    write_json(out/"final-selection.json",report)


if __name__ == "__main__":
    main()
