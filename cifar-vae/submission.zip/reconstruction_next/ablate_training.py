"""Separate beta and posterior sampling effects in gated 16x16, using validation only."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from train_next import BATCH, HERE, HIGHPASS, SEED, SPLIT_HASH, TASK, digest, train
from cifar_data import load_split


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    device = torch.device(args.device)
    torch.set_num_threads(4)
    base = json.loads((TASK / "gated_detail/final-selection.json").read_text(encoding="utf-8"))["selected"]["16"]
    parent = TASK / base["checkpoint"]
    split = TASK / "refinement/beta/split.npz"
    if digest(parent) != base["sha256"] or digest(split) != SPLIT_HASH:
        raise ValueError("Input differs from the screening study")
    xs = load_split(TASK / "data", train=True)[0]
    with np.load(split) as groups:
        train_x = torch.from_numpy(xs[groups["train"]]).to(device)
        valid_x = torch.from_numpy(xs[groups["val"]])
    result = dict(side=16, epochs=12, seed=SEED, batch=BATCH, initial_lr=.00035, highpass=HIGHPASS,
                  parent_sha256=base["sha256"], split_sha256=SPLIT_HASH, used_in_selection=False, runs=[])
    for beta in (.003, .0003):
        for fraction in (1., .5):
            screened = HERE / "train/16-continued"
            if beta == .0003 and fraction == .5 and (screened / "epoch-12.pt").is_file():
                # The ordinary, unchanged architecture screening branch is exactly this cell.
                folder = screened
            else:
                folder = HERE / "ablation" / f"beta-{beta}-posterior-{fraction}"
                if not (folder / "epoch-12.pt").is_file() or not (folder / "validation.json").is_file():
                    train(16, "continued", parent, train_x, valid_x, 12, .00035, folder, device,
                          beta=beta, posterior_fraction=fraction)
            row = json.loads((folder / "validation.json").read_text(encoding="utf8"))["12"]
            checkpoint = TASK / row["checkpoint"]
            with checkpoint.open("rb") as f:
                conf = torch.load(f, map_location="cpu", weights_only=True)["config"]
            if (conf["parent_sha256"],conf["beta"],conf["posterior_fraction"]) != (base["sha256"],beta,fraction):
                raise ValueError("Unexpected ablation checkpoint")
            result["runs"].append(dict(beta=beta, posterior_fraction=fraction, architecture="gated",
                                       **{key: row[key] for key in ("psnr","ssim","local_detail_mae","kl_per_coordinate","sha256")}))
    path = HERE / "diagnostics/ablation.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")
    print(result["runs"], flush=True)


if __name__ == "__main__":
    main()
