"""Measure the encoding and decoding cost of the published and newly selected VAEs."""
import argparse
import hashlib
import json
from pathlib import Path
from statistics import median
import sys
from time import perf_counter

import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from cifar_data import load_split
from gated_detail.gated_model import load_gated_model
from reconstruction_next.model_next import load_next_model


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    device = torch.device(args.device)
    torch.set_num_threads(4)
    torch.backends.cudnn.allow_tf32 = False
    def sync():
        if device.type == "cuda":
            torch.cuda.synchronize(device)
    pixels, _ = load_split(ROOT / "data", train=True)
    x = torch.from_numpy(pixels[:32]).to(device, dtype=torch.float32).div(255)
    locks = (ROOT / "gated_detail/final-selection.json", HERE / "final-selection.json")
    models = {}
    for tag, path, loader in zip(("previous", "selected"), locks, (load_gated_model, load_next_model)):
        lock = json.loads(path.read_text(encoding="utf-8"))
        if not lock["selection_final"]:
            raise ValueError("Lock both selections before benchmarking")
        for side, spec in lock["selected"].items():
            checkpoint = ROOT / spec["checkpoint"]
            if hashlib.sha256(checkpoint.read_bytes()).hexdigest() != spec["sha256"]:
                raise ValueError(f"Mismatched weights at {checkpoint}")
            model = loader(checkpoint, device).eval()
            z = model.encode(x)[0]
            models[f"{tag}{side}"] = (model, z)
    results = {key: {"encoder_ms": [], "decoder_ms": []} for key in models}
    for i in range(12):
        keys = list(models)
        if i % 2:
            keys.reverse()
        for name in keys:
            model, mu = models[name]
            for field, fn, value in (("encoder_ms", model.encode, x), ("decoder_ms", model.decode, mu)):
                sync()
                begin = perf_counter()
                fn(value)
                sync()
                if i >= 3:
                    results[name][field].append(1000 * (perf_counter() - begin))
    output = dict(device=str(device), name=torch.cuda.get_device_name(device) if device.type == "cuda" else "CPU",
                  dtype="float32", batch=32, warmup=3, repetitions=9, torch=torch.__version__,
                  protocol="Same input photos, device and dtype; alternating model order; no transfers or file I/O.",
                  median_ms={k: {m: median(vals) for m, vals in measurements.items()} for k, measurements in results.items()},
                  measurements=results)
    path = HERE / "diagnostics/latency.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(output["median_ms"])


if __name__ == "__main__":
    main()
