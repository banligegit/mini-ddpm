"""Warm-started CIFAR VAE with an optional wider local analysis/synthesis transform."""
from pathlib import Path
import sys

import torch
from torch import nn

TASK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TASK))
from gated_detail.gated_model import GatedVAE, load_gated_model


class PhaseTransform(nn.Module):
    """Process a grid of RGB subpixels or latent coordinates with local neighbors."""
    def __init__(self, inputs, outputs, width=64):
        super().__init__()
        self.lift = nn.Conv2d(inputs, width, 3, padding=1)
        self.context = nn.Sequential(nn.SiLU(), nn.Conv2d(width, width, 3, padding=1),
                                     nn.SiLU(), nn.Conv2d(width, width, 3, padding=1))
        self.project = nn.Sequential(nn.SiLU(), nn.Conv2d(width, outputs, 1))
        nn.init.zeros_(self.project[-1].weight)
        nn.init.zeros_(self.project[-1].bias)

    def forward(self, x):
        h = self.lift(x)
        return self.project(h + self.context(h))


class WideVAE(GatedVAE):
    def __init__(self, side):
        super().__init__(side)
        scale = 32 // side
        phases = 3 * scale ** 2
        self.analysis_correction = nn.Sequential(nn.PixelUnshuffle(scale), PhaseTransform(phases, 8))
        self.synthesis_correction = nn.Sequential(PhaseTransform(4, phases), nn.PixelShuffle(scale))

    def encode(self, x):
        stats = self.encoder(x) + self.analysis(x) + self.analysis_correction(x)
        mu, logvar = stats.float().chunk(2, dim=1)
        return mu, logvar.clamp(-12, 8)

    def decode(self, z):
        logits = z
        for block in list(self.decoder.children())[:-1]:
            logits = block(logits)
        return torch.sigmoid(logits + self.synthesis(z) + self.synthesis_correction(z))


class FeedbackVAE(nn.Module):
    """Predict a correction to the posterior mean from the first reconstruction residual."""
    def __init__(self, base):
        super().__init__()
        self.base = base
        self.side = base.side
        self.fold = nn.PixelUnshuffle(32 // self.side)
        phases = 3 * (32 // self.side) ** 2
        self.correct = PhaseTransform(phases + 4, 4)

    def encode(self, x):
        mu, logvar = self.base.encode(x)
        # Detaching the provisional image avoids updating the decoder through
        # the encoder's feedback target. The final image trains the decoder.
        coarse = self.base.decode(mu).detach()
        residual = self.fold(x - coarse) * 8
        correction = self.correct(torch.cat([residual, mu], dim=1))
        return mu + correction, logvar

    def decode(self, z):
        return self.base.decode(z)

    def forward(self, x):
        mu, logvar = self.encode(x)
        return self.decode(mu + (0.5 * logvar).exp() * torch.randn_like(mu)), mu, logvar


class DistilledMeanVAE(nn.Module):
    """Three shared convolutional corrections trained to approximate a refined posterior mean."""
    def __init__(self, base):
        super().__init__()
        self.base = base
        self.side = base.side
        scale = 32 // self.side
        self.fold = nn.PixelUnshuffle(scale)
        self.correct = PhaseTransform(6 * scale ** 2 + 4, 4, width=96)

    def refine(self, x, mu):
        # The shared correction sees the current RGB error, coarse RGB values,
        # and the current four-channel code. Only the last code reaches decode().
        for _ in range(3):
            image = self.base.decode(mu)
            patches = self.fold(torch.cat([(x - image) * 8, image], dim=1))
            update = self.correct(torch.cat((patches, mu), dim=1))
            mu = mu + 0.25 * torch.tanh(update)
        return mu

    def encode(self, x):
        mu, logvar = self.base.encode(x)
        return self.refine(x, mu), logvar

    def decode(self, z):
        return self.base.decode(z)

    def forward(self, x):
        mu, logvar = self.encode(x)
        return self.decode(mu + (0.5 * logvar).exp() * torch.randn_like(mu)), mu, logvar


def load_next_model(checkpoint, device="cpu"):
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if state["architecture"] == "distilled_mean":
        base_cls = WideVAE if state["backbone"] == "wide" else GatedVAE
        body = base_cls(state["side"])
        if state["base_feedback"]:
            body = FeedbackVAE(body)
        model = DistilledMeanVAE(body)
    elif state["architecture"] == "feedback":
        base_cls = WideVAE if state["backbone"] == "wide" else GatedVAE
        model = FeedbackVAE(base_cls(state["side"]))
    elif state["architecture"] == "wide":
        model = WideVAE(state["side"])
    else:
        return load_gated_model(checkpoint, device)
    model.load_state_dict(state["state_dict"])
    return model.to(device).eval()
