"""Export the two validation-selected CIFAR VAEs and their official test results for Pages."""
import argparse
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK))
from gated_detail.export_best_web import export_selected
from reconstruction_next.model_next import load_next_model


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selection", type=Path, default=HERE / "final-selection.json")
    parser.add_argument("--results", type=Path, default=HERE / "results")
    parser.add_argument("--data", type=Path, default=TASK / "data")
    parser.add_argument("--output", type=Path, required=True, help="Destination site/cifar-vae directory")
    args = parser.parse_args()
    export_selected(args.selection, args.results, args.data, args.output, load_next_model)


if __name__ == "__main__":
    main()
