"""Read the original CIFAR-10 Python release after verifying its archive."""

import hashlib
import pickle
import shutil
import tarfile
import tempfile
from pathlib import Path
from urllib.request import urlopen

import numpy as np


URL = "https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
ARCHIVE_MD5 = "c58f30108f718f92721af3b95e74349a"
CLASS_NAMES = ("airplane", "automobile", "bird", "cat", "deer",
               "dog", "frog", "horse", "ship", "truck")


def check_archive(path):
    digest = hashlib.md5()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest() == ARCHIVE_MD5


def get_archive(data_dir):
    directory = Path(data_dir)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "cifar-10-python.tar.gz"
    if path.exists():
        if not check_archive(path):
            raise ValueError(f"Incomplete or invalid CIFAR-10 archive: {path}")
        return path
    with tempfile.NamedTemporaryFile(dir=directory, delete=False, suffix=".part") as f:
        temporary = Path(f.name)
    try:
        with urlopen(URL, timeout=90) as response, temporary.open("wb") as f:
            shutil.copyfileobj(response, f)
        if not check_archive(temporary):
            raise ValueError("Downloaded CIFAR-10 archive failed its checksum")
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)
    return path


def load_split(data_dir, train=False):
    names = [f"data_batch_{i}" for i in range(1, 6)] if train else ["test_batch"]
    batches = {}
    with tarfile.open(get_archive(data_dir), "r|gz") as archive:
        for entry in archive:
            name = entry.name.split("/")[-1]
            if entry.isfile() and name in names:
                with archive.extractfile(entry) as f:
                    batches[name] = pickle.loads(f.read(), encoding="bytes")
    images = np.concatenate([batches[name][b"data"] for name in names])
    labels = np.concatenate([batches[name][b"labels"] for name in names])
    return images.reshape(-1, 3, 32, 32), labels.astype(np.int64)
