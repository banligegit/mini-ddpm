"""Measure three visible kinds of reconstruction error on the CIFAR-10 test set."""

import argparse
import json
from pathlib import Path

import torch
from torch.nn import functional as F

from cifar_data import load_split
from model import load_model


def appearance_errors(original, restored):
    """Return per-image errors in 8-bit intensity units. Inputs have range [0, 1]."""
    # All three filters are linear, so filtering (restored - original) gives
    # exactly the difference between the two independently filtered images.
    error = (restored - original) * 255
    color = error.mean(dim=(2, 3)).abs().mean(1)
    blocks = F.avg_pool2d(error, kernel_size=4)
    horizontal = blocks.diff(dim=3).abs().mean(dim=(1, 2, 3))
    vertical = blocks.diff(dim=2).abs().mean(dim=(1, 2, 3))
    edge = (horizontal + vertical) / 2
    smooth = F.avg_pool2d(F.pad(error, (1, 1, 1, 1), mode="reflect"), 3, stride=1)
    detail = (error - smooth).abs().mean(dim=(1, 2, 3))
    return torch.stack((color, edge, detail), dim=1)


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--out", type=Path, default=Path("runs"))
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=256)
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    torch.set_num_threads(min(8, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    pixels, _ = load_split(args.data, train=False)
    pixels = torch.from_numpy(pixels)
    output = {"test_images": len(pixels), "units": "8-bit RGB intensity levels", "models": {}}
    for side in (16, 8):
        model = load_model(args.out / f"vae{side}.pt", args.device)
        total = torch.zeros(3, dtype=torch.float64, device=args.device)
        for batch in pixels.split(args.batch_size):
            images = batch.to(device=args.device, dtype=torch.float32) / 255
            mu, _ = model.encode(images)
            total += appearance_errors(images, model.decode(mu)).sum(0, dtype=torch.float64)
        names = ("mean_rgb_mae", "coarse_gradient_mae", "local_detail_mae")
        output["models"][str(side)] = dict(zip(names, (total / len(pixels)).tolist()))
    result = json.dumps(output, indent=2, allow_nan=False)
    (args.out / "appearance.json").write_text(result + "\n", encoding="utf-8")
    print(result)


if __name__ == "__main__":
    main()
