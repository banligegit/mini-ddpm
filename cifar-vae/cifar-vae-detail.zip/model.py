"""Convolutional VAE for 32x32 RGB images in [0, 1]."""

import torch
from torch import nn


class ConvVAE(nn.Module):
    def __init__(self, side, width=32):
        super().__init__()
        if side not in (8, 16):
            raise ValueError("latent side must be 8 or 16")
        self.side = side
        enc = [
            nn.Conv2d(3, width, 4, stride=2, padding=1), nn.SiLU(),
            nn.Conv2d(width, width, 3, padding=1), nn.SiLU(),
        ]
        if side == 8:
            enc.extend([nn.Conv2d(width, width, 4, stride=2, padding=1), nn.SiLU()])
        enc.append(nn.Conv2d(width, 8, 3, padding=1))
        self.encoder = nn.Sequential(*enc)
        dec = [nn.Conv2d(4, width, 3, padding=1), nn.SiLU()]
        if side == 8:
            dec.extend([nn.ConvTranspose2d(width, width, 4, stride=2, padding=1), nn.SiLU()])
        dec.extend([
            nn.Conv2d(width, width, 3, padding=1), nn.SiLU(),
            nn.ConvTranspose2d(width, 3, 4, stride=2, padding=1), nn.Sigmoid(),
        ])
        self.decoder = nn.Sequential(*dec)

    def encode(self, x):
        mu, logvar = self.encoder(x).float().chunk(2, dim=1)
        return mu, logvar.clamp(-12., 8.)

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = mu + torch.exp(0.5 * logvar) * torch.randn_like(mu)
        return self.decode(z), mu, logvar


def load_model(checkpoint, device="cpu"):
    saved = torch.load(checkpoint, map_location="cpu", weights_only=True)
    model = ConvVAE(saved["side"])
    model.load_state_dict(saved["state_dict"])
    return model.to(device).eval()
