# CIFAR-10 VAE 重建细节优化

请先打开 [实验说明与复现步骤](detail/README.md)。[局部对比图](detail/results/crop-comparison.png) · [网页演示](https://banligegit.github.io/mini-ddpm/cifar-vae/)
