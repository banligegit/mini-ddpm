"""Train and validate CIFAR-10 VAE reconstruction refinements on the fixed 45k/5k split."""
import argparse
import copy
import csv
import hashlib
import json
import math
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from torch.nn import functional as F

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK))
from appearance import appearance_errors
from cifar_data import load_split
from evaluate import save_grid, ssim_per_image
from model import ConvVAE, load_model
from train import train_one

SEED = 2026
BATCH = 256
BETA = 0.003
FORK = 40
EPOCHS = 60
WEIGHT = 0.075


def highpass_l1(error):
    low = F.avg_pool2d(F.pad(error, (1, 1, 1, 1), mode="reflect"), 3, stride=1)
    return (error - low).abs().mean()


def write_json(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def comparison_figures(out, report):
    """The regions are fixed in input pixel coordinates using the original images."""
    rows = [("Original", out / "validation-original.png")]
    for side in (8, 16):
        selected = report["selected"][str(side)]["candidate"]
        rows.append((f"{side} x {side}, 10 epochs", out / f"validation-{side}-mse10.png"))
        rows.append((f"{side} x {side}, selected", out / f"validation-{side}-{selected}.png"))
    font = ImageFont.load_default(size=16)
    full = [(class_name, i, 0, 0, 32) for i, class_name in enumerate(
        ("Airplane", "Auto", "Bird", "Cat", "Deer", "Dog", "Frog", "Horse", "Ship", "Truck"))]
    crops = [("Auto #46", 1, 2, 12, 16), ("Bird #6", 2, 12, 3, 16), ("Truck #208", 9, 7, 5, 16)]
    for name, boxes, tile in (("validation-comparison", full, 64), ("validation-crops", crops, 96)):
        left, top, gap = 146, 32, 5
        sheet = Image.new("RGB", (left + len(boxes)*(tile+gap), top + len(rows)*(tile+gap)), "white")
        draw = ImageDraw.Draw(sheet)
        for col, (title, index, x, y, size) in enumerate(boxes):
            px = left + col*(tile+gap)
            draw.text((px, 8), title, font=font, fill="black")
            for row, (label, path) in enumerate(rows):
                py = top + row*(tile+gap)
                if col == 0:
                    draw.text((5, py + (tile-16)//2), label, font=font, fill="black")
                with Image.open(path) as strip:
                    box = (index*32+x, y, index*32+x+size, y+size)
                    patch = strip.crop(box).resize((tile, tile), Image.Resampling.NEAREST)
                sheet.paste(patch, (px, py))
        sheet.save(out / f"{name}.png")


@torch.inference_mode()
def validation(checkpoint, pixels, examples, device, figure):
    model = load_model(checkpoint, device)
    sums = torch.zeros(6, dtype=torch.float64, device=device)
    with torch.backends.cudnn.flags(enabled=torch.backends.cudnn.enabled,
                                   benchmark=torch.backends.cudnn.benchmark,
                                   deterministic=torch.backends.cudnn.deterministic, allow_tf32=False):
        for batch in pixels.split(BATCH):
            x = batch.to(device, dtype=torch.float32) / 255
            recon = model.decode(model.encode(x)[0])
            mse = (x - recon).square().mean((1, 2, 3))
            scores = torch.cat((mse[:, None], -10*mse.log10()[:, None],
                                ssim_per_image(x, recon)[:, None], appearance_errors(x, recon)), dim=1)
            sums += scores.sum(0, dtype=torch.float64)
        save_grid(model.decode(model.encode(examples)[0]), figure)
    names = ("mse", "psnr", "ssim", "color_mae", "coarse_edge_mae", "local_detail_mae")
    found = dict(zip(names, (sums / len(pixels)).tolist()))
    found["sha256"] = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    found["checkpoint"] = (checkpoint.relative_to(TASK) if checkpoint.is_relative_to(TASK)
                           else checkpoint).as_posix()
    return found


def run_epochs(model, opt, sched, train_x, order, start, stop, detail_weight):
    history = []
    device = train_x.device
    mixed = device.type == "cuda" and torch.cuda.is_bf16_supported()
    for epoch in range(start, stop + 1):
        begin = time.perf_counter()
        totals = torch.zeros(4, dtype=torch.float64, device=device)
        shuffled = torch.randperm(len(train_x), generator=order).to(device)
        for indices in shuffled.split(BATCH):
            x = train_x[indices].to(dtype=torch.float32, memory_format=torch.channels_last).div_(255)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device.type, dtype=torch.bfloat16, enabled=mixed):
                recon, mu, lv = model(x)
            error = recon.float() - x
            mse = error.square().mean()
            kl = .5 * (mu.square() + lv.exp() - 1 - lv).flatten(1).sum(1).mean() / 3072
            detail = highpass_l1(error) if detail_weight else error.new_zeros(())
            loss = mse + BETA * kl + detail_weight * detail
            loss.backward()
            opt.step()
            sched.step()
            totals += torch.stack([mse, kl, detail, loss]).detach() * len(indices)
        averages = (totals / len(train_x)).tolist()
        if not all(math.isfinite(v) for v in averages):
            raise RuntimeError(f"Nonfinite objective at epoch {epoch}")
        history.append((epoch, *averages, detail_weight, time.perf_counter() - begin))
        if epoch == start or epoch % 10 == 0:
            print(f"{model.side}x{model.side} detail={detail_weight} epoch={epoch} "
                  f"MSE={averages[0]:.6f} time={history[-1][-1]:.2f}s", flush=True)
    return history


def train_branches(side, train_x, out):
    device = train_x.device
    torch.manual_seed(SEED)
    order = torch.Generator().manual_seed(SEED)
    model = ConvVAE(side).to(device=device, memory_format=torch.channels_last)
    opt = torch.optim.Adam(model.parameters(), lr=.002)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, T_max=EPOCHS * math.ceil(len(train_x)/BATCH), eta_min=.0002)
    common = run_epochs(model, opt, sched, train_x, order, 1, FORK, 0.)
    shared = copy.deepcopy((model.state_dict(), opt.state_dict(), sched.state_dict()))
    cpu_rng, order_rng = torch.get_rng_state(), order.get_state()
    cuda_rng = torch.cuda.get_rng_state(device) if device.type == "cuda" else None
    for name, weight in (("mse60", 0.), ("detail60", WEIGHT)):
        model.load_state_dict(shared[0])
        opt.load_state_dict(copy.deepcopy(shared[1]))
        sched.load_state_dict(shared[2])
        torch.set_rng_state(cpu_rng)
        order.set_state(order_rng)
        if cuda_rng is not None:
            torch.cuda.set_rng_state(cuda_rng, device)
        history = common + run_epochs(model, opt, sched, train_x, order, FORK + 1, EPOCHS, weight)
        path = out / f"{side}-{name}"
        path.mkdir(parents=True, exist_ok=True)
        with (path / "history.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(("epoch", "train_mse", "kl_per_pixel", "highpass_l1_if_active",
                             "total", "highpass_weight", "seconds"))
            writer.writerows(history)
        weight_path = path / f"vae{side}.pt"
        tmp = weight_path.with_suffix(".tmp")
        torch.save({"side": side, "state_dict": {k:v.cpu() for k,v in model.state_dict().items()},
                    "config": {"seed": SEED, "beta": BETA, "train_images": len(train_x),
                               "epochs": EPOCHS, "batch_size": BATCH, "fork_epoch": FORK,
                               "highpass_weight_after_fork": weight}}, tmp)
        tmp.replace(weight_path)
        yield name, weight_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--data", type=Path, default=TASK/"data")
    parser.add_argument("--out", type=Path, default=HERE,
                        help="Directory for validation.json and experiments/")
    parser.add_argument("--figures-only", action="store_true",
                        help="Rebuild grids from the saved validation outputs, without training.")
    args = parser.parse_args()
    torch.set_num_threads(min(torch.get_num_threads(), 8))
    output_root = args.out.resolve()
    out = output_root / "experiments"
    out.mkdir(parents=True, exist_ok=True)
    if args.figures_only:
        comparison_figures(out, json.loads((output_root / "validation.json").read_text(encoding="utf-8")))
        return
    array, labels = load_split(args.data, train=True)
    with np.load(TASK / "refinement/beta/split.npz") as split:
        tr, val = split["train"], split["val"]
    train_x = torch.from_numpy(array[tr]).to(args.device)
    val_x = torch.from_numpy(array[val])
    indices = [int(val[labels[val] == digit][0]) for digit in range(10)]
    examples = torch.from_numpy(array[indices]).to(args.device, dtype=torch.float32) / 255
    del array
    save_grid(examples, out / "validation-original.png")
    report = {"train_images": len(tr), "validation_images": len(val), "validation_indices": indices,
              "seed": SEED, "beta": BETA, "branch_at_epoch": FORK, "final_epoch": EPOCHS,
              "highpass_weight": WEIGHT, "selection": "Minimize validation local_detail_mae among "
              "candidates within 0.25 dB PSNR and 0.003 SSIM of their side's respective maxima.",
              "candidates": {}, "selected": {}}
    for side in (8, 16):
        models = report["candidates"][str(side)] = {}
        if side == 8:
            short = TASK / "refinement/beta/0.003/vae8.pt"
        else:
            short_dir = out / "16-mse10"
            short_dir.mkdir(exist_ok=True)
            config = SimpleNamespace(seed=SEED, lr=.002, batch_size=BATCH, epochs=10, beta=BETA, out=short_dir)
            train_one(16, train_x, config)
            short = short_dir / "vae16.pt"
        models["mse10"] = validation(short, val_x, examples, args.device, out / f"validation-{side}-mse10.png")
        for name, ckpt in train_branches(side, train_x, out):
            models[name] = validation(ckpt, val_x, examples, args.device, out / f"validation-{side}-{name}.png")
            print(name, side, models[name], flush=True)
            write_json(output_root / "validation.json", report)
        max_psnr = max(s["psnr"] for s in models.values())
        max_ssim = max(s["ssim"] for s in models.values())
        allowed = [k for k,v in models.items() if v["psnr"] >= max_psnr-.25 and v["ssim"] >= max_ssim-.003]
        chosen = min(allowed, key=lambda k: models[k]["local_detail_mae"])
        report["selected"][str(side)] = {"candidate": chosen, **models[chosen]}
        write_json(output_root / "validation.json", report)
        print("selected", side, chosen, flush=True)
    comparison_figures(out, report)


if __name__ == "__main__":
    main()
