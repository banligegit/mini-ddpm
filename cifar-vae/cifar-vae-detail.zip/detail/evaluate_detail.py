"""Compare frozen VAE reconstructions on the official CIFAR-10 test split.

Run after selecting one optimized checkpoint for each latent size on validation.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK))
from appearance import appearance_errors
from cifar_data import CLASS_NAMES, load_split
from evaluate import ssim_per_image
from model import load_model

METRICS = ("mse", "psnr", "ssim", "mean_rgb_mae", "coarse_gradient_mae", "local_detail_mae")
HIGHER_BETTER = {"psnr", "ssim"}
# Original test indices and crop coordinates were fixed before evaluating new weights.
# x0,y0 include the first pixel; x1,y1 are exclusive. All crops cover 20 x 12 pixels.
CROPS = (
    (0, 3, (4, 0, 24, 12), "飞机文字", "Airplane lettering"),
    (9, 11, (12, 5, 32, 17), "卡车车窗", "Truck window"),
    (8, 1, (5, 13, 25, 25), "船体边缘", "Ship hull"),
)
STATES = ("original", "baseline8", "optimized8", "baseline16", "optimized16")
ZH_LABELS = ("原图", "8×8 原版", "8×8 优化版", "16×16 原版", "16×16 优化版")
EN_LABELS = ("Original", "8x8 baseline", "8x8 optimized", "16x16 baseline", "16x16 optimized")
ZH_CLASSES = ("飞机", "汽车", "鸟", "猫", "鹿", "狗", "蛙", "马", "船", "卡车")


def font_for_figures():
    for path in ("C:/Windows/Fonts/msyh.ttc",
                 "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"):
        if Path(path).is_file():
            return ImageFont.truetype(path, 18), True
    return ImageFont.load_default(), False


def to_pil(tensor):
    arr = tensor.clamp(0, 1).mul(255).round().byte().permute(1, 2, 0).cpu().numpy()
    return Image.fromarray(arr)


def figures(examples, directory):
    font, chinese = font_for_figures()
    labels = ZH_LABELS if chinese else EN_LABELS
    classes = ZH_CLASSES if chinese else CLASS_NAMES
    tile, left, gap, top = 96, 132, 6, 38
    canvas = Image.new("RGB", (left + 10*(tile+gap), top+5*(tile+gap)), "white")
    draw = ImageDraw.Draw(canvas)
    for col, name in enumerate(classes):
        draw.text((left+col*(tile+gap)+tile//2, top//2), name, font=font, fill="#16252b", anchor="mm")
    for row, (state, name) in enumerate(zip(STATES, labels)):
        y = top + row*(tile+gap)
        draw.text((9, y+tile//2), name, fill="#16252b", font=font, anchor="lm")
        for j, source in enumerate(examples[state]):
            patch = to_pil(source).resize((tile, tile), Image.Resampling.NEAREST)
            canvas.paste(patch, (left+j*(tile+gap), y))
    canvas.save(directory / "full-comparison.png", optimize=True)

    # The orange outline is drawn only on the overview, never on compared crop pixels.
    row_height, pitch, image_y = 147, 151, 42
    zoom = Image.new("RGB", (pitch*6, image_y+(len(CROPS)-1)*row_height+132), "white")
    draw = ImageDraw.Draw(zoom)
    view_labels = (("原图定位", "原图局部") if chinese else ("Location", "Original crop")) + labels[1:]
    for col, label in enumerate(view_labels):
        draw.text((col*pitch+pitch//2, 14), label, font=font, fill="#16252b", anchor="mm")
    for row, (class_id, index, box, zh, en) in enumerate(CROPS):
        y = image_y + row*row_height
        reference = to_pil(examples["original"][class_id]).resize((96, 96), Image.Resampling.NEAREST)
        x0, y0, x1, y1 = box
        ImageDraw.Draw(reference).rectangle((3*x0, 3*y0, 3*x1-1, 3*y1-1), outline="#ff8e12", width=2)
        zoom.paste(reference, ((pitch-96)//2, y))
        draw.text((pitch//2, y+111), (zh if chinese else en)+f" #{index}", fill="#16252b",
                  font=font, anchor="mm")
        for col, state in enumerate(STATES, 1):
            patch = to_pil(examples[state][class_id]).crop(box).resize((140, 84), Image.Resampling.NEAREST)
            zoom.paste(patch, (col*pitch+(pitch-140)//2, y+6))
    zoom.save(directory / "crop-comparison.png", optimize=True)


@torch.inference_mode()
def score(checkpoint, side, images, indices, device, batch_size):
    model = load_model(checkpoint, device)
    if model.side != side:
        raise ValueError(f"Expected {side}x{side} weights, got {checkpoint}")
    chunks = []
    examples = torch.empty((len(indices), 3, 32, 32))
    for start in range(0, len(images), batch_size):
        x = images[start:start+batch_size].to(device=device, dtype=torch.float32) / 255
        y = model.decode(model.encode(x)[0])
        mse = (y - x).square().mean(dim=(1, 2, 3))
        common = torch.stack((mse, -10*mse.log10(), ssim_per_image(x, y)), dim=1)
        chunks.append(torch.cat((common, appearance_errors(x, y)), dim=1).cpu().numpy())
        for j, index in enumerate(indices):
            if start <= index < start+len(x):
                examples[j] = y[index-start].cpu()
    return np.concatenate(chunks), examples


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--optimized8", type=Path, required=True)
    parser.add_argument("--optimized16", type=Path, required=True)
    parser.add_argument("--baseline-dir", type=Path, default=TASK/"runs")
    parser.add_argument("--data", type=Path, default=TASK/"data")
    parser.add_argument("--out", type=Path, default=HERE/"results")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=256)
    args = parser.parse_args()
    if args.batch_size <= 0:
        parser.error("--batch-size must be positive")
    torch.set_num_threads(min(8, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    pixels, labels = load_split(args.data, train=False)
    if len(pixels) != 10000:
        raise ValueError("Expected the full official 10,000-image test split")
    indices = [int(np.flatnonzero(labels == label)[0]) for label in range(10)]
    for class_id, idx, *_ in CROPS:
        assert indices[class_id] == idx
    images = torch.from_numpy(pixels)
    args.out.mkdir(parents=True, exist_ok=True)
    summary = {"split": "official CIFAR-10 test", "n": len(images),
               "device": args.device, "torch": str(torch.__version__),
               "reconstruction": "posterior mean, float RGB in [0,1]; per-image metrics then average",
               "indices": indices, "classes": list(CLASS_NAMES),
               "crop_convention": "xyxy, left/top inclusive and right/bottom exclusive",
               "crops": [], "metric_columns": list(METRICS), "models": {}, "paired": {}}
    per_image = {}
    examples = {"original": images[indices].float().div(255)}
    for side, improved in [(8, args.optimized8), (16, args.optimized16)]:
        for variant, path in (("baseline", args.baseline_dir/f"vae{side}.pt"), ("optimized", improved)):
            key = variant + str(side)
            scores, examples[key] = score(path, side, images, indices, args.device, args.batch_size)
            if not np.isfinite(scores).all():
                raise ValueError(f"Non-finite metrics for {key}")
            per_image[key] = scores
            avg = dict(zip(METRICS, scores.mean(axis=0, dtype=np.float64).tolist()))
            summary["models"][key] = dict(checkpoint=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                                          metrics=avg)
        deltas = per_image["optimized"+str(side)].astype(np.float64) - per_image["baseline"+str(side)]
        paired = {}
        for col, metric in enumerate(METRICS):
            value = deltas[:,col]
            better = value if metric in HIGHER_BETTER else -value
            count = int(np.count_nonzero(better > 0))
            paired[metric] = {"mean_new_minus_old": float(value.mean()), "improved_images": count,
                              "unchanged_images": int(np.count_nonzero(better==0)),
                              "improved_fraction": count/len(value)}
        summary["paired"][str(side)] = paired
    for class_id, idx, box, _, en in CROPS:
        x0, y0, x1, y1 = box
        target = examples["original"][class_id, :, y0:y1, x0:x1]
        crop_mae = {}
        for state in STATES[1:]:
            y = examples[state][class_id, :, y0:y1, x0:x1]
            crop_mae[state] = float((y-target).abs().double().mean()*255)
        summary["crops"].append(dict(name=en, index=idx, box=list(box), mean_rgb_abs_error=crop_mae))
    figures(examples, args.out)
    np.savez_compressed(args.out/"per-image.npz", **per_image)
    text = json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False)
    temporary = args.out / "metrics.json.tmp"
    temporary.write_text(text+"\n", encoding="utf-8")
    temporary.replace(args.out/"metrics.json")
    print(json.dumps(summary["models"], indent=2))


if __name__ == "__main__":
    main()
