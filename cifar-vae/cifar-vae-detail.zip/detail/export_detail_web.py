"""Export the selected detail-optimized VAE pairs into the existing task-five Pages site."""

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK))
from cifar_data import load_split
from export_web import Decoder, MeanEncoder, checked_export, save_image
from model import load_model


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Existing site/cifar-vae directory")
    parser.add_argument("--data", type=Path, default=TASK / "data")
    args = parser.parse_args()
    torch.set_num_threads(2)
    report = json.loads((HERE / "results/metrics.json").read_text(encoding="utf-8"))
    selected = json.loads((HERE / "validation.json").read_text(encoding="utf-8"))["selected"]
    catalog = json.loads((args.output / "results.json").read_text(encoding="utf-8"))
    sample_dir = args.output / "samples"
    model_dir = args.output / "models"
    pictures, _ = load_split(args.data, train=False)
    images = {}
    for sample in catalog["samples"]:
        idx = sample["index"]
        original = np.array(Image.open(sample_dir / f"{idx}-original.png").convert("RGB"))
        if not np.array_equal(original, pictures[idx].transpose(1, 2, 0)):
            raise ValueError(f"Website sample {idx} does not match the official test image")
        images[idx] = torch.from_numpy(pictures[idx]).unsqueeze(0).float() / 255

    records = {}
    for side in (8, 16):
        selection = selected[str(side)]
        checkpoint = TASK / selection["checkpoint"]
        digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        if digest != selection["sha256"] or digest != report["models"][f"optimized{side}"]["sha256"]:
            raise ValueError(f"Selection and final evaluation disagree for {checkpoint}")
        model = load_model(checkpoint)
        enc, dec = MeanEncoder(model), Decoder(model)
        x = next(iter(images.values()))
        z = torch.randn(1, 4, side, side, generator=torch.Generator().manual_seed(2026))
        enc_error = checked_export(enc, x, model_dir / f"detail-encoder{side}.onnx", "x", "mu")
        dec_error = checked_export(dec, z, model_dir / f"detail-decoder{side}.onnx", "z", "rgb")
        for idx, picture in images.items():
            output = dec(enc(picture))[0].mul(255).round().clamp(0, 255).byte().numpy()
            save_image(output, sample_dir / f"{idx}-detail{side}.png")
        records[str(side)] = {}
        for version in ("baseline", "optimized"):
            metrics = report["models"][f"{version}{side}"]["metrics"]
            records[str(side)][version] = {name: metrics[name] for name in ("psnr", "ssim", "local_detail_mae")}
        records[str(side)]["optimized"].update(
            checkpoint_sha256=digest, encoder_max_abs=enc_error, decoder_max_abs=dec_error,
            candidate=selection["candidate"])
        print(f"{side}x{side}: encoder {enc_error:.3g}, decoder {dec_error:.3g}; candidate {selection['candidate']}")
    (args.output / "detail-results.json").write_text(
        json.dumps({"test_image_count": len(pictures), "models": records}, indent=2, allow_nan=False) + "\n",
        encoding="utf-8")


if __name__ == "__main__":
    main()
