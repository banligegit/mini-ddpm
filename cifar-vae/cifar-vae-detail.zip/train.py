"""Train matched CIFAR-10 VAEs; run from this directory."""

import argparse
import csv
import math
import time
from pathlib import Path

import torch
from torch.nn import functional as F

from cifar_data import load_split
from model import ConvVAE


def train_one(side, pixels, args):
    device = pixels.device
    torch.manual_seed(args.seed)
    order_rng = torch.Generator().manual_seed(args.seed)
    model = ConvVAE(side).to(device=device, memory_format=torch.channels_last)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    steps_per_epoch = math.ceil(len(pixels) / args.batch_size)
    decay = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=steps_per_epoch * args.epochs, eta_min=args.lr * 0.1)
    use_bf16 = device.type == "cuda" and torch.cuda.is_bf16_supported()
    path = args.out / f"history{side}.csv"
    fields = ("epoch", "mse", "kl_per_image", "kl_per_pixel", "beta", "total", "seconds")
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for epoch in range(1, args.epochs + 1):
            start = time.perf_counter()
            totals = torch.zeros(3, device=device, dtype=torch.float64)
            order = torch.randperm(len(pixels), generator=order_rng).to(device)
            for indices in order.split(args.batch_size):
                x = pixels[indices].to(dtype=torch.float32, memory_format=torch.channels_last).div_(255.)
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_bf16):
                    reconstruction, mu, logvar = model(x)
                mse = F.mse_loss(reconstruction.float(), x)
                kl = 0.5 * (mu.square() + logvar.exp() - 1 - logvar).flatten(1).sum(1).mean()
                loss = mse + args.beta * kl / x[0].numel()
                loss.backward()
                optimizer.step()
                decay.step()
                totals += torch.stack([mse, kl, loss]).detach() * len(indices)
            mse_avg, kl_avg, total_avg = (totals / len(pixels)).tolist()
            if not math.isfinite(total_avg):
                raise RuntimeError(f"Non-finite objective in epoch {epoch}")
            elapsed = time.perf_counter() - start
            writer.writerow(dict(zip(fields, (epoch, mse_avg, kl_avg, kl_avg / 3072,
                                              args.beta, total_avg, elapsed))))
            f.flush()
            print(f"latent={side} epoch={epoch}/{args.epochs} mse={mse_avg:.6f} "
                  f"KL/image={kl_avg:.2f} total={total_avg:.6f} time={elapsed:.1f}s", flush=True)
    checkpoint = args.out / f"vae{side}.pt"
    tmp = checkpoint.with_suffix(".pt.tmp")
    torch.save({
        "state_dict": {k: v.cpu() for k, v in model.state_dict().items()},
        "side": side, "config": {"epochs": args.epochs, "batch_size": args.batch_size,
        "beta": args.beta, "seed": args.seed, "lr": args.lr, "train_images": len(pixels),
        "precision": "bfloat16 autocast" if use_bf16 else "float32",
        "device": torch.cuda.get_device_name(device) if device.type == "cuda" else "cpu",
        "torch": str(torch.__version__)},
    }, tmp)
    tmp.replace(checkpoint)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--data", type=Path, default=Path("data"), help="official CIFAR-10 archive directory")
    parser.add_argument("--out", type=Path, default=Path("runs"), help="output directory")
    parser.add_argument("--sides", nargs="+", type=int, choices=(8, 16), default=[16, 8], help="latent spatial sizes")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu", help="PyTorch device")
    parser.add_argument("--epochs", type=int, default=10, help="full passes over the training set per model")
    parser.add_argument("--batch-size", type=int, default=256, help="training batch size")
    parser.add_argument("--seed", type=int, default=2026, help="initialization, shuffle and sampling seed")
    parser.add_argument("--lr", type=float, default=0.002, help="Adam initial learning rate, cosine decay to 10%")
    parser.add_argument("--beta", type=float, default=0.003, help="constant weight of KL per input RGB scalar")
    args = parser.parse_args()
    if args.batch_size < 1 or args.epochs < 1 or args.lr <= 0 or args.beta < 0:
        parser.error("batch size, epochs and learning rate must be positive; beta must be nonnegative")
    args.out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(min(8, torch.get_num_threads()))
    data, _ = load_split(args.data, train=True)
    pixels = torch.from_numpy(data).to(args.device)
    print(f"device={pixels.device} images={len(pixels)} sides={args.sides}", flush=True)
    for side in args.sides:
        train_one(side, pixels, args)


if __name__ == "__main__":
    main()
