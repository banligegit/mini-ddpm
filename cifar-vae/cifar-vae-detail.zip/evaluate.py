"""Evaluate both final VAEs using the same official CIFAR-10 test set."""

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from torch.nn import functional as F

from cifar_data import CLASS_NAMES, load_split
from model import load_model


def ssim_per_image(x, y):
    """RGB channel average, 11x11 valid Gaussian windows, population moments."""
    coords = torch.arange(-5, 6, dtype=x.dtype, device=x.device)
    g = torch.exp(-coords.square() / (2 * 1.5 ** 2))
    g = g / g.sum()
    kernel = torch.outer(g, g).expand(15, 1, 11, 11).contiguous()
    moments = torch.cat((x, y, x.square(), y.square(), x * y), dim=1)
    mx, my, exx, eyy, exy = F.conv2d(moments, kernel, groups=15).chunk(5, dim=1)
    vx = (exx - mx.square()).clamp_min(0.)
    vy = (eyy - my.square()).clamp_min(0.)
    cov = exy - mx * my
    c1, c2 = 0.01 ** 2, 0.03 ** 2
    score = ((2 * mx * my + c1) * (2 * cov + c2)
             / ((mx.square() + my.square() + c1) * (vx + vy + c2)))
    return score.mean(dim=(1, 2, 3))


def gradient_strength(x):
    """Mean absolute neighboring RGB difference, equally weighting both axes."""
    dx = (x[:, :, :, 1:] - x[:, :, :, :-1]).abs().mean(dim=(1, 2, 3))
    dy = (x[:, :, 1:] - x[:, :, :-1]).abs().mean(dim=(1, 2, 3))
    return (dx + dy) * 0.5


def save_grid(tensor, path, columns=10):
    images = tensor.detach().clamp(0, 1).mul(255).round().byte().permute(0, 2, 3, 1)
    images = images.cpu().contiguous().numpy()
    rows = [np.concatenate(images[i:i + columns], axis=1)
            for i in range(0, len(images), columns)]
    Image.fromarray(np.concatenate(rows, axis=0)).save(path)


def save_comparison(directory):
    """Align input and deterministic reconstructions by class without smoothing."""
    rows = [("Original", "original.png"), ("16 x 16 x 4", "recon16.png"),
            ("8 x 8 x 4", "recon8.png")]
    tile, gap, left, top = 96, 4, 108, 32
    width = left + len(CLASS_NAMES) * (tile + gap) + gap
    height = top + len(rows) * (tile + gap) + gap
    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.load_default(size=16)
    except TypeError:  # Pillow < 10.1
        font = ImageFont.load_default()
    for col, name in enumerate(CLASS_NAMES):
        x = left + col * (tile + gap)
        draw.text((x + tile / 2, top / 2), name.capitalize(), fill="black", font=font, anchor="mm")
    for row, (label, filename) in enumerate(rows):
        y = top + row * (tile + gap)
        draw.text((8, y + tile / 2), label, fill="black", font=font, anchor="lm")
        with Image.open(directory / filename) as strip:
            for col in range(len(CLASS_NAMES)):
                image = strip.crop((col * 32, 0, (col + 1) * 32, 32))
                canvas.paste(image.resize((tile, tile), Image.Resampling.NEAREST),
                             (left + col * (tile + gap), y))
    canvas.save(directory / "reconstruction-comparison.png", optimize=True)


@torch.inference_mode()
def evaluate_one(side, pixels, index, args):
    model = load_model(args.out / f"vae{side}.pt", args.device)
    # Double-precision accumulation keeps the final average insensitive to batch boundaries.
    sums = torch.zeros(6, device=args.device, dtype=torch.float64)
    for batch in pixels.split(args.batch_size):
        x = batch.to(device=args.device, dtype=torch.float32).div_(255.)
        mu, _ = model.encode(x)
        recon = model.decode(mu)
        mse = (x - recon).square().mean(dim=(1, 2, 3))
        psnr = -10 * mse.log10()  # Peak is 1; PSNR is averaged after taking the log.
        ssim = ssim_per_image(x, recon)
        color_error = (x.mean((2, 3)) - recon.mean((2, 3))).abs().mean(dim=1)
        sums += torch.stack([mse, psnr, ssim, color_error, gradient_strength(x),
                             gradient_strength(recon)]).sum(dim=1, dtype=torch.float64)
    names = ("test_mse", "psnr", "ssim", "mean_rgb_bias_abs",
             "original_gradient_abs_mean", "gradient_abs_mean")
    metrics = dict(zip(names, (sums / len(pixels)).tolist()))
    example = pixels[index].to(device=args.device, dtype=torch.float32).div_(255.)
    save_grid(model.decode(model.encode(example)[0]), args.out / f"recon{side}.png")
    rng = torch.Generator().manual_seed(args.prior_seed)
    prior = torch.randn(20, 4, side, side, generator=rng).to(args.device)
    save_grid(model.decode(prior), args.out / f"prior{side}.png")
    metrics.update(params=sum(p.numel() for p in model.parameters()), prior_seed=args.prior_seed,
                   latent_chw=[4, side, side], latent_scalars=4 * side * side,
                   scalar_compression=3072 / (4 * side * side))
    print(f"side={side} PSNR={metrics['psnr']:.4f} SSIM={metrics['ssim']:.5f}", flush=True)
    return metrics


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--data", type=Path, default=Path("data"), help="CIFAR-10 archive directory")
    parser.add_argument("--out", type=Path, default=Path("runs"), help="directory with both final checkpoints")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu", help="PyTorch device")
    parser.add_argument("--batch-size", type=int, default=256, help="test batch size")
    parser.add_argument("--prior-seed", type=int, default=202605, help="CPU normal draw seed for each prior grid")
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    torch.set_num_threads(min(8, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    data, labels = load_split(args.data)
    pixels = torch.from_numpy(data)
    index = [int(np.flatnonzero(labels == label)[0]) for label in range(len(CLASS_NAMES))]
    save_grid(pixels[index].float().div_(255.), args.out / "original.png")
    result = {
        "test_images": len(data), "reconstruction": "posterior mean",
        "display_indices": index, "display_classes": list(CLASS_NAMES), "prior_images_per_grid": 20,
        "image_range": [0, 1], "psnr_aggregation": "mean of per-image PSNR across RGB scalars",
        "ssim": "11x11 Gaussian sigma 1.5, valid windows, per-channel population covariance, L=1",
        "models": {str(side): evaluate_one(side, pixels, index, args) for side in (16, 8)},
    }
    save_comparison(args.out)
    output = args.out / "metrics.json"
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
