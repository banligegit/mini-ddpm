"""Export both trained VAE pairs and the test examples used by the Pages demo."""
import argparse
import json
from pathlib import Path

import numpy as np
import onnxruntime as ort
from PIL import Image
import torch
from torch import nn

from cifar_data import load_split
from model import load_model


class MeanEncoder(nn.Module):
    def __init__(self, vae):
        super().__init__()
        self.vae = vae

    def forward(self, x):
        mu, _ = self.vae.encode(x)
        return mu


class Decoder(nn.Module):
    def __init__(self, vae):
        super().__init__()
        self.vae = vae

    def forward(self, z):
        return self.vae.decode(z)


def checked_export(module, x, path, input_name, output_name):
    torch.onnx.export(
        module.eval(), (x,), path, dynamo=False, opset_version=17,
        input_names=[input_name], output_names=[output_name],
    )
    session = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
    actual, = session.run([output_name], {input_name: x.numpy()})
    reference = module(x).numpy()
    error = np.abs(actual - reference)
    if not np.isfinite(error).all() or error.max() > 2e-4:
        raise RuntimeError(f"{path.name} does not match PyTorch: {error.max()}")
    return float(error.max())


def save_image(chw, path):
    hwc = np.ascontiguousarray(chw.transpose(1, 2, 0))
    Image.fromarray(hwc).save(path)


@torch.inference_mode()
def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True,
                        help="Destination site/cifar-vae directory")
    parser.add_argument("--data", type=Path, default=root / "data")
    parser.add_argument("--runs", type=Path, default=root / "runs")
    args = parser.parse_args()
    torch.set_num_threads(2)
    model_dir, sample_dir = args.output / "models", args.output / "samples"
    for folder in (model_dir, sample_dir):
        folder.mkdir(parents=True, exist_ok=True)
    metrics = json.loads((args.runs / "metrics.json").read_text(encoding="utf-8"))
    pictures, labels = load_split(args.data, train=False)
    names = ["飞机", "汽车", "鸟", "猫", "鹿", "狗", "蛙", "马", "船", "卡车"]
    samples = [{"name": name, "index": int(np.flatnonzero(labels == d)[0])}
               for d, name in enumerate(names)]
    reference = {"samples": samples, "models": {}}
    for s in samples:
        idx = s["index"]
        save_image(pictures[idx], sample_dir / f"{idx}-original.png")
    for side in (16, 8):
        model = load_model(args.runs / f"vae{side}.pt")
        encoder, decoder = MeanEncoder(model), Decoder(model)
        x = torch.from_numpy(pictures[samples[0]["index"]]).unsqueeze(0).float().div_(255)
        encoder_error = checked_export(encoder, x, model_dir / f"encoder{side}.onnx", "x", "mu")
        z = torch.randn(1, 4, side, side, generator=torch.Generator().manual_seed(2026))
        decoder_error = checked_export(decoder, z, model_dir / f"decoder{side}.onnx", "z", "rgb")
        for sample in samples:
            idx = sample["index"]
            x = torch.from_numpy(pictures[idx]).unsqueeze(0).float().div_(255)
            output = decoder(encoder(x))[0].mul(255).round().clamp(0, 255).byte().numpy()
            save_image(output, sample_dir / f"{idx}-recon{side}.png")
        m = metrics["models"][str(side)]
        reference["models"][str(side)] = {
            "psnr": m["psnr"], "ssim": m["ssim"], "params": m["params"],
            "encoder_max_abs": encoder_error, "decoder_max_abs": decoder_error,
        }
        print(f"{side}x{side}: encoder max |error| {encoder_error:.3g}, decoder {decoder_error:.3g}")
    (args.output / "results.json").write_text(
        json.dumps(reference, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
