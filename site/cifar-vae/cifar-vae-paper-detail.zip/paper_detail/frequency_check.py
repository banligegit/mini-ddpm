"""Partition validation RGB reconstruction MSE into three Fourier frequency bands."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from paper_model import load_paper_model
from cifar_data import load_split

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


@torch.inference_mode()
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device",default="cpu")
    p.add_argument("--data",type=Path,default=ROOT / "data")
    p.add_argument("--run-dir",type=Path,default=HERE)
    args = p.parse_args()
    torch.set_num_threads(min(6,torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    val = json.loads((args.run_dir / "validation.json").read_text(encoding="utf-8"))
    if not val["selection_final"]:
        raise ValueError("Wait until model selection is final")
    pixels = load_split(args.data,train=True)[0]
    with np.load(ROOT / "refinement/beta/split.npz") as split:
        images = torch.from_numpy(pixels[split["val"]])
    f = torch.fft.fftfreq(32,device=args.device)
    radius = (f[:,None].square() + f[None,:].square()).sqrt()
    masks = (radius <= .125,(radius > .125) & (radius <= .25),radius > .25)
    output = {"split": "fixed validation split, posterior mean reconstructions",
              "images":len(images),"radial_units":"cycles per pixel",
              "bands":["r <= 1/8","1/8 < r <= 1/4","r > 1/4"],
              "metric":"sum of orthonormal 2D spectral error energy in band, divided by total RGB samples; contributions add to image MSE",
              "candidates":{}}
    for side,candidates in val["candidates"].items():
        records = output["candidates"][side] = {}
        for key,spec in candidates.items():
            checkpoint = ROOT / spec["checkpoint"]
            if hashlib.sha256(checkpoint.read_bytes()).hexdigest() != spec["sha256"]:
                raise ValueError(f"Weight mismatch: {checkpoint}")
            model = load_paper_model(checkpoint,args.device)
            sums = torch.zeros(4,device=args.device,dtype=torch.float64)
            for batch in images.split(128):
                x = batch.to(args.device,torch.float32) / 255
                error = model.decode(model.encode(x)[0]) - x
                energy = torch.fft.fft2(error,norm="ortho").abs().square()
                for i,mask in enumerate(masks):
                    sums[i] += energy[...,mask].sum(dtype=torch.float64)
                sums[3] += error.square().sum(dtype=torch.float64)
            low,mid,high,mse = (sums / images.numel()).tolist()
            if abs(low+mid+high-mse) > 1e-8 or abs(spec["mse"]-mse) > 1e-6:
                raise ValueError("Spectral energy must sum to the previous validation MSE")
            records[key] = dict(low=low,mid=mid,high=high,mse=mse)
    text = json.dumps(output,indent=2,allow_nan=False)
    (args.run_dir / "frequency-bands.json").write_text(text+"\n",encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
