"""Fit train-only posterior-mean scaling for the newly selected 8x8 checkpoint."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from detail.calibrate import main
from paper_model import load_paper_model

if __name__ == "__main__":
    main(model_loader=load_paper_model, default_out=HERE / "calibration")
