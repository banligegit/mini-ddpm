"""Export validation-selected round-three VAEs and verify the complete ONNX path."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import onnxruntime as ort
from PIL import Image
import torch

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK))
from cifar_data import load_split
from export_web import Decoder, MeanEncoder, checked_export, save_image
from paper_model import load_paper_model


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Existing site/cifar-vae folder")
    parser.add_argument("--data", type=Path, default=TASK / "data")
    args = parser.parse_args()
    torch.set_num_threads(2)
    validation = json.loads((HERE / "validation.json").read_text(encoding="utf-8"))
    if validation.get("selection_final") is not True:
        raise ValueError("Validation selection must be locked before export")
    selected = validation["selected"]
    scores = json.loads((HERE / "results/metrics.json").read_text(encoding="utf-8"))
    catalog = json.loads((args.output / "results.json").read_text(encoding="utf-8"))
    originals, _ = load_split(args.data, train=False)
    samples = args.output / "samples"
    models = args.output / "models"
    images = {}
    for sample in catalog["samples"]:
        idx = sample["index"]
        with Image.open(samples / f"{idx}-original.png") as im:
            assert np.array_equal(np.array(im.convert("RGB")), originals[idx].transpose(1, 2, 0))
        images[idx] = torch.from_numpy(originals[idx]).float().unsqueeze(0) / 255

    records = {}
    for side in (16, 8):
        choice = selected[str(side)]
        path = TASK / choice["checkpoint"]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        result = scores["models"][f"current{side}"]
        if digest != choice["sha256"] or digest != result["sha256"]:
            raise ValueError(f"Checkpoint does not match validation and test records: {path}")
        model = load_paper_model(path, "cpu").eval()
        enc_path = models / f"paper-encoder{side}.onnx"
        dec_path = models / f"paper-decoder{side}.onnx"
        enc_error = checked_export(MeanEncoder(model), next(iter(images.values())), enc_path, "x", "mu")
        noise = torch.randn(1, 4, side, side, generator=torch.Generator().manual_seed(2026))
        dec_error = checked_export(Decoder(model), noise, dec_path, "z", "rgb")
        enc = ort.InferenceSession(str(enc_path), providers=["CPUExecutionProvider"])
        dec = ort.InferenceSession(str(dec_path), providers=["CPUExecutionProvider"])
        rgb_error = 0.
        for idx, x in images.items():
            torch_rgb = model.decode(model.encode(x)[0])
            mu, = enc.run(["mu"], {"x": x.numpy()})
            rgb, = dec.run(["rgb"], {"z": mu})
            error = float(np.abs(rgb - torch_rgb.numpy()).max())
            if not np.isfinite(error) or error > 2e-4:
                raise RuntimeError(f"ONNX reconstruction mismatch for {side}x{side} sample {idx}: {error}")
            rgb_error = max(rgb_error, error)
            save_image(torch_rgb[0].mul(255).round().clamp(0, 255).byte().numpy(), samples / f"{idx}-paper{side}.png")
        row = {k: result["metrics"][k] for k in ("psnr", "ssim", "local_detail_mae")}
        row.update(checkpoint_sha256=digest, candidate=choice["candidate"], encoder_max_abs=enc_error,
                   decoder_max_abs=dec_error, ten_image_rgb_max_abs=rgb_error)
        records[str(side)] = row
        print(f"{side}x{side}: max float RGB error for 10 images = {rgb_error:.3g}", flush=True)
    (args.output / "paper-results.json").write_text(
        json.dumps({"test_image_count": scores["n"], "models": records}, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
