"""Measure the frozen 8x8 VAE on each official CIFAR-10 split separately."""

import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK))
from cifar_data import load_split
from model import load_model


def pearson(a, b):
    # Both arrays are views of a single channel. Never pair across images.
    a = a - a.mean()
    b = b - b.mean()
    rms_product = np.sqrt(np.mean(a * a) * np.mean(b * b))
    if rms_product == 0:
        raise ValueError("Pearson correlation is undefined for a constant channel")
    return float(np.mean(a * b) / rms_product)


def describe(x, edges, within_image=False):
    channels, horizontal, vertical = [], [], []
    centered_horizontal, centered_vertical = [], []
    for channel in range(x.shape[1]):
        v = x[:, channel].astype(np.float64)
        channels.append({"mean": float(v.mean()), "std": float(v.std())})
        horizontal.append(pearson(v[:, :, :-1], v[:, :, 1:]))
        vertical.append(pearson(v[:, :-1, :], v[:, 1:, :]))
        if within_image:
            v -= v.mean(axis=(1, 2), keepdims=True)
            centered_horizontal.append(pearson(v[:, :, :-1], v[:, :, 1:]))
            centered_vertical.append(pearson(v[:, :-1, :], v[:, 1:, :]))
    counts, _ = np.histogram(x, edges)
    below, above = int((x < edges[0]).sum()), int((x > edges[-1]).sum())
    assert int(counts.sum()) + below + above == x.size
    result = {
        "global": {"mean": float(x.mean(dtype=np.float64)),
                   "std": float(x.std(dtype=np.float64)),
                   "p05": float(np.quantile(x, 0.05)), "median": float(np.median(x)),
                   "p95": float(np.quantile(x, 0.95))},
        "channels": channels,
        "neighbor_pearson": {"horizontal": horizontal, "vertical": vertical},
        "histogram": {"edges": edges.tolist(), "counts": counts.tolist(),
                      "below": below, "above": above},
    }
    if within_image:
        result["neighbor_pearson_after_image_channel_centering"] = {
            "horizontal": centered_horizontal, "vertical": centered_vertical,
        }
    return result


@torch.inference_mode()
def measure_split(model, train, args, seeds):
    pixels, _ = load_split(args.data, train=train)
    n = len(pixels)
    expected = 50000 if train else 10000
    if n != expected:
        raise ValueError(f"Expected {expected} images, received {n}")
    shape = (n, 4, 8, 8)
    mu, logvar = np.empty(shape, dtype=np.float32), np.empty(shape, dtype=np.float32)
    for i in range(0, n, args.batch_size):
        batch = torch.from_numpy(pixels[i:i + args.batch_size]).to(args.device, torch.float32) / 255
        m, lv = model.encode(batch)
        mu[i:i + len(batch)] = m.cpu().numpy()
        logvar[i:i + len(batch)] = lv.cpu().numpy()
    del pixels
    sigma = np.exp(0.5 * logvar)
    rng = np.random.default_rng(seeds["posterior"])
    z = mu + sigma * rng.standard_normal(shape, dtype=np.float32)
    prior = np.random.default_rng(seeds["prior"]).standard_normal(shape, dtype=np.float32)
    distributions = {}
    signed_edges = np.linspace(-5.0, 5.0, 101)
    for name, values in (("mu", mu), ("sigma", sigma), ("z", z), ("prior", prior)):
        edges = np.linspace(0.0, 2.0, 101) if name == "sigma" else signed_edges
        distributions[name] = describe(values, edges, within_image=name in ("z", "prior"))

    mu_term = 0.5 * np.mean(mu.astype(np.float64) ** 2)
    lv = logvar.astype(np.float64)
    variance_term = 0.5 * np.mean(np.expm1(lv) - lv)
    posterior_variance = np.exp(lv).mean(axis=(0, 2, 3))
    conditional_mean_variance = np.array([s["std"] ** 2 for s in distributions["mu"]["channels"]])
    pooled_mu_variance = distributions["mu"]["global"]["std"] ** 2
    return {
        "images": n, "coordinates_per_image": 256, "seeds": seeds,
        "distributions": distributions,
        "kl": {
            "mean_term_per_coordinate": float(mu_term),
            "variance_term_per_coordinate": float(variance_term),
            "per_coordinate_nats": float(mu_term + variance_term),
            "mean_per_image_nats": float((mu_term + variance_term) * 256),
        },
        "variance_decomposition": {
            "by_channel": {
                "var_mu": conditional_mean_variance.tolist(),
                "mean_sigma_squared": posterior_variance.tolist(),
                "expected_var_z": (conditional_mean_variance + posterior_variance).tolist(),
                "sampled_var_z": [s["std"] ** 2 for s in distributions["z"]["channels"]],
            },
            "global": {"var_mu": pooled_mu_variance,
                       "mean_sigma_squared": float(posterior_variance.mean()),
                       "expected_var_z": float(pooled_mu_variance + posterior_variance.mean()),
                       "sampled_var_z": distributions["z"]["global"]["std"] ** 2},
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=TASK / "data")
    parser.add_argument("--checkpoint", type=Path, default=TASK / "runs" / "vae8.pt")
    parser.add_argument("--output", type=Path, default=HERE / "results.json")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--seed", type=int, default=20261123)
    args = parser.parse_args()
    if args.batch_size < 1 or args.seed < 0:
        parser.error("batch-size must be positive and seed nonnegative")
    torch.set_num_threads(min(torch.get_num_threads(), 8))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    model = load_model(args.checkpoint, args.device).requires_grad_(False)
    if model.side != 8:
        parser.error("This diagnostic requires an 8x8 checkpoint.")
    result = {
        "checkpoint": args.checkpoint.name,
        "checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        "latent_chw": [4, 8, 8], "seed": args.seed, "device": str(args.device),
        "torch_version": str(torch.__version__), "numpy_version": np.__version__,
        "aggregation": "Means and population SD (ddof=0) over images and spatial positions; global also pools channels.",
        "pearson_method": "Pearson over pairs of adjacent spatial coordinates in the same image and channel; pooled across images and all valid positions for each direction, without per-image centering.",
        "sampling": "One float32 NumPy PCG64 diagonal-posterior draw per image; independent iid standard normal tensor of the same shape for the prior. No image selection.",
        "splits": {},
    }
    for offset, name in enumerate(("train", "test")):
        base = args.seed + 2 * offset
        result["splits"][name] = measure_split(model, name == "train", args,
                                               {"posterior": base, "prior": base + 1})
        print(f"{name}: {result['splits'][name]['images']} frozen encodings", flush=True)
    serialized = json.dumps(result, indent=2, allow_nan=False)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temp = args.output.with_suffix(args.output.suffix + ".tmp")
    temp.write_text(serialized + "\n", encoding="utf-8")
    temp.replace(args.output)
    print(args.output)


if __name__ == "__main__":
    main()
