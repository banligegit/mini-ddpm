"""Intervene only on latent positions and measure paired reconstruction on CIFAR-10."""

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont

TASK5 = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(TASK5))
from cifar_data import CLASS_NAMES, load_split
from evaluate import ssim_per_image
from model import load_model


def permute_positions(z, orders):
    """Move entire four-channel vectors, retaining all 64 vectors of each image."""
    flat = z.flatten(2)
    index = orders[:, None, :].expand_as(flat)
    shuffled = flat.gather(2, index)
    restored = shuffled.gather(2, index.argsort(dim=2))
    if not torch.equal(flat, restored):
        raise RuntimeError("The spatial permutation was not exactly reversible")
    return shuffled.reshape_as(z)


def image_metrics(original, reconstruction):
    mse = (original - reconstruction).square().mean((1, 2, 3))
    return torch.stack((mse, -10 * mse.log10(), ssim_per_image(original, reconstruction)), dim=1)


def make_grid(rows, path):
    # Use Chinese when a CJK font is installed, otherwise use the bundled Latin font.
    font_paths = [Path("C:/Windows/Fonts/msyh.ttc"),
                  Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
                  Path("/System/Library/Fonts/PingFang.ttc")]
    font_path = next((p for p in font_paths if p.exists()), None)
    if font_path:
        font = ImageFont.truetype(str(font_path), 17)
        classes = ["飞机","汽车","鸟","猫","鹿","狗","蛙","马","船","卡车"]
        labels = ["原图", "后验均值 μ", "后验采样 z", "打乱 z 的位置", "先验采样"]
        gap_label = "标准正态独立抽样：下排十张没有目标类别，与上方各列不配对"
    else:
        font = ImageFont.load_default(size=15)
        classes = CLASS_NAMES
        labels = ["Original", "Mean", "Posterior", "Shuffled", "Prior"]
        gap_label = "Independent prior draws; columns have no target class."
    tile, pad, left, head, split = 88, 5, 148, 32, 34
    width = left + 10 * (tile + pad)
    height = head + 5 * (tile + pad) + split
    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)
    for col, name in enumerate(classes):
        x = left + col * (tile + pad)
        draw.text((x + tile / 2, head / 2), name, anchor="mm", fill="#212121", font=font)
    for row, images in enumerate(rows):
        y = head + row * (tile + pad)
        if row == 4:
            draw.line((12, y + 2, width - pad, y + 2), fill="#cccccc")
            draw.text((left, y + split / 2), gap_label, anchor="lm", fill="#333333", font=font)
            y += split
        draw.text((10, y + tile / 2), labels[row], anchor="lm", fill="#212121", font=font)
        pixels = images.clamp(0, 1).mul(255).round().byte().permute(0, 2, 3, 1).cpu().numpy()
        for col, array in enumerate(pixels):
            small = Image.fromarray(array)
            canvas.paste(small.resize((tile, tile), Image.Resampling.NEAREST),
                         (left + col * (tile + pad), y))
    canvas.save(path)


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=TASK5 / "data")
    parser.add_argument("--weights", type=Path, default=TASK5 / "runs/vae8.pt")
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("batch size must be positive")
    device = torch.device(args.device)
    torch.set_num_threads(min(8, torch.get_num_threads()))
    if device.type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    vae = load_model(args.weights, device)
    if vae.side != 8:
        raise ValueError("This experiment uses the 8 x 8 latent model")
    pixels, labels = load_split(args.data)
    indices = [int(np.flatnonzero(labels == i)[0]) for i in range(10)]
    indices_t = torch.tensor(indices)
    posterior_seed, perm_seed, prior_seed = 20261123, 20261124, 20261125
    eps = torch.randn(len(pixels), 4, 8, 8, generator=torch.Generator().manual_seed(posterior_seed))
    rng = torch.Generator().manual_seed(perm_seed)
    orders = torch.stack([torch.randperm(64, generator=rng) for _ in pixels])
    names = ["mu", "posterior_z", "spatially_permuted_z"]
    sums = torch.zeros((3, 3), dtype=torch.float64, device=device)
    grid = torch.empty(4, len(indices), 3, 32, 32)
    for start in range(0, len(pixels), args.batch_size):
        sl = slice(start, start + args.batch_size)
        x = torch.from_numpy(pixels[sl]).to(device=device, dtype=torch.float32) / 255
        mu, logvar = vae.encode(x)
        z = mu + torch.exp(0.5 * logvar) * eps[sl].to(device)
        shuffled = permute_positions(z, orders[sl].to(device))
        selected = torch.where((indices_t >= start) & (indices_t < start + len(x)))[0]
        local = (indices_t[selected] - start).to(device)
        grid[0, selected] = x[local].cpu()
        for i, latent in enumerate((mu, z, shuffled)):
            recon = vae.decode(latent)
            sums[i] += image_metrics(x, recon).sum(0, dtype=torch.float64)
            grid[i + 1, selected] = recon[local].cpu()
    prior = torch.randn(10, 4, 8, 8, generator=torch.Generator().manual_seed(prior_seed))
    args.out.mkdir(parents=True, exist_ok=True)
    make_grid([*grid, vae.decode(prior.to(device)).cpu()], args.out / "spatial-control.png")
    metrics = {name: dict(zip(("mse", "psnr_db", "ssim"), values))
               for name, values in zip(names, (sums / len(pixels)).tolist())}
    result = {
        "checkpoint_sha256": hashlib.sha256(args.weights.read_bytes()).hexdigest(),
        "test_images": len(pixels), "example_selection": "first official test image per class",
        "example_indices": indices, "sample_count_per_input": 1,
        "seeds": dict(posterior=posterior_seed, permutation=perm_seed, prior=prior_seed),
        "paired_metrics": metrics,
        "metric_definition": "Mean over per-image RGB MSE/PSNR/SSIM, data range 1, task5 evaluate.py SSIM.",
        "permutation": "Independent uniform random permutation of 64 positions per image, shared by all 4 channels, using exactly the same sampled z as the posterior row.",
        "exact_inverse_recovered_for_all_images": True,
        "prior": "Ten unfiltered independent standard-normal tensors with no reference image or class.",
        "device": str(device), "torch_version": str(torch.__version__),
    }
    text = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)
    (args.out / "spatial-control.json").write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
