"""Plot the marginal distribution and neighboring-site correlations of held-out z."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap
import numpy as np


def set_fonts(font_path):
    if font_path is not None:
        font_manager.fontManager.addfont(font_path)
        family = font_manager.FontProperties(fname=font_path).get_name()
    else:
        installed = {font.name for font in font_manager.fontManager.ttflist}
        choices = ["Microsoft YaHei", "Noto Sans CJK SC", "Source Han Sans SC",
                   "PingFang SC", "WenQuanYi Zen Hei", "SimHei"]
        family = next((name for name in choices if name in installed), None)
        if family is None:
            raise SystemExit("Please supply a Chinese font with --font PATH.")
    plt.rcParams.update({"font.family": [family, "DejaVu Sans"], "font.size": 10,
                         "axes.unicode_minus": False, "axes.edgecolor": "#73777B",
                         "axes.labelcolor": "#24282D", "text.color": "#24282D",
                         "xtick.color": "#45494C", "ytick.color": "#45494C"})


def plot(data, output):
    test = data["splits"]["test"]
    distributions = test["distributions"]
    sample_count = test["images"] * 4 * 8 * 8
    fig = plt.figure(figsize=(10.5, 4.9))
    fig.text(.075, .91, "CIFAR-10 编码得到的 8 × 8 × 4 潜变量",
             size=17, weight="bold")
    fig.text(.075, .835, f"测试集 {test['images']:,} 张图，每张从后验抽取一次 z。独立标准正态对照使用相同数量的坐标。",
             size=10, color="#525A61")
    density_ax = fig.add_axes([.075, .17, .395, .51])
    corr_ax = fig.add_axes([.655, .20, .315, .47])

    colors = {"z": "#0072B2", "prior": "#B54D12"}
    labels = {"z": "真实图像编码后采样 z", "prior": "独立标准正态对照"}
    for key in ("z", "prior"):
        histogram = distributions[key]["histogram"]
        edges = np.asarray(histogram["edges"])
        counts = np.asarray(histogram["counts"])
        widths = np.diff(edges)
        if counts.size != widths.size or not np.all(widths > 0):
            raise ValueError(f"Invalid histogram for {key}")
        if int(counts.sum()) + histogram["below"] + histogram["above"] != sample_count:
            raise ValueError(f"Histogram accounting mismatch for {key}")
        density = counts / (sample_count * widths)
        if key == "z":
            density_ax.stairs(density, edges, fill=True, color=colors[key], alpha=.16)
        density_ax.stairs(density, edges, label=labels[key], color=colors[key],
                          linestyle="-" if key == "z" else "--", linewidth=1.65)
    density_ax.set_title("单个坐标的取值分布", loc="left", fontsize=13, pad=12)
    density_ax.set(xlabel="坐标值", ylabel="概率密度", ylim=(0, None))
    density_ax.legend(frameon=False, fontsize=8, loc="upper left")
    density_ax.spines[["top", "right"]].set_visible(False)

    rows = []
    names = []
    for key, label in (("z", "后验 z"), ("prior", "独立对照")):
        for direction, axis_label in (("horizontal", "左右"), ("vertical", "上下")):
            rows.append(distributions[key]["neighbor_pearson"][direction])
            names.append(f"{label} · {axis_label}")
    rows = np.asarray(rows)
    if rows.shape != (4, 4) or not np.all(np.isfinite(rows)) or np.abs(rows).max() > 1.000001:
        raise ValueError("Expected one finite Pearson r per channel and direction.")
    cmap = LinearSegmentedColormap.from_list("pearson", ["#B84919", "#F5F5F3", "#005A85"])
    corr_ax.imshow(rows, cmap=cmap, vmin=-1, vmax=1, aspect="auto", interpolation="none")
    for (i, j), value in np.ndenumerate(rows):
        corr_ax.text(j, i, f"{value:.4f}", ha="center", va="center",
                     color="white" if abs(value) > .63 else "#232629", fontsize=10)
    corr_ax.set_title("相邻坐标的 Pearson 相关系数", loc="left", fontsize=13, pad=14)
    corr_ax.set_yticks(range(4), names)
    corr_ax.set_xticks(range(4), ["通道 1", "通道 2", "通道 3", "通道 4"])
    corr_ax.tick_params(length=0, pad=5)
    for spine in corr_ax.spines.values():
        spine.set_visible(False)
    fig.text(.075, .047, "左图汇总四个通道。右图在各通道内分别配对相邻位置，正值代表邻近位置倾向于一同升降。",
             size=9, color="#525A61")
    fig.savefig(output, dpi=300, facecolor="white")
    plt.close(fig)


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=root / "results.json")
    parser.add_argument("--output", type=Path, default=root / "latent-distributions.png")
    parser.add_argument("--font", type=Path, help="Optional Chinese font file")
    args = parser.parse_args()
    set_fonts(args.font)
    plot(json.loads(args.input.read_text(encoding="utf-8")), args.output)


if __name__ == "__main__":
    main()
