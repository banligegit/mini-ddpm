"""Verify the task-six interface against direct task-five reconstruction."""

import argparse
import json

import torch

from latent_io import FrozenLatents, HERE
from cifar_data import load_split
from evaluate import ssim_per_image


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    torch.set_num_threads(6)
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    interface = FrozenLatents(args.device)
    pixels, _ = load_split(HERE.parent / "data", train=False)
    total = torch.zeros(2, device=args.device, dtype=torch.float64)
    max_delta = torch.zeros(2, device=args.device)
    sums = torch.zeros((2, 4), dtype=torch.float64, device=args.device)
    for batch in torch.from_numpy(pixels).split(256):
        images = batch.to(device=args.device, dtype=torch.float32) / 255
        mu, _ = interface.vae.encode(images)
        normalized = interface.encode(images)
        assert normalized.shape[1:] == (4, 8, 8)
        restored = interface.decode(normalized)
        reference = interface.vae.decode(mu)
        max_delta = torch.maximum(max_delta, torch.stack([
            (normalized * interface.std + interface.mean - mu).abs().max(),
            (restored - reference).abs().max()]))
        dims = (0, 2, 3)
        sums[0] += normalized.sum(dims, dtype=torch.float64)
        sums[1] += normalized.square().sum(dims, dtype=torch.float64)
        mse = (images - restored).square().mean((1, 2, 3))
        total += torch.stack([(-10*mse.log10()).sum(dtype=torch.float64),
                              ssim_per_image(images, restored).sum(dtype=torch.float64)])
    if not (max_delta < 1e-5).all():
        raise AssertionError(f"Round-trip mismatch: {max_delta.tolist()}")
    mean, second = sums / (len(pixels) * 64)
    psnr, ssim = (total / len(pixels)).tolist()
    result = dict(test_images=len(pixels), normalized_test_mean=mean.tolist(),
                  normalized_test_std=(second - mean.square()).sqrt().tolist(),
                  max_abs_mu_error=max_delta[0].item(), max_abs_rgb_error=max_delta[1].item(),
                  psnr=psnr, ssim=ssim)
    text = json.dumps(result, indent=2, allow_nan=False)
    (HERE / "roundtrip.json").write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
