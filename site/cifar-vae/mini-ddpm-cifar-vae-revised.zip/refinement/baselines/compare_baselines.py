"""Compare the two original frozen VAE checkpoints on all 10,000 CIFAR-10 test images."""

import argparse
import hashlib
import json
import sys
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
TASK5 = HERE.parents[1]
sys.path.insert(0, str(TASK5))
from cifar_data import load_split
from evaluate import ssim_per_image
from model import load_model


@torch.inference_mode()
def measure(pixels, checkpoint, device, batch_size, seed):
    vae = load_model(checkpoint, device).requires_grad_(False)
    dims = 4 * vae.side**2
    noise = torch.randn(len(pixels), 4, vae.side, vae.side,
                        generator=torch.Generator(device="cpu").manual_seed(seed))
    latent_sums = torch.zeros(3, device=device, dtype=torch.float64)
    metric_sums = torch.zeros((2, 3), device=device, dtype=torch.float64)
    for start in range(0, len(pixels), batch_size):
        idx = slice(start, start + batch_size)
        x = pixels[idx].to(device, dtype=torch.float32) / 255
        mu, logvar = vae.encode(x)
        sigma = torch.exp(0.5 * logvar)
        lv = logvar.double()
        latent_sums += torch.stack((
            sigma.sum(dtype=torch.float64),
            0.5 * mu.double().square().sum(),
            0.5 * (torch.expm1(lv) - lv).sum(),
        ))
        z = mu + sigma * noise[idx].to(device)
        for i, latent in enumerate((mu, z)):
            recon = vae.decode(latent)
            mse = (x - recon).square().mean(dim=(1, 2, 3))
            scores = torch.stack((mse, -10 * mse.log10(), ssim_per_image(x, recon)))
            metric_sums[i] += scores.sum(dim=1, dtype=torch.float64)
    avg_sigma, mean_kl, variance_kl = (latent_sums / (len(pixels) * dims)).tolist()
    total_kl = mean_kl + variance_kl
    reconstructions = {
        name: dict(zip(("mse", "psnr_db", "ssim"), row))
        for name, row in zip(("mu", "z"), (metric_sums / len(pixels)).tolist())
    }
    return dict(checkpoint=checkpoint.name, sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
                coordinates=dims, mean_sigma=avg_sigma, kl_per_image=total_kl * dims,
                kl_per_coordinate=total_kl, kl_mean_term_per_coordinate=mean_kl,
                kl_variance_term_per_coordinate=variance_kl, kl_mean_fraction=mean_kl/total_kl,
                kl_variance_fraction=variance_kl/total_kl, reconstructions=reconstructions)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--seed", type=int, default=20261123)
    parser.add_argument("--data", type=Path, default=TASK5 / "data")
    parser.add_argument("--runs", type=Path, default=TASK5 / "runs")
    parser.add_argument("--output", type=Path, default=HERE / "comparison.json")
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    torch.set_num_threads(min(8, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    pixels, _ = load_split(args.data, train=False)
    pixels = torch.from_numpy(pixels)
    assert len(pixels) == 10000
    output = dict(split="official CIFAR-10 test", images=len(pixels), prior="standard normal",
                  z_sampling="One posterior sample per image, CPU-generated normal noise in dataset order",
                  seed=args.seed, device=args.device, torch=str(torch.__version__),
                  kl_units="nats", reconstruction_aggregation="Mean of per-image scores in RGB [0,1]",
                  models={})
    for side in (16, 8):
        row = measure(pixels, args.runs / f"vae{side}.pt", args.device, args.batch_size, args.seed)
        assert row["coordinates"] == 4 * side**2
        output["models"][str(side)] = row
    contents = json.dumps(output, indent=2, allow_nan=False)
    args.output.write_text(contents + "\n", encoding="utf-8")
    print(contents)


if __name__ == "__main__":
    main()
