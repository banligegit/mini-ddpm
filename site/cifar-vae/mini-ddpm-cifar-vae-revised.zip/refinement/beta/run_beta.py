"""Matched 8x8 VAE beta sweep on a fixed split of the official training set."""

import argparse
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
TASK = HERE.parents[1]
sys.path.insert(0, str(TASK))
from cifar_data import CLASS_NAMES, load_split
from evaluate import save_grid, ssim_per_image
from model import ConvVAE, load_model
from train import train_one


BETAS = (0.001, 0.003, 0.01)
SPLIT_SEED = 20261123
TRAIN_SEED = 2026
PRIOR_SEEDS = (202605, 202606)


def split_indices(labels):
    """Stratify once, then use the same source images and their order in every run."""
    rng = np.random.default_rng(SPLIT_SEED)
    training, validation = [], []
    for class_id in range(10):
        pool = np.flatnonzero(labels == class_id)
        if len(pool) != 5000:
            raise ValueError("Expected 5,000 official training images in every class")
        perm = rng.permutation(pool)
        validation.append(perm[:500])
        training.append(perm[500:])
    return np.sort(np.concatenate(training)), np.sort(np.concatenate(validation))


def initialization_digest():
    torch.manual_seed(TRAIN_SEED)
    digest = hashlib.sha256()
    for name, parameter in ConvVAE(8).state_dict().items():
        digest.update(name.encode())
        digest.update(parameter.numpy().tobytes())
    return digest.hexdigest()


@torch.inference_mode()
def validate(model, pixels, device):
    names = ["mse", "psnr", "ssim", "sigma_mean", "kl_mean_term", "kl_variance_term"]
    total = torch.zeros(len(names), device=device, dtype=torch.float64)
    dims = (1, 2, 3)
    for batch in pixels.split(256):
        x = batch.to(device=device, dtype=torch.float32) / 255
        mu, lv = model.encode(x)
        recon = model.decode(mu)
        mse = (recon - x).square().mean(dims)
        mean_term = mu.double().square().mean(dims) / 2
        lv = lv.double()
        var_term = (lv.expm1() - lv).mean(dims) / 2
        quantities = [mse, -10 * mse.log10(), ssim_per_image(x, recon),
                      (0.5 * lv).exp().mean(dims), mean_term, var_term]
        total += torch.stack(quantities).sum(1, dtype=torch.float64)
    result = dict(zip(names, (total / len(pixels)).tolist()))
    result["kl_per_coordinate"] = result["kl_mean_term"] + result["kl_variance_term"]
    result["kl_per_image"] = 256 * result["kl_per_coordinate"]
    result["kl_variance_fraction"] = result["kl_variance_term"] / result["kl_per_coordinate"]
    return result


@torch.inference_mode()
def save_examples(model, example, out, device):
    rec = model.decode(model.encode(example)[0])
    save_grid(rec, out / "reconstruction.png", columns=10)
    for seed in PRIOR_SEEDS:
        generator = torch.Generator().manual_seed(seed)
        prior = torch.randn(32, 4, 8, 8, generator=generator).to(device)
        save_grid(model.decode(prior), out / f"prior-{seed}.png", columns=8)


def run(args):
    torch.set_num_threads(min(8, torch.get_num_threads()))
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    data, labels = load_split(args.data, train=True)
    train_idx, val_idx = split_indices(labels)
    np.savez_compressed(out / "split.npz", train=train_idx, val=val_idx)
    train_x = torch.from_numpy(data[train_idx]).to(args.device)
    val_x = torch.from_numpy(data[val_idx])
    index = [int(val_idx[labels[val_idx] == digit][0]) for digit in range(10)]
    sample = torch.from_numpy(data[index]).to(device=args.device, dtype=torch.float32) / 255
    del data
    save_grid(sample, out / "original.png", columns=10)
    result = {
        "split": {"source": "official training set", "seed": SPLIT_SEED, "per_class_train": 4500,
                  "per_class_validation": 500, "train_images": 45000, "validation_images": 5000,
                  "training_indices_sha256": hashlib.sha256(train_idx.astype("<i8").tobytes()).hexdigest(),
                  "validation_indices_sha256": hashlib.sha256(val_idx.astype("<i8").tobytes()).hexdigest()},
        "training": {"seed": TRAIN_SEED, "initial_state_sha256": initialization_digest(),
                     "epochs": 10, "batch_size": 256, "steps_per_epoch": 176, "updates": 1760,
                     "optimizer": "Adam", "lr": 0.002, "final_lr": 0.0002, "schedule": "cosine",
                     "kl_denominator": 3072, "side": 8},
        "validation_reconstruction": "deterministic posterior mean; full validation split",
        "figure_indices": index, "figure_classes": list(CLASS_NAMES),
        "prior_seeds": list(PRIOR_SEEDS), "prior_images_per_seed": 32, "models": {},
    }
    for beta in BETAS:
        name = str(beta)
        directory = out / name
        directory.mkdir(exist_ok=True)
        # train_one resets model initialization, posterior sampling and shuffle seeds on each call.
        # Restore the original training precision policy after each float32 validation.
        options = SimpleNamespace(seed=TRAIN_SEED, out=directory, epochs=10,
                                  lr=0.002, beta=beta, batch_size=256)
        print(f"Training beta {name}", flush=True)
        train_one(8, train_x, options)
        with torch.backends.cudnn.flags(enabled=torch.backends.cudnn.enabled,
                                        benchmark=torch.backends.cudnn.benchmark,
                                        deterministic=torch.backends.cudnn.deterministic, allow_tf32=False):
            checkpoint = directory / "vae8.pt"
            model = load_model(checkpoint, args.device)
            metrics = validate(model, val_x, args.device)
            metrics["checkpoint_sha256"] = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
            save_examples(model, sample, directory, args.device)
            result["models"][name] = metrics
            print("Validation", name, json.dumps(metrics), flush=True)
    target = out / "validation.json"
    temporary = target.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(target)
    from plot_beta import make_figures
    make_figures(out, result)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", type=Path, default=TASK / "data")
    p.add_argument("--out", type=Path, default=HERE)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    run(p.parse_args())
