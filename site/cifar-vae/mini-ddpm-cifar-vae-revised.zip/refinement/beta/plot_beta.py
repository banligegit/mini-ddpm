"""Display all fixed samples and plot separate reconstruction and KL curves."""

import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont


def label_font(size):
    try:
        return ImageFont.truetype("DejaVuSans.ttf", size=size)
    except OSError:
        return ImageFont.load_default(size=size)


def write_images(out, results):
    betas = list(results["models"])
    size, gap = 72, 3
    left, top = 130, 38
    classes = results["figure_classes"]
    img = Image.new("RGB", (left + (size + gap)*10, top + (size + gap)*4), "white")
    draw = ImageDraw.Draw(img)
    font = label_font(15)
    for col, name in enumerate(classes):
        draw.text((left + (size + gap)*col + size/2, top/2), name, fill="#222222", font=font, anchor="mm")
    rows = [("Original", out / "original.png")] + [
        (f"beta = {beta}", out / beta / "reconstruction.png") for beta in betas]
    for row, (label, path) in enumerate(rows):
        y = top + row*(size+gap)
        draw.text((8,y+size/2),label,fill="#222222",font=font,anchor="lm")
        with Image.open(path) as strip:
            for col in range(10):
                tile = strip.crop((col*32,0,(col+1)*32,32)).resize((size,size),Image.Resampling.NEAREST)
                img.paste(tile,(left+col*(size+gap),y))
    img.save(out/"reconstruction-comparison.png",optimize=True)

    tile_size, gap, header = 64, 2, 26
    block_height = header + len(betas)*(tile_size+gap)
    for seed in results["prior_seeds"]:
        sheet = Image.new("RGB",(left+8*(tile_size+gap),4*block_height),"white")
        draw = ImageDraw.Draw(sheet)
        for block in range(4):
            top = block*block_height
            draw.text((8,top+header/2),f"Seed {seed}   /   draws {block*8+1:02d}-{block*8+8:02d}",
                      fill="#222222",font=font,anchor="lm")
            for row,beta in enumerate(betas):
                y = top+header+row*(tile_size+gap)
                draw.text((8,y+tile_size/2),f"beta = {beta}",fill="#222222",font=font,anchor="lm")
                with Image.open(out/beta/f"prior-{seed}.png") as grid:
                    for col in range(8):
                        tile=grid.crop((col*32,block*32,(col+1)*32,(block+1)*32))
                        sheet.paste(tile.resize((tile_size,tile_size),Image.Resampling.NEAREST),
                                    (left+col*(tile_size+gap),y))
        sheet.save(out/f"prior-{seed}.png",optimize=True)


def make_figures(out, results):
    write_images(out, results)
    fig, axes = plt.subplots(1, 2, figsize=(8.3, 3.4), layout="constrained")
    colors = ("#15598c", "#b6531b", "#33815b")
    for (beta, color) in zip(results["models"], colors):
        with (out/beta/"history8.csv").open(encoding="utf-8") as f:
            records = list(csv.DictReader(f))
        epochs = [int(row["epoch"]) for row in records]
        for ax, column in zip(axes, ("mse", "kl_per_pixel")):
            ax.plot(epochs,[float(row[column]) for row in records],
                    marker="o",markersize=3,color=color,label=f"β = {beta}")
            ax.set_xlabel("Epoch")
            ax.set_xticks([1, 2, 4, 6, 8, 10])
    axes[0].set_ylabel("Training reconstruction MSE")
    axes[1].set_ylabel("Training KL per image / 3,072")
    axes[0].legend(frameon=False)
    fig.savefig(out/"training-curves.png",dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=Path(__file__).resolve().parent)
    out = parser.parse_args().out
    make_figures(out,json.loads((out/"validation.json").read_text(encoding="utf-8")))
