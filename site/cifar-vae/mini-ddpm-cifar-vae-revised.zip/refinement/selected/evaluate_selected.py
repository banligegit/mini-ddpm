"""Score the validation-selected beta on official test images and check its scaling."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "latent_diagnostics"))
from latent_io import FrozenLatents
from cifar_data import load_split
from evaluate import ssim_per_image
from model import load_model


def read_decision(path=HERE / "decision.json"):
    return json.loads(path.read_text(encoding="utf-8"))


def candidate(decision, beta_dir=HERE.parent / "beta"):
    return beta_dir / decision["validation_selected_beta"] / "vae8.pt"


def task6_codec(device="cpu"):
    """Use the checkpoint and its matching training-set statistics chosen in the report."""
    decision = read_decision()
    if decision["use_new_weights_for_task6"]:
        return FrozenLatents(device, candidate(decision), HERE / "channel-statistics.json")
    return FrozenLatents(device)


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--beta-dir", type=Path, default=HERE.parent / "beta")
    parser.add_argument("--decision", type=Path, default=HERE / "decision.json")
    parser.add_argument("--out", type=Path, default=HERE)
    args = parser.parse_args()
    torch.set_num_threads(min(8, torch.get_num_threads()))
    if torch.device(args.device).type == "cuda":
        torch.backends.cudnn.allow_tf32 = False
    decision = read_decision(args.decision)
    checkpoint = candidate(decision, args.beta_dir)
    digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    if digest != decision["candidate_sha256"]:
        raise ValueError("Selected checkpoint differs from the recorded decision")
    model = load_model(checkpoint, args.device).requires_grad_(False)
    with np.load(args.beta_dir / "split.npz") as split:
        indices = split["train"]
    validation = json.loads((args.beta_dir / "validation.json").read_text(encoding="utf-8"))
    if hashlib.sha256(indices.astype("<i8").tobytes()).hexdigest() != validation["split"]["training_indices_sha256"]:
        raise ValueError("Training indices differ from those of the beta comparison")
    pixels, _ = load_split(args.data, train=True)
    sums = torch.zeros(2, 4, dtype=torch.float64, device=args.device)
    for batch in torch.from_numpy(pixels[indices]).split(256):
        x = batch.to(args.device, torch.float32) / 255
        mu = model.encode(x)[0].double()
        sums += torch.stack((mu.sum((0, 2, 3)), mu.square().sum((0, 2, 3))))
    mean, second = sums / (len(indices) * 64)
    std = (second - mean.square()).sqrt()
    channels = [dict(mean=m, std=s) for m, s in zip(mean.tolist(), std.tolist())]
    stats = dict(checkpoint_sha256=digest, splits={"train": {
        "images": len(indices), "distributions": {"mu": {"channels": channels}}}})
    args.out.mkdir(parents=True, exist_ok=True)
    stat_file = args.out / "channel-statistics.json"
    stat_file.write_text(json.dumps(stats, indent=2) + "\n", encoding="utf-8")
    codec = FrozenLatents(args.device, checkpoint, stat_file)

    pixels, _ = load_split(args.data, train=False)
    totals = torch.zeros(3, dtype=torch.float64, device=args.device)
    max_errors = torch.zeros(2, device=args.device)
    for batch in torch.from_numpy(pixels).split(256):
        x = batch.to(args.device, torch.float32) / 255
        mu = model.encode(x)[0]
        target = codec.encode(x)
        recon = codec.decode(target)
        direct = model.decode(mu)
        max_errors = torch.maximum(max_errors, torch.stack((
            (target * codec.std + codec.mean - mu).abs().max(), (recon - direct).abs().max())))
        mse = (recon - x).square().mean((1, 2, 3))
        totals += torch.stack([mse, -10 * mse.log10(), ssim_per_image(x, recon)]).sum(1, dtype=torch.float64)
    if not (max_errors < 1e-5).all():
        raise ValueError(f"Scaling round trip failed: {max_errors.tolist()}")
    mse, psnr, ssim = (totals / len(pixels)).tolist()
    result = dict(beta=decision["validation_selected_beta"], checkpoint_sha256=digest,
                  training_images=len(indices), test_images=len(pixels), mse=mse, psnr=psnr,
                  ssim=ssim, max_abs_mu_error=max_errors[0].item(), max_abs_rgb_error=max_errors[1].item())
    text = json.dumps(result, indent=2, allow_nan=False)
    (args.out / "test.json").write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
