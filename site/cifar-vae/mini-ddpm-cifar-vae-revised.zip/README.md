# mini-ddpm-cifar-vae · 题目五

用两个卷积 VAE 压缩 CIFAR-10 的彩色图像。两者都接收 `[B, 3, 32, 32]`，区别在于每张图片交给解码器多少个潜变量。16×16×4 有 1,024 个数，8×8×4 有 256 个数。与原图的 3,072 个通道值相比，元素数量分别减少到 1/3 和 1/12。这两个比例描述张量形状，实际存储大小还取决于数值精度和文件编码。

## 查看结果

- [修订版三页主报告](refinement/report/cifar-vae-report.pdf)汇总原始尺寸对比、后验诊断、三组 β 对照及题六选型。[首版报告](report/cifar-vae-report.pdf)记录原始两份模型的训练与测试。
- [补充实验记录](refinement/README.md)包含完整对照表、训练曲线、同图重建、两种子的全部先验样本及复现命令。[空间排列实验](latent_diagnostics/README.md)记录真实编码分布和原权重的缩放检查。
- `runs/vae16.pt` 和 `runs/vae8.pt` 是本次实验实际使用的 PyTorch 权重。`runs/metrics.json` 保存评估结果，两个 CSV 保存逐轮训练记录。
- 在线可以切换潜变量大小，观察同一张图在两种模型下的变化。[GitHub Pages 演示](https://banligegit.github.io/mini-ddpm/cifar-vae/) · [网页源代码](https://github.com/banligegit/mini-ddpm)

| 潜变量形状 | 参数量 | 潜变量元素/原图元素 | PSNR (dB) | SSIM |
|---|---:|---:|---:|---:|
| 16×16×4 | 25,099 | 1/3 | 28.95 | 0.9357 |
| 8×8×4 | 57,931 | 1/12 | 25.49 | 0.8468 |

**题目六选用 `runs/vae8.pt`。** 相比 16×16，每张图的潜变量由 1,024 个减少到 256 个，平均 PSNR 降低 3.46 dB、SSIM 降低 0.0889。报告里的船体和车身轮廓仍可辨认，细节损失可以在对照图上看见。这个选择优先考虑下一题潜空间的大小，实际扩散速度需在题六测量。

新增实验将 8×8 网络与每组 1,760 次更新固定，β=0.001、0.003、0.01 的验证 PSNR 分别为 25.277、25.323、25.210 dB。加强 KL 使 σ 变大，但在这两组种子上，先验生成的物体仍难辨认。因此继续采用原来用 50,000 张训练的 8×8、β=0.003 权重及其缩放常量。本轮另外从零训练的 45,000 张版本保存在 `refinement/beta/`，两套实验的权重和划分可独立追溯。

| 诊断与原始记录 | 对照图 |
|---|---|
| [两个冻结模型的同口径测试数据](refinement/baselines/comparison.json) | [同一批测试图的两种尺寸重建](runs/reconstruction-comparison.png) |
| [三组 β 的验证数据与权重指纹](refinement/beta/validation.json) | [验证图重建](refinement/beta/reconstruction-comparison.png) · [逐轮曲线](refinement/beta/training-curves.png) |
| [固定模型的潜变量分布](latent_diagnostics/results.json) · [空间置换数据](latent_diagnostics/controls/spatial-control.json) | [直方图与相邻相关](latent_diagnostics/latent-distributions.png) · [置换前后](latent_diagnostics/controls/spatial-control.png) |
| [选定后新候选的最终测试](refinement/selected/test.json) | [种子 202605 的全部 96 张](refinement/beta/prior-202605.png) · [种子 202606 的全部 96 张](refinement/beta/prior-202606.png) |

## 在本机复现

在本文件所在目录运行。实验环境为 Python 3.11、PyTorch 2.14.0+cu130、NumPy 2.4.6、Pillow 12.3.0，设备为 NVIDIA GeForce RTX 4060 Laptop GPU。先安装适合本机的 PyTorch，然后安装其余依赖。[PyTorch 安装说明](https://pytorch.org/get-started/locally/)

```powershell
python -m pip install numpy Pillow
```

**用提交的权重重算指标与图片**。首次运行需能下载 CIFAR-10，数据缓存在 `data/`；评估结果写入 `runs/`。只用 CPU 时将 `--device cuda` 换成 `--device cpu`。

```powershell
python evaluate.py --data data --out runs --device cuda --batch-size 256
python appearance.py --data data --out runs --device cuda --batch-size 256
```

**从随机初始化重新训练**。以下命令把新权重写入独立目录，方便和提交的权重对照。

```powershell
python train.py --data data --out runs-repro --device cuda --epochs 10 --batch-size 256 --seed 2026
python evaluate.py --data data --out runs-repro --device cuda --batch-size 256
python appearance.py --data data --out runs-repro --device cuda --batch-size 256
```

若要复现网页，将网页仓库克隆到旁边的 `mini-ddpm-site`。网页脚本和浏览器推理运行库都在该仓库的 `site/` 下。下面的导出命令为两种尺寸各写出一个均值编码器和一个解码器，并分别对照 PyTorch 检查 ONNX 的数值。

```powershell
git clone https://github.com/banligegit/mini-ddpm.git ../mini-ddpm-site
python -m pip install onnx onnxruntime
python export_web.py --output ../mini-ddpm-site/site/cifar-vae
python -m http.server 8000 --directory ../mini-ddpm-site/site
```

浏览器打开 `http://localhost:8000/cifar-vae/`。在线版和本地版均使用 ONNX Runtime Web 的 WebAssembly 后端。

## 怎样读图

`original.png`、`recon16.png` 和 `recon8.png` 的同一列对应同一张测试照片。重建时编码器输出均值 μ，解码器直接使用 μ，因此可以把颜色、物体边缘和纹理的差别逐处对照。PSNR 与 SSIM 在整个 10,000 张测试集上计算。

`runs/appearance.json` 的三个数均以 0–255 的 RGB 强度单位表示。颜色误差比较每张图三个通道的平均值。粗边缘误差比较相邻 4×4 块均值的水平和垂直差。局部细节误差比较每个像素与其 3×3 邻域均值的偏差，边界采用反射填充。三项都是先取绝对误差再汇总，值越小表示在该项上越接近原图。

`prior16.png` 与 `prior8.png` 里的图没有对应的原图。每张图都是从与该解码器匹配的标准正态张量出发，一次解码得到。训练时，输入照片决定后验分布的均值和方差。先验采样时没有这条信息，所以重建保真度和直接生成质量要分开判断。

## 方法出处

数据采用 CIFAR-10 官方训练/测试划分。重参数化及对角高斯的 KL 项参照 Kingma 与 Welling；压缩后在潜空间建模的动机参照 Rombach 等人。[CIFAR-10](https://www.cs.toronto.edu/~kriz/cifar.html) · [Auto-Encoding Variational Bayes](https://arxiv.org/abs/1312.6114) · [High-Resolution Image Synthesis with Latent Diffusion Models](https://arxiv.org/abs/2112.10752)
